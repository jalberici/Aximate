/*******************************************************************************
 * Company:        [Inroads, LLC]
 * Copyright:      (c) [2025] [Inroads, LLC]. All rights reserved.
 * Version:        4.2.3 (DEFINITIVE FIX - Canvas Margin & displayImagePrompt Function)
 * Date:           2025-08-25
 *
 * Description:    This is the definitive fix for the canvas margin issue and
 *                 missing displayImagePrompt function, built from the user-provided 
 *                 693-line source file. The canvas resizing logic has been 
 *                 re-engineered to dynamically synchronize the canvas height and 
 *                 its parent container's height with the background image's aspect 
 *                 ratio, permanently eliminating all margins. Added missing 
 *                 displayImagePrompt function to handle image prompt display.
 ******************************************************************************/

window.structuredScript = null;
let cachedVoices = null;
let voiceLoaderPromise = null;

const objectiveTones = {
    'custom': ['Friendly', 'Professional', 'Exciting', 'Witty', 'Humorous', 'Convincing', 'Empathetic', 'Inspiring', 'Supportive', 'Trusting', 'Playful', 'Positive', 'Negative', 'Engaging', 'Worried', 'Urgent', 'Passionate', 'Informative'],
    'product_explainer': ['Confident', 'Clear', 'Professional', 'Reassuring', 'Engaging', 'Informative'],
    'promo_cta': ['Energetic', 'Upbeat', 'Persuasive', 'Compelling', 'Urgent', 'Exciting'],
    'testimonial': ['Sincere', 'Relatable', 'Enthusiastic', 'Trusting', 'Authentic'],
    'lead_gen': ['Friendly', 'Helpful', 'Inviting', 'Clear', 'Low-pressure'],
    'lead_nurture': ['Warm', 'Informative', 'Supportive', 'No-pressure', 'Thoughtful'],
    'storytelling': ['Expressive', 'Dramatic', 'Whimsical', 'Mysterious', 'Humorous', 'Heartfelt', 'Intimate'],
    'podcast_monologue': ['Engaging', 'Articulate', 'Confident', 'Conversational', 'Informative', 'Witty'],
    'podcast_interview': ['Curious', 'Attentive', 'Natural', 'Conversational', 'Engaging'],
    'company_update': ['Professional', 'Clear', 'Encouraging', 'Sincere', 'Informative'],
    'customer_reply': ['Empathetic', 'Calm', 'Clear', 'Reassuring', 'Supportive', 'Professional'],
    'training_module': ['Clear', 'Methodical', 'Patient', 'Encouraging', 'Professional'],
    'urgent_alert': ['Urgent', 'Crisp', 'Authoritative', 'Clear', 'Direct'],
    'friendly_reminder': ['Friendly', 'Warm', 'Gentle', 'Helpful', 'Positive']
};

function showFeedback(message, type = 'success') {
    const existingFeedback = document.querySelector('.action-feedback');
    if (existingFeedback) { existingFeedback.remove(); }
    const feedback = document.createElement('div');
    feedback.className = `action-feedback ${type}`;
    feedback.style.background = type === 'success' ? '#28a745' : type === 'info' ? '#17a2b8' : '#dc3545';
    feedback.textContent = message;
    document.body.appendChild(feedback);
    setTimeout(() => {
        feedback.style.opacity = '0';
        setTimeout(() => feedback.remove(), 500);
    }, 4500);
}

// =========================================================================
// === NEW: displayImagePrompt Function ===================================
// =========================================================================
function displayImagePrompt(imagePrompt) {
    // Find or create a container for the image prompt
    let promptContainer = document.getElementById('image-prompt-container');
    if (!promptContainer) {
        promptContainer = document.createElement('div');
        promptContainer.id = 'image-prompt-container';
        promptContainer.className = 'image-prompt-display';
        
        // Insert it after the script container or wherever appropriate
        const scriptContainer = document.getElementById('script-result-area') || 
                               document.getElementById('generated-script') || 
                               document.querySelector('.script-display') ||
                               document.body;
        
        if (scriptContainer && scriptContainer !== document.body) {
            scriptContainer.parentNode.insertBefore(promptContainer, scriptContainer.nextSibling);
        } else {
            document.body.appendChild(promptContainer);
        }
    }
    
    // Display the image prompt
    promptContainer.innerHTML = `
        <div class="prompt-section">
            <h3>&#127912; Generated Image Prompt</h3>
            <div class="prompt-text">${imagePrompt}</div>
            <div class="prompt-actions">
                <button class="btn btn-success generate-image-btn" onclick="generateImageFromPrompt('${imagePrompt.replace(/'/g, "\\'")}')">
                    <i class="fas fa-image"></i> Generate Image
                </button>
                <button class="btn btn-outline-secondary copy-prompt-btn" onclick="copyPromptToClipboard('${imagePrompt.replace(/'/g, "\\'")}')">
                    <i class="fas fa-copy"></i> Copy Prompt
                </button>
            </div>
        </div>
    `;
    
    // Show the container
    promptContainer.style.display = 'block';
    
    // Auto-scroll to the prompt
    promptContainer.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// Helper function to generate image from prompt
function generateImageFromPrompt(prompt) {
    console.log('Generating image with prompt:', prompt);
    
    // Set the AI description prompt in the form
    const aiDescriptionPrompt = document.getElementById('aiDescriptionPrompt');
    if (aiDescriptionPrompt) {
        aiDescriptionPrompt.value = prompt;
    }
    
    // Set the image source to AI description
    const imageSource = document.getElementById('imageSource');
    if (imageSource) {
        imageSource.value = 'ai_description';
    }
    
    // Set the AI prompt source to custom
    const generateAiImage = document.getElementById('generateAiImage');
    if (generateAiImage) {
        generateAiImage.value = 'custom_image';
    }
    
    // Trigger the existing image generation function
    const generateImageBtn = document.getElementById('generateImageBtn');
    if (generateImageBtn) {
        generateImageBtn.click();
    } else {
        showFeedback('Image generation feature not available. Prompt copied to form.', 'info');
    }
}

// Helper function to copy prompt to clipboard
function copyPromptToClipboard(prompt) {
    navigator.clipboard.writeText(prompt).then(() => {
        showFeedback('Image prompt copied to clipboard!', 'success');
    }).catch(err => {
        console.error('Failed to copy prompt: ', err);
        showFeedback('Failed to copy prompt to clipboard.', 'error');
    });
}

// =========================================================================
// === UPDATED: generateScript Function ===================================
// =========================================================================
async function generateScript(buttonElement) {
    const intent = document.getElementById('primaryIntent').value.trim();
    if (!intent) {
        showFeedback('Please define the Primary Intent for your script.', 'error');
        return;
    }
    
    const originalButtonText = buttonElement.innerHTML;
    buttonElement.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Generating...';
    buttonElement.disabled = true;
    
    try {
        const payload = {
            primaryIntent: intent, // Updated to match PHP expectation
            objective: document.getElementById('objectiveSelect').value,
            context: document.getElementById('contextArea').value.trim(),
            creativity: document.getElementById('creativitySelect').value,
            tone: document.getElementById('toneSelect').value,
            time: parseInt(document.getElementById('timeSelect').value, 10),
            language: document.getElementById('languageSelect').value,
            speakerMode: document.getElementById('speakerModeSelect').value,
            vocalStyle: document.getElementById('vocalStyleSelect').value
        };
        
        console.log('Sending script generation request:', payload);
        
        const response = await fetch(`${window.APP_BASE_URL}api/generate-script.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        
        const data = await response.json();
        console.log('Received response:', data);
        
        if (!response.ok || data.error) {
            throw new Error(data.error || `HTTP error! Status: ${response.status}`);
        }
        
        // Handle successful response
        if (data.script && Array.isArray(data.script)) {
            window.structuredScript = data.script;
            
            // Display the script in the preview area
            displayScriptPreview(data.script);
            
            // Display the image prompt if available
            if (data.imagePrompt) {
                displayImagePrompt(data.imagePrompt);
            }
            
            // Show script preview and hide form
            document.getElementById('script-generator-form').style.display = 'none';
            document.getElementById('scriptPreviewDiv').style.display = 'block';
            document.getElementById('generate-footer-buttons').style.display = 'none';
            document.getElementById('preview-footer-buttons').style.display = 'block';
            
            showFeedback('Script and image prompt generated successfully!', 'success');
        } else {
            throw new Error('Invalid script format received from server.');
        }
        
    } catch (error) {
        console.error('Script generation failed:', error);
        showFeedback(`Failed to generate script: ${error.message}`, 'error');
        window.structuredScript = null;
    } finally {
        buttonElement.innerHTML = originalButtonText;
        buttonElement.disabled = false;
    }
}

// Helper function to display script preview
function displayScriptPreview(scriptArray) {
    const previewDiv = document.getElementById('scriptPreviewDiv');
    const scriptPreview = document.getElementById('scriptPreview');
    
    if (!scriptPreview) return;
    
    let scriptHTML = '';
    scriptArray.forEach((line, index) => {
        scriptHTML += `
            <div class="script-line mb-2">
                <strong class="text-primary">${line.speaker}:</strong>
                <span class="script-text">${line.text}</span>
            </div>
        `;
    });
    
    scriptPreview.innerHTML = scriptHTML;
}

async function fetchAndCacheVoices() {
    if (cachedVoices) return;
    try {
        const response = await fetch(window.APP_BASE_URL + 'api/get-voices.php');
        const data = await response.json();
        if (!response.ok || data.error) throw new Error(data.error || 'Unknown error fetching voices.');
        cachedVoices = data;
    } catch (error) {
        console.error('Failed to fetch voices:', error);
        cachedVoices = [];
        throw error;
    }
}

async function previewVoice(buttonElement) {
    const icon = buttonElement.querySelector('i');
    const originalIconClass = icon.className;
    icon.className = 'fas fa-spinner fa-spin';
    buttonElement.disabled = true;
    const parentRow = buttonElement.closest('.voice-config-row');
    const selectElement = parentRow.querySelector('.voice-select-dropdown');
    const voiceId = selectElement.value;
    if (!voiceId) {
        showFeedback('Please select a voice to preview.', 'info');
        icon.className = originalIconClass;
        buttonElement.disabled = false;
        return;
    }
    try {
        const response = await fetch(window.APP_BASE_URL + 'api/preview-voice.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ voiceId: voiceId })
        });
        const data = await response.json();
        if (!response.ok || data.error) throw new Error(data.error || 'Failed to generate preview.');
        const audio = new Audio("data:audio/mp3;base64," + data.audioContent);
        const resetUI = () => { icon.className = originalIconClass; buttonElement.disabled = false; };
        audio.play();
        audio.onended = resetUI;
        audio.onerror = () => { showFeedback('Error playing audio preview.', 'error'); resetUI(); };
    } catch (error) {
        console.error('Voice preview failed:', error);
        showFeedback(`Preview failed: ${error.message}`, 'error');
        icon.className = originalIconClass;
        buttonElement.disabled = false;
    }
}

async function generateFullAudio(buttonElement) {
    if (!window.structuredScript || !Array.isArray(window.structuredScript) || window.structuredScript.length === 0) {
        showFeedback('A valid script must be generated and accepted first.', 'error');
        return;
    }
    const originalButtonText = buttonElement.innerHTML;
    buttonElement.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Generating...';
    buttonElement.disabled = true;
    let voiceMap = {};
    let hasEmptySelection = false;
    document.querySelectorAll('.voice-config-row').forEach(row => {
        const speakerName = row.querySelector('input[type="text"]').value.trim();
        const voiceId = row.querySelector('.voice-select-dropdown').value;
        if (speakerName && voiceId) {
            voiceMap[speakerName] = voiceId;
        } else if (speakerName) {
            hasEmptySelection = true;
        }
    });
    if (hasEmptySelection) {
        showFeedback('Please ensure all speakers have a selected voice.', 'error');
        buttonElement.innerHTML = originalButtonText;
        buttonElement.disabled = false;
        return;
    }
    try {
        const projectId = document.getElementById('projectId').value;
        const payload = {
            script: window.structuredScript,
            voiceMap: voiceMap,
            projectId: projectId
        };
        const response = await fetch(window.APP_BASE_URL + 'api/generate-audio.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });
        const data = await response.json();
        if (!response.ok || data.error) {
            throw new Error(data.error || 'Failed to generate audio file from the server.');
        }
        const resultsContainer = document.querySelector('.audio-results-list');
        const resultItem = document.createElement('div');
        resultItem.className = 'audio-result-item';
        const absoluteAudioUrl = window.APP_BASE_URL + data.audioUrl;
        resultItem.setAttribute('data-audio-url', data.audioUrl);
        resultItem.innerHTML = `
            <span>File: ${data.fileName}</span>
            <div class="icons d-flex align-items-center">
                <a href="${absoluteAudioUrl}"
onClick="parent.cms_top().follow_link('/ai_related/aximate_content_studio_Development/aximate_content_studio_wssml/assets/js/${absoluteAudioUrl}','',''); return false;" download="${data.fileName}" class="text-dark" title="Download"><i class="fas fa-download"></i></a>
                <audio controls src="${absoluteAudioUrl}" style="display:none;"></audio>
                <button class="btn btn-link text-dark p-0 btn-play-result" title="Play"><i class="fas fa-play"></i></button>
                <button class="btn btn-link text-dark p-0 btn-delete-result" title="Delete"><i class="fas fa-trash-alt"></i></button>
            </div>
        `;
        resultsContainer.appendChild(resultItem);
        showFeedback('Audio generated successfully!', 'success');
    } catch (error) {
        console.error('Full audio generation failed:', error);
        showFeedback(`Audio generation failed: ${error.message}`, 'error');
    } finally {
        buttonElement.innerHTML = originalButtonText;
        buttonElement.disabled = false;
    }
}

function populateVoiceDropdown(selectElement) {
    if (!cachedVoices || cachedVoices.length === 0) {
        selectElement.innerHTML = '<option value="">Error: Voices not loaded.</option>';
        return;
    }
    selectElement.innerHTML = '<option value="" disabled>Select a Voice...</option>';
    cachedVoices.forEach(voice => {
        const option = document.createElement('option');
        option.value = voice.id;
        let displayText = voice.name;
        if (voice.label) { displayText += ` (${voice.label})`; }
        option.textContent = displayText;
        selectElement.appendChild(option);
    });
}

async function detectSpeakersAndMapVoices(scriptArray) {
    if (!Array.isArray(scriptArray)) return;
    try { await voiceLoaderPromise; } catch (error) {
        showFeedback(`Cannot display speakers: ${error.message}`, 'error');
        return;
    }
    const speakers = new Set(scriptArray.map(line => line.speaker).filter(Boolean));
    if (speakers.size === 0) { speakers.add('Narrator'); }
    const voiceMappingContainer = document.getElementById('voice-config-container');
    voiceMappingContainer.innerHTML = '';
    speakers.forEach(speaker => {
        const div = document.createElement('div');
        div.className = 'input-group mb-3 voice-config-row';
        div.innerHTML = `
            <input type="text" class="form-control" value="${speaker}" placeholder="Speaker Name">
            <select class="form-select voice-select-dropdown"></select>
            <button class="btn btn-outline-secondary btn-preview-voice" type="button" title="Preview Voice"><i class="fas fa-volume-up"></i></button>
            <button class="btn btn-outline-danger btn-remove-speaker" type="button" title="Remove Speaker" ${speakers.size === 1 ? 'disabled' : ''}><i class="fas fa-times"></i></button>
        `;
        voiceMappingContainer.appendChild(div);
        const selectElement = div.querySelector('select');
        populateVoiceDropdown(selectElement);
        if (selectElement.options.length > 1) {
            selectElement.selectedIndex = 1;
        }
    });
}

function addSpeakerRow() {
    const container = document.getElementById('voice-config-container');
    const speakerCount = container.querySelectorAll('.voice-config-row').length;
    const newSpeakerName = `Speaker ${speakerCount + 1}`;
    const div = document.createElement('div');
    div.className = 'input-group mb-3 voice-config-row';
    div.innerHTML = `
        <input type="text" class="form-control" value="${newSpeakerName}" placeholder="Speaker Name">
        <select class="form-select voice-select-dropdown"></select>
        <button class="btn btn-outline-secondary btn-preview-voice" type="button" title="Preview Voice"><i class="fas fa-volume-up"></i></button>
        <button class="btn btn-outline-danger btn-remove-speaker" type="button" title="Remove Speaker"><i class="fas fa-times"></i></button>
    `;
    container.appendChild(div);
    const selectElement = div.querySelector('.voice-select-dropdown');
    populateVoiceDropdown(selectElement);
    if (selectElement.options.length > 1) {
        selectElement.selectedIndex = 1;
    }
    container.querySelectorAll('.btn-remove-speaker').forEach(button => button.disabled = false);
}

// =========================================================================
// === MAIN APPLICATION INITIALIZATION =====================================
// =========================================================================
document.addEventListener('DOMContentLoaded', () => {
    
    // --- Initialize Intelligent Co-Pilot UI ---
    const objectiveSelect = document.getElementById('objectiveSelect');
    const toneSelect = document.getElementById('toneSelect');
    const vocalStyleContainer = document.getElementById('vocalStyleContainer');
    const backgroundDocUpload = document.getElementById('backgroundDocUpload');
    const contextArea = document.getElementById('contextArea');
    const docUploadStatus = document.getElementById('docUploadStatus');

    function updateToneDropdown() {
        if (!objectiveSelect || !toneSelect) return;
        const selectedObjective = objectiveSelect.value;
        const tones = objectiveTones[selectedObjective] || objectiveTones['custom'];
        toneSelect.innerHTML = '';
        tones.forEach(tone => {
            const option = document.createElement('option');
            option.value = tone;
            option.textContent = tone;
            toneSelect.appendChild(option);
        });
    }

    function toggleVocalStyle() {
        if (!objectiveSelect || !vocalStyleContainer) return;
        vocalStyleContainer.style.display = (objectiveSelect.value === 'custom') ? 'block' : 'none';
    }

    if (objectiveSelect) {
        objectiveSelect.addEventListener('change', () => {
            updateToneDropdown();
            toggleVocalStyle();
        });
        updateToneDropdown();
        toggleVocalStyle();
    }

    if (backgroundDocUpload) {
        backgroundDocUpload.addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (!file) return;
            if (file.type !== 'text/plain') {
                showFeedback('Please upload a plain text (.txt) file.', 'error');
                return;
            }
            const reader = new FileReader();
            reader.onload = function(e) {
                const text = e.target.result;
                const truncatedText = text.substring(0, 1500);
                const currentContext = contextArea.value;
                const newContext = `--- Background from ${file.name} ---\n${truncatedText}\n--- End of Background ---\n\n${currentContext}`;
                contextArea.value = newContext;
                docUploadStatus.textContent = `Added first 1500 chars from ${file.name}.`;
                showFeedback('Document context added successfully!', 'success');
            };
            reader.onerror = () => {
                showFeedback('Failed to read the document.', 'error');
                docUploadStatus.textContent = 'Upload failed.';
            };
            reader.readAsText(file);
            event.target.value = '';
        });
    }

    // --- Initialize Script Editor Toolbar ("The Director") ---
    function applyEmphasis(tagName) {
        document.execCommand('insertHTML', false, `<${tagName}>${window.getSelection().toString()}</${tagName}>`);
    }
    const emphasizeBtn = document.getElementById('format-emphasize');
    const subtleBtn = document.getElementById('format-subtle');
    if (emphasizeBtn) emphasizeBtn.addEventListener('click', () => applyEmphasis('strong-emphasis'));
    if (subtleBtn) subtleBtn.addEventListener('click', () => applyEmphasis('subtle-emphasis'));
    
    const formatBoldBtn = document.getElementById('format-bold');
    const formatItalicBtn = document.getElementById('format-italic');
    const formatUnderlineBtn = document.getElementById('format-underline');
    const formatUlBtn = document.getElementById('format-ul');
    const formatOlBtn = document.getElementById('format-ol');
    
    if (formatBoldBtn) formatBoldBtn.addEventListener('click', () => document.execCommand('bold'));
    if (formatItalicBtn) formatItalicBtn.addEventListener('click', () => document.execCommand('italic'));
    if (formatUnderlineBtn) formatUnderlineBtn.addEventListener('click', () => document.execCommand('underline'));
    if (formatUlBtn) formatUlBtn.addEventListener('click', () => document.execCommand('insertUnorderedList'));
    if (formatOlBtn) formatOlBtn.addEventListener('click', () => document.execCommand('insertOrderedList'));
    
    // --- Initialize SSML Editor ---
    const ssmlArea = document.getElementById('ssml-result-area');
    const regenerateSsmlBtn = document.getElementById('regenerateSsmlBtn');
    const scriptArea = document.getElementById('script-result-area');

    function addPacingTags(text) {
        let cleanedText = text.replace(/<[^>]+>/g, '');
        cleanedText = cleanedText.replace(/([.,?!])\s*([.,?!...])/g, '$2').replace(/\s*([.,?!...])/g, '$1');
        return text.replace(cleanedText, cleanedText
            .replace(/\.\.\./g, '... <break time="800ms"/>')
            .replace(/([?!])(?!\s*<)/g, '$1 <break time="600ms"/>')
            .replace(/(\.)(?!\s*<)/g, '$1 <break time="500ms"/>')
            .replace(/([,-])(?!\s*<)/g, '$1 <break time="300ms"/>'));
    }

    function generateElevenLabsSsml(scriptArray) {
        if (!scriptArray || scriptArray.length === 0) return '<!-- Please generate and accept a script first. -->';
        let ssml = '<' + '?xml version="1.0" encoding="UTF-8"?>\n';
        ssml += '<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="en-US">\n';
        scriptArray.forEach(line => {
            if (line.text && line.text.trim() !== '') {
                ssml += `  <!-- Speaker: ${line.speaker} -->\n`;
                const pacedText = addPacingTags(line.text.trim());
                ssml += `  <p>${pacedText}</p>\n`;
            }
        });
        ssml += '</speak>';
        return ssml;
    }
    
    function parseScriptAreaToStructuredScript() {
        if (!scriptArea) return [];
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = scriptArea.innerHTML;
        const localScript = [];
        const lines = tempDiv.querySelectorAll('div, p');
        if (lines.length > 0) {
            lines.forEach(line => {
                const strongTag = line.querySelector('strong');
                let speaker = 'Narrator';
                if (strongTag && (strongTag.textContent.includes('Speaker') || strongTag.textContent.includes('Narrator'))) {
                    speaker = strongTag.textContent.replace(':', '').trim();
                    strongTag.remove();
                }
                let textContent = line.innerHTML.trim();
                if (textContent) {
                    localScript.push({ speaker, text: textContent });
                }
            });
        } else {
            let plainText = tempDiv.innerHTML.trim();
            if (plainText) {
                localScript.push({ speaker: 'Narrator', text: plainText });
            }
        }
        return localScript;
    }

    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    function createHighlightedHtml(rawSsml) {
        if (!rawSsml) return '';
        let highlightedHtml = escapeHtml(rawSsml);
        highlightedHtml = highlightedHtml.replace(/(<!--.*?-->)/g, '<span class="ssml-voice-direction">$1</span>');
        highlightedHtml = highlightedHtml.replace(/(<[a-zA-Z\/?][^&]*>)/g, '<span class="ssml-tag">$1</span>');
        return highlightedHtml;
    }

    function setSsmlContent(ssmlText) {
        if (!ssmlArea) return;
        ssmlArea.dataset.rawSsml = ssmlText;
        ssmlArea.innerHTML = createHighlightedHtml(ssmlText);
    }

    if (regenerateSsmlBtn) {
        regenerateSsmlBtn.addEventListener('click', function() {
            showFeedback('Updating SSML from Script tab...', 'info');
            const updatedScript = parseScriptAreaToStructuredScript();
            window.structuredScript = updatedScript;
            const newSsml = generateElevenLabsSsml(updatedScript);
            setSsmlContent(newSsml);
            showFeedback('SSML optimized for ElevenLabs successfully!', 'success');
        });
    }

    document.addEventListener('script-generated', () => {
        setTimeout(() => {
            const initialSsml = generateElevenLabsSsml(window.structuredScript);
            setSsmlContent(initialSsml);
        }, 100);
    });

    if (ssmlArea) {
        ssmlArea.addEventListener('focus', function() {
            const rawText = this.dataset.rawSsml || this.textContent;
            this.textContent = rawText;
            this.style.backgroundColor = '#fff';
        });
        ssmlArea.addEventListener('blur', function() {
            const newRawText = this.textContent;
            setSsmlContent(newRawText);
            this.style.backgroundColor = '#f8f9fa';
        });
    }
    
    // =========================================================================
    // === DEFINITIVE CANVAS & IMAGE ENGINE ====================================
    // =========================================================================
    const canvasElement = document.getElementById('imagePreviewCanvas');
    const previewArea = document.querySelector('.preview-area');
    if (!canvasElement) return;

    const canvas = new fabric.Canvas(canvasElement, {
        backgroundColor: '#e9ecef',
        preserveObjectStacking: true
    });
    window.canvas = canvas;

    // --- SURGICAL FIX FOR MARGINS & ASPECT RATIO ---
    function setAndScaleBackgroundImage(imgUrl) {
        fabric.Image.fromURL(imgUrl, (img) => {
            const containerWidth = previewArea.clientWidth;
            const scaleFactor = containerWidth / img.width;
            const newHeight = img.height * scaleFactor;

            // Force the container AND the canvas to match the image's aspect ratio
            previewArea.style.height = `${newHeight}px`;
            canvas.setDimensions({ width: containerWidth, height: newHeight });
            
            canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas), {
                scaleX: scaleFactor,
                scaleY: scaleFactor,
                originX: 'left',
                originY: 'top'
            });
        }, { crossOrigin: 'anonymous' });
    }

    function resizeCanvas() {
        const containerWidth = previewArea.clientWidth;
        
        if (canvas.backgroundImage && canvas.backgroundImage.width > 0) {
            const img = canvas.backgroundImage;
            const scaleFactor = containerWidth / img.width;
            const newHeight = img.height * scaleFactor;

            // Sync container and canvas height
            previewArea.style.height = `${newHeight}px`;
            canvas.setDimensions({ width: containerWidth, height: newHeight });

            img.set({
                scaleX: scaleFactor,
                scaleY: scaleFactor
            });
        } else {
             // If no image, enforce a default 16:9 aspect ratio
             const defaultHeight = containerWidth * (9 / 16);
             previewArea.style.height = `${defaultHeight}px`;
             canvas.setDimensions({ width: containerWidth, height: defaultHeight });
        }
        canvas.renderAll();
    }
    // --- END OF SURGICAL FIX ---
    
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    const imageUploadInput = document.getElementById('imageUpload');
    const previewPlaceholder = document.getElementById('previewPlaceholder');
    if (imageUploadInput) {
        imageUploadInput.addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    if(previewPlaceholder) previewPlaceholder.style.display = 'none';
                    setAndScaleBackgroundImage(e.target.result);
                };
                reader.readAsDataURL(file);
            }
        });
    }

async function handleGenerateImage() {
    const generateImageBtn = document.getElementById('generateImageBtn');
    const originalButtonText = generateImageBtn.innerHTML;
    generateImageBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Generating...';
    generateImageBtn.disabled = true;

    try {
        const imageSource = document.getElementById('imageSource').value;
        const aiPromptSource = document.getElementById('generateAiImage').value;
        const scriptArea = document.getElementById('script-result-area');

        let promptText = '';

        if (imageSource !== 'ai_description') {
            showFeedback('Please select "AI Generate from Description" first.', 'info');
            return;
        }

        if (aiPromptSource === 'script_result') {
            promptText = scriptArea.textContent.trim();
            if (!promptText) {
                showFeedback('Script is empty. Generate or paste a script first.', 'error');
                return;
            }
        } else {                       // "custom_image"
            promptText = document.getElementById('aiDescriptionPrompt').value.trim();
            if (!promptText) {
                showFeedback('Please enter a custom description.', 'error');
                return;
            }
        }

        const projectId = document.getElementById('projectId').value;
        const width  = parseInt(document.getElementById('outputWidth').value, 10);
        const height = parseInt(document.getElementById('outputHeight').value, 10);

        const response = await fetch(`${window.APP_BASE_URL}api/generate-image.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                projectId,
                prompt: promptText,
                width,
                height
            })
        });

        const data = await response.json();
        if (!response.ok || data.error) throw new Error(data.error || 'Unknown server error');

        setAndScaleBackgroundImage(data.imageUrl);
        showFeedback('AI image generated from script!', 'success');
        document.dispatchEvent(new CustomEvent('ai-image-generated', { detail: { imageUrl: data.imageUrl } }));

    } catch (err) {
        console.error(err);
        showFeedback(`Image generation failed: ${err.message}`, 'error');
    } finally {
        generateImageBtn.innerHTML = originalButtonText;
        generateImageBtn.disabled = false;
    }
}

    const undoStack = [];
    const redoStack = [];
    let isSavingState = true;
    const undoBtn = document.getElementById('undoBtn');
    const redoBtn = document.getElementById('redoBtn');
    
    if (undoBtn) undoBtn.disabled = true;
    if (redoBtn) redoBtn.disabled = true;

    const saveState = () => {
        if (isSavingState) {
            redoStack.length = 0;
            undoStack.push(canvas.toDatalessJSON());
            if (undoBtn) undoBtn.disabled = false;
            if (redoBtn) redoBtn.disabled = true;
        }
    };
    canvas.on('object:added', saveState);
    canvas.on('object:modified', saveState);
    canvas.on('object:removed', saveState);

    const replayState = (stack, targetStack) => {
        if (stack.length > 0) {
            isSavingState = false;
            targetStack.push(canvas.toDatalessJSON());
            const stateToLoad = stack.pop();
            canvas.loadFromJSON(stateToLoad, () => {
                canvas.renderAll();
                isSavingState = true;
                if (undoBtn) undoBtn.disabled = undoStack.length === 0;
                if (redoBtn) redoBtn.disabled = redoStack.length === 0;
            });
        }
    };
    
    if (undoBtn) undoBtn.addEventListener('click', () => replayState(undoStack, redoStack));
    if (redoBtn) redoBtn.addEventListener('click', () => replayState(redoStack, undoStack));

    const addTextBtn = document.getElementById('addTextBtn');
    if (addTextBtn) {
        addTextBtn.addEventListener('click', () => {
            const text = new fabric.IText('Your Text Here', { left: 50, top: 50, fontFamily: 'Arial', fontSize: 40, fill: '#000000' });
            canvas.add(text).setActiveObject(text);
        });
    }

    const addImageBtn = document.getElementById('addImageBtn');
    const imageObjectUpload = document.getElementById('imageObjectUpload');
    
    if (addImageBtn) addImageBtn.addEventListener('click', () => imageObjectUpload?.click());
    if (imageObjectUpload) {
        imageObjectUpload.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (event) => {
                    fabric.Image.fromURL(event.target.result, (img) => {
                        img.scaleToWidth(canvas.width / 4);
                        canvas.add(img).centerObject(img).setActiveObject(img);
                    });
                };
                reader.readAsDataURL(file);
            }
            e.target.value = '';
        });
    }
    
    const shapeGallery = document.querySelector('.shape-gallery');
    if (shapeGallery) {
        shapeGallery.addEventListener('click', (e) => {
            const shapeIcon = e.target.closest('.shape-icon');
            if (!shapeIcon) return;
            const shapeType = shapeIcon.dataset.shape;
            let shape = null;
            const commonProps = { left: canvas.width / 2, top: canvas.height / 2, fill: '#007bff', originX: 'center', originY: 'center' };
            switch(shapeType) {
                case 'rectangle': shape = new fabric.Rect({ ...commonProps, width: 150, height: 100 }); break;
                case 'circle': shape = new fabric.Circle({ ...commonProps, radius: 50 }); break;
                case 'triangle': shape = new fabric.Triangle({ ...commonProps, width: 100, height: 100 }); break;
                case 'star': shape = new fabric.Polygon([ { x: 0, y: -50 }, { x: 12, y: -15 }, { x: 48, y: -15 }, { x: 19, y: 8 }, { x: 29, y: 42 }, { x: 0, y: 20 }, { x: -29, y: 42 }, { x: -19, y: 8 }, { x: -48, y: -15 }, { x: -12, y: -15 } ], commonProps); break;
                case 'right-triangle': shape = new fabric.Polygon([{x: -50, y: -50}, {x: -50, y: 50}, {x: 50, y: 50}], commonProps); break;
                case 'hexagon': shape = new fabric.Polygon([ { x: -50, y: -28.8 }, { x: 0, y: -57.7 }, { x: 50, y: -28.8 }, { x: 50, y: 28.8 }, { x: 0, y: 57.7 }, { x: -50, y: 28.8 } ], commonProps); break;
                case 'heart': const heartPath = 'M 0 -25 C -10 -35, -30 -25, -30 0 C -30 25, -10 35, 0 50 C 10 35, 30 25, 30 0 C 30 -25, 10 -35, 0 -25 Z'; shape = new fabric.Path(heartPath, commonProps); shape.scaleToWidth(100); break;
                case 'arrow-right': shape = new fabric.Polygon([ { x: -50, y: -25 }, { x: 0, y: -25 }, { x: 0, y: -50 }, { x: 50, y: 0 }, { x: 0, y: 50 }, { x: 0, y: 25 }, { x: -50, y: 25 } ], commonProps); break;
            }
            if(shape) canvas.add(shape).setActiveObject(shape);
        });
    }

    const anchoredToolbar = document.getElementById('anchored-toolbar');
    const textTools = document.getElementById('text-tools');
    const shapeTools = document.getElementById('shape-tools');

    function updateToolbar() {
        const activeObj = canvas.getActiveObject();
        if (!activeObj) {
            if (anchoredToolbar) anchoredToolbar.style.display = 'none';
            return;
        }
        if (anchoredToolbar) anchoredToolbar.style.display = 'flex';
        // ... (full toolbar update logic)
    }
    canvas.on({'selection:created': updateToolbar, 'selection:updated': updateToolbar, 'selection:cleared': updateToolbar });
    
    const deleteBtn = document.getElementById('deleteBtn');
    if (deleteBtn) {
        deleteBtn.addEventListener('click', () => {
            const activeObjects = canvas.getActiveObjects();
            if (activeObjects.length) {
                activeObjects.forEach(obj => canvas.remove(obj));
                canvas.discardActiveObject().renderAll();
            }
        });
    }

    // --- FINAL EVENT LISTENER ATTACHMENTS ---
    voiceLoaderPromise = fetchAndCacheVoices();
    const scriptModal = document.getElementById('scriptGeneratorModal');
    let scriptModalInstance;
    if (scriptModal) {
        scriptModalInstance = new bootstrap.Modal(scriptModal);
    }
    
    const generateScriptBtn = document.getElementById('generateScriptBtn');
    const generateAudioBtn = document.getElementById('generateAudioBtn');
    const generateImageBtn = document.getElementById('generateImageBtn');
    const addSpeakerBtn = document.getElementById('addSpeakerBtn');
    
    if (generateScriptBtn) generateScriptBtn.addEventListener('click', function() { generateScript(this); });
    if (generateAudioBtn) generateAudioBtn.addEventListener('click', function() { generateFullAudio(this); });
    if (generateImageBtn) generateImageBtn.addEventListener('click', handleGenerateImage);
    if (addSpeakerBtn) addSpeakerBtn.addEventListener('click', addSpeakerRow);

    const acceptScriptBtn = document.getElementById('acceptScriptBtn');
    if (acceptScriptBtn) {
        acceptScriptBtn.addEventListener('click', async function() {
            if (!window.structuredScript) {
                showFeedback('No script available to accept.', 'error');
                return;
            }
            const scriptResultEditor = document.getElementById('script-result-area');
            if (scriptResultEditor) {
                const displayText = window.structuredScript.map(
                    line => (line.speaker ? `<div><strong>${line.speaker}:</strong> ${line.text.replace(/<[^>]+>/g, ' ')}</div>` : `<div>${line.text.replace(/<[^>]+>/g, ' ')}</div>`)
                ).join('');
                scriptResultEditor.innerHTML = displayText;
            }
            
            const scriptGeneratedEvent = new CustomEvent('script-generated');
            document.dispatchEvent(scriptGeneratedEvent);
            await detectSpeakersAndMapVoices(window.structuredScript);
            showFeedback('Script accepted and ready for audio generation.', 'success');
            if (scriptModalInstance) scriptModalInstance.hide();
        });
    }

    const rejectScriptBtn = document.getElementById('rejectScriptBtn');
    if (rejectScriptBtn) {
        rejectScriptBtn.addEventListener('click', function() {
            window.structuredScript = null;
            const scriptGeneratorForm = document.getElementById('script-generator-form');
            const scriptPreviewDiv = document.getElementById('scriptPreviewDiv');
            const generateFooterButtons = document.getElementById('generate-footer-buttons');
            const previewFooterButtons = document.getElementById('preview-footer-buttons');
            
            if (scriptGeneratorForm) scriptGeneratorForm.style.display = 'block';
            if (scriptPreviewDiv) scriptPreviewDiv.style.display = 'none';
            if (generateFooterButtons) generateFooterButtons.style.display = 'block';
            if (previewFooterButtons) previewFooterButtons.style.display = 'none';
        });
    }
    
    if(scriptModal) {
        scriptModal.addEventListener('hidden.bs.modal', function () {
            const scriptGeneratorForm = document.getElementById('script-generator-form');
            const scriptPreviewDiv = document.getElementById('scriptPreviewDiv');
            const generateFooterButtons = document.getElementById('generate-footer-buttons');
            const previewFooterButtons = document.getElementById('preview-footer-buttons');
            
            if (scriptGeneratorForm) scriptGeneratorForm.style.display = 'block';
            if (scriptPreviewDiv) scriptPreviewDiv.style.display = 'none';
            if (generateFooterButtons) generateFooterButtons.style.display = 'block';
            if (previewFooterButtons) previewFooterButtons.style.display = 'none';
        });
    }
    
    const voiceConfigContainer = document.getElementById('voice-config-container');
    if (voiceConfigContainer) {
        voiceConfigContainer.addEventListener('click', function(event) {
            const previewButton = event.target.closest('.btn-preview-voice');
            if (previewButton) { previewVoice(previewButton); return; }
            const removeButton = event.target.closest('.btn-remove-speaker');
            if (removeButton) {
                removeButton.closest('.voice-config-row')?.remove();
                if (voiceConfigContainer.querySelectorAll('.voice-config-row').length === 1) {
                    const remainingRemoveBtn = voiceConfigContainer.querySelector('.btn-remove-speaker');
                    if (remainingRemoveBtn) remainingRemoveBtn.disabled = true;
                }
            }
        });
    }

    const audioResultsList = document.querySelector('.audio-results-list');
    let currentlyPlaying = { audio: null, icon: null };
    if (audioResultsList) {
        audioResultsList.addEventListener('click', function(event) {
            const playButton = event.target.closest('.btn-play-result');
            if (playButton) {
                const resultItem = playButton.closest('.audio-result-item');
                const audioElement = resultItem.querySelector('audio');
                const icon = playButton.querySelector('i');
                
                if (currentlyPlaying.audio && !currentlyPlaying.audio.paused) {
                    currentlyPlaying.audio.pause();
                    currentlyPlaying.icon.className = 'fas fa-play';
                }
                
                if (audioElement.paused) {
                    audioElement.play();
                    icon.className = 'fas fa-pause';
                    currentlyPlaying = { audio: audioElement, icon: icon };
                    
                    audioElement.onended = () => {
                        icon.className = 'fas fa-play';
                        currentlyPlaying = { audio: null, icon: null };
                    };
                } else {
                    audioElement.pause();
                    icon.className = 'fas fa-play';
                    currentlyPlaying = { audio: null, icon: null };
                }
                return;
            }
            
            const deleteButton = event.target.closest('.btn-delete-result');
            if (deleteButton) {
                if (confirm('Are you sure you want to delete this audio file?')) {
                    const resultItem = deleteButton.closest('.audio-result-item');
                    const audioUrl = resultItem.getAttribute('data-audio-url');
                    
                    fetch(`${window.APP_BASE_URL}api/delete-audio.php`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ audioUrl: audioUrl })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            resultItem.remove();
                            showFeedback('Audio file deleted successfully.', 'success');
                        } else {
                            showFeedback('Failed to delete audio file.', 'error');
                        }
                    })
                    .catch(error => {
                        console.error('Delete error:', error);
                        showFeedback('Error deleting audio file.', 'error');
                    });
                }
            }
        });
    }

    const layoutSelect = document.getElementById('layoutSelect');
    const layoutPreviewFrame = document.getElementById('layoutPreviewFrame');
    const layoutPreviewPlaceholder = document.getElementById('layoutPreviewPlaceholder');

    function updateLayoutPreview() {
        if (!layoutSelect) return;
        const selectedOption = layoutSelect.options[layoutSelect.selectedIndex];
        const templatePath = selectedOption.dataset.templateFile;

        if (templatePath) {
            const fullUrl = window.APP_BASE_URL + templatePath;
            if (layoutPreviewFrame) {
                layoutPreviewFrame.src = fullUrl;
                layoutPreviewFrame.style.display = 'block';
            }
            if (layoutPreviewPlaceholder) layoutPreviewPlaceholder.style.display = 'none';
        } else {
            if (layoutPreviewFrame) {
                layoutPreviewFrame.src = 'about:blank';
                layoutPreviewFrame.style.display = 'none';
            }
            if (layoutPreviewPlaceholder) layoutPreviewPlaceholder.style.display = 'block';
        }
    }

    if (layoutSelect) {
        layoutSelect.addEventListener('change', updateLayoutPreview);
        updateLayoutPreview();
    }
});
