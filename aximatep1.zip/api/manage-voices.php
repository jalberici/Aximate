<?php
/*******************************************************************************
 * Service:        Manages Custom Voices (Full CRUD)
 * Version:        2.2.0 (DEFINITIVE FIX: FormData Compatibility)
 * Date:           2025-08-28
 * Last Author:    [Gemini]
 *
 * Description:    This version is updated to correctly handle 'FormData'
 *                 submissions (multipart/form-data) which are required for
 *                 file uploads. It now reads input from the $_POST superglobal
 *                 for the 'add_voice' action, resolving the "Invalid action"
 *                 error. It retains JSON handling for the 'delete_voice' action.
 ******************************************************************************/
require_once '../config/config.php';
header('Content-Type: application/json');

try {
    $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($mysqli->connect_error) { throw new Exception('Database connection failed.'); }
    
    // Determine the action from either POST data or a JSON payload
    $action = '';
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
    } else {
        $input = json_decode(file_get_contents('php://input'), true);
        $action = isset($input['action']) ? $input['action'] : '';
    }

    $response = array('success' => false, 'error' => 'Invalid action.');

    if ($action === 'add_voice') {
        // --- ADD VOICE LOGIC (Now reads from $_POST) ---
        $project_id = isset($_POST['project_id']) ? (int)$_POST['project_id'] : 0;
        $voice_name = isset($_POST['voice_name']) ? trim($_POST['voice_name']) : '';
        $voice_id = isset($_POST['voice_id']) ? trim($_POST['voice_id']) : '';
        $provider = isset($_POST['provider']) ? trim($_POST['provider']) : '';
        $language_code = isset($_POST['language_code']) ? trim($_POST['language_code']) : '';
        $description = isset($_POST['description']) ? trim($_POST['description']) : '';
        $preview_url = '';

        if (empty($project_id) || empty($voice_name) || empty($voice_id) || empty($provider) || empty($language_code)) {
            throw new Exception('Missing required fields.');
        }
        
        // --- Handle File Upload ---
        if (isset($_FILES['preview_audio']) && $_FILES['preview_audio']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['preview_audio'];
            $uploadDir = dirname(__DIR__) . '/audio_outputs/previews/';
            if (!is_dir($uploadDir)) { @mkdir($uploadDir, 0755, true); }
            
            $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            if ($fileExtension !== 'mp3') { throw new Exception('Invalid file type. Only .mp3 is allowed.'); }

            $sanitizedFilename = 'preview_' . $project_id . '_' . preg_replace('/[^a-zA-Z0-9_-]/', '_', $voice_id) . '_' . time() . '.mp3';
            $filepath = $uploadDir . $sanitizedFilename;

            if (move_uploaded_file($file['tmp_name'], $filepath)) {
                $preview_url = 'audio_outputs/previews/' . $sanitizedFilename;
            } else {
                throw new Exception('Failed to save uploaded preview file.');
            }
        } else {
            throw new Exception('Preview audio file is required or there was an upload error.');
        }

        // Check for duplicates first
        $stmt = $mysqli->prepare("SELECT id FROM custom_voices WHERE project_id = ? AND voice_id = ?");
        $stmt->bind_param("is", $project_id, $voice_id);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            throw new Exception('This Voice ID has already been added to this project.');
        }
        $stmt->close();

        // If no duplicate, proceed with insert
        $stmt = $mysqli->prepare("INSERT INTO custom_voices (project_id, voice_name, voice_id, provider, language_code, description, preview_url) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("issssss", $project_id, $voice_name, $voice_id, $provider, $language_code, $description, $preview_url);
        
        if ($stmt->execute()) {
            $response = array('success' => true, 'message' => 'Custom voice added successfully.');
        } else {
            throw new Exception('Database execute failed: ' . $stmt->error);
        }
        $stmt->close();

    } elseif ($action === 'delete_voice') {
        // --- DELETE VOICE LOGIC (Remains unchanged, still uses JSON) ---
        $custom_voice_db_id = isset($input['id']) ? (int)$input['id'] : 0;
        $project_id = isset($input['project_id']) ? (int)$input['project_id'] : 0;

        if (empty($custom_voice_db_id) || empty($project_id)) {
            throw new Exception('Missing ID for deletion.');
        }

        $stmt = $mysqli->prepare("DELETE FROM custom_voices WHERE id = ? AND project_id = ?");
        $stmt->bind_param("ii", $custom_voice_db_id, $project_id);

        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                $response = array('success' => true, 'message' => 'Voice deleted successfully.');
            } else {
                throw new Exception('Voice not found or you do not have permission to delete it.');
            }
        } else {
            throw new Exception('Database delete failed: ' . $stmt->error);
        }
        $stmt->close();

    } else {
        $response['error'] = 'Invalid action specified.';
    }

    $mysqli->close();
    echo json_encode($response);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(array('success' => false, 'error' => $e->getMessage()));
}
?>