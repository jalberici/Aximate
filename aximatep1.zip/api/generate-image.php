<?php
/*******************************************************************************
 * Company:        [Inroads, LLC]
 * Version:        67.0.2 (Surgically Corrected Path)
 * Date:           2025-08-24
 * Last Author:    [Gemini]
 *
 * Description:    Surgically corrected the directory path from 'save_images'
 *                 to 'saved_images' to match the application's structure.
 ******************************************************************************/

ini_set('display_errors', 1);
error_reporting(E_ALL);
set_time_limit(300);

require_once '../config/config.php';

function log_image_error($message) {
    $log_dir = dirname(__DIR__) . '/logs/';
    if (!is_dir($log_dir)) { @mkdir($log_dir, 0755, true); }
    @file_put_contents($log_dir . 'image_gen_error.log', date('Y-m-d H:i:s') . " - " . $message . "\n", FILE_APPEND);
}

header('Content-Type: application/json');

if (!defined('STABILITY_API_KEY') || !defined('STABILITY_API_ENDPOINT') || !defined('STABILITY_IMAGE_DIMENSIONS')) {
    http_response_code(503);
    log_image_error('FATAL: Stability AI constants not defined in config.php.');
    echo json_encode(['error' => 'Server Configuration Error for Image Generation.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON payload.']);
    exit;
}

$prompt = isset($input['prompt']) ? trim($input['prompt']) : '';
$requested_width = isset($input['width']) ? (int)$input['width'] : 1024;
$requested_height = isset($input['height']) ? (int)$input['height'] : 1024;
$projectId = isset($input['projectId']) ? (int)$input['projectId'] : 0;

if (empty($prompt)) { http_response_code(400); echo json_encode(['error' => 'Prompt is required.']); exit; }
if ($projectId === 0) { http_response_code(400); echo json_encode(['error' => 'Project ID is required.']); exit; }

try {
    // --- Intelligent Dimension Selection (unchanged) ---
    $supported_dims_str = STABILITY_IMAGE_DIMENSIONS;
    $supported_dims_array = explode(',', $supported_dims_str);
    $final_width = 1024;
    $final_height = 1024;

    $requested_dim_str = "{$requested_width}x{$requested_height}";

    if (in_array($requested_dim_str, $supported_dims_array)) {
        $final_width = $requested_width;
        $final_height = $requested_height;
    } else {
        $min_diff = PHP_INT_MAX;
        $requested_area = $requested_width * $requested_height;
        foreach ($supported_dims_array as $dim) {
            list($w, $h) = explode('x', $dim);
            $supported_area = (int)$w * (int)$h;
            $diff = abs($requested_area - $supported_area);
            if ($diff < $min_diff) {
                $min_diff = $diff;
                $final_width = (int)$w;
                $final_height = (int)$h;
            }
        }
    }

    $payload = json_encode([
        'text_prompts' => [['text' => $prompt]],
        'cfg_scale' => 7,
        'height' => $final_height,
        'width' => $final_width,
        'samples' => 1,
        'steps' => 30
    ]);

    $ch = curl_init(STABILITY_API_ENDPOINT);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_TIMEOUT => 240,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Accept: application/json',
            'Authorization: Bearer ' . STABILITY_API_KEY
        ]
    ]);

    $response_body = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($curl_error) { throw new Exception('cURL Error: ' . $curl_error); }
    if ($http_code !== 200) {
        log_image_error("Stability API Error (HTTP {$http_code}): " . $response_body);
        throw new Exception('The AI Image Service returned an error.');
    }

    $api_response = json_decode($response_body, true);
    if (json_last_error() !== JSON_ERROR_NONE || !isset($api_response['artifacts'][0]['base64'])) {
        log_image_error("Invalid Stability AI Response JSON: " . $response_body);
        throw new Exception('Invalid response structure from the AI image service.');
    }

    $b64_image = $api_response['artifacts'][0]['base64'];
    $decoded_image = base64_decode($b64_image);

    if ($decoded_image === false) { throw new Exception('Failed to decode base64 image data from API.'); }

    // --- CORRECTED: Save to saved_images/ (plural) ---
    $outputDir = dirname(__DIR__) . '/saved_images/' . $projectId . '/';
    if (!is_dir($outputDir)) {
        if (!mkdir($outputDir, 0755, true)) { throw new Exception('Server error: Failed to create saved_images directory.'); }
    }

    $filename = 'ai_image_' . time() . '.png';
    $filepath = $outputDir . $filename;

    if (file_put_contents($filepath, $decoded_image) === false) {
        throw new Exception('Server error: Failed to save image to server.');
    }

  // --- CORRECTED: Return a relative URL consistent with the rest of the app ---
  $imageUrl = 'saved_images/' . $projectId . '/' . $filename;

    echo json_encode(['success' => true, 'imageUrl' => $imageUrl]);

} catch (Exception $e) {
    http_response_code(500);
    log_image_error($e->getMessage());
    echo json_encode(['error' => $e->getMessage()]);
}
?>