<?php
/*******************************************************************************
 * Company:        [Inroads, LLC]
 * Copyright:      (c) [2025] [Inroads, LLC]. All rights reserved.
 * Version:        147.1.0 (STABLE & FINAL - Output Buffering Fix)
 * Date:           2025-09-02
 * Last Author:    [Gemini]
 *
 * Description:    This is the definitive, stable version. It introduces
 *                 output buffering (ob_start/ob_end_clean) to prevent any
 *                 stray HTML from included files from breaking the JSON
 *                 output. All other logic for Google and Hume is correct.
 ******************************************************************************/

// --- START: DEFINITIVE FIX FOR STRAY HTML ---
// Start output buffering to catch any stray whitespace or HTML from includes
ob_start();
// --- END: DEFINITIVE FIX FOR STRAY HTML ---

ini_set('display_errors', 0);
error_reporting(E_ALL);

// --- DEPENDENCIES ---
require_once dirname(dirname(__FILE__)) . '/vendor/autoload.php';
use Google\Cloud\TextToSpeech\V1\TextToSpeechClient;
use Google\Cloud\TextToSpeech\V1\SsmlVoiceGender;

// --- CONFIG ---
$config_path = dirname(dirname(__FILE__)) . '/config/config.php';
if (!file_exists($config_path)) {
    http_response_code(500);
    echo '{"success": false, "error": "Server configuration file is missing."}';
    exit;
}
require_once $config_path;

// --- CONTROL PANELS ---
$languageCategories = array(
    'English' => array('en-AU', 'en-GB', 'en-IN', 'en-US'),
    'European - West' => array('fr-FR', 'fr-CA', 'de-DE', 'it-IT', 'nl-NL'),
    'European - Iberian' => array('pt-BR', 'pt-PT', 'es-ES', 'es-US', 'ca-ES'),
    'European - North' => array('da-DK', 'fi-FI', 'nb-NO', 'sv-SE'),
    'European - East' => array('bg-BG', 'cs-CZ', 'el-GR', 'hr-HR', 'hu-HU', 'lt-LT', 'lv-LV', 'pl-PL', 'ro-RO', 'ru-RU', 'sk-SK', 'sr-RS', 'uk-UA'),
    'Asian - East' => array('ja-JP', 'ko-KR', 'zh-CN', 'yue-HK', 'zh-TW'),
    'Asian - South & SE' => array('bn-IN', 'fil-PH', 'gu-IN', 'hi-IN', 'id-ID', 'kn-IN', 'km-KH', 'ml-IN', 'ms-MY', 'ta-IN', 'te-IN', 'th-TH', 'vi-VN'),
    'Global & Other' => array('af-ZA', 'ar-XA', 'he-IL', 'tr-TR')
);
$voicePlanTiers = array(
    'AxiMate-Standard'   => array('isPremium' => false, 'isActive' => true, 'sortOrder' => 1, 'icon' => '&#11088;'),
    'AxiMate-Provoice 1' => array('isPremium' => true,  'isActive' => true, 'sortOrder' => 2, 'icon' => '&#128081;'),
    'AxiMate-Provoice 2' => array('isPremium' => true,  'isActive' => true, 'sortOrder' => 3, 'icon' => '&#128081;'),
    'AxiMate-Premium-1'  => array('isPremium' => true,  'isActive' => true, 'sortOrder' => 4, 'icon' => '&#128081;&#128081;'),
    'AxiMate-Premium-4'  => array('isPremium' => true,  'isActive' => true, 'sortOrder' => 5, 'icon' => '&#128081;&#128081;'),
    'AxiMate-Premium-5'  => array('isPremium' => true,  'isActive' => true, 'sortOrder' => 6, 'icon' => '&#128081;&#128081;'),
    'AxiMate-Premium-6'  => array('isPremium' => true,  'isActive' => true, 'sortOrder' => 7, 'icon' => '&#128081;&#128081;')
);
$brandNameMap = array( /* Placeholder for user-provided list */ );

// --- UTILITY FUNCTIONS ---
function send_error($message) {
    http_response_code(500);
    echo json_encode(array('success' => false, 'error' => $message));
    exit;
}

function classifyGoogleVoice($voiceName) {
    $nameLower = strtolower($voiceName);
    if (strpos($nameLower, 'chirp') !== false || strpos($nameLower, 'studio') !== false) return 'AxiMate-Premium-1';
    if (strpos($nameLower, 'polyglot') !== false) return 'AxiMate-Premium-5';
    if (strpos($nameLower, 'news') !== false) return 'AxiMate-Premium-6';
    if (strpos($nameLower, 'casual') !== false) return 'AxiMate-Premium-4';
    if (strpos($nameLower, 'neural2') !== false) return 'AxiMate-Provoice 2';
    if (strpos($nameLower, 'wavenet') !== false) return 'AxiMate-Provoice 1';
    return 'AxiMate-Standard';
}

function createBrandedLabel($voiceName, $genderName, $groupInfo) {
    global $brandNameMap;
    $finalName = isset($brandNameMap[$voiceName]) ? $brandNameMap[$voiceName] : $voiceName;
    $typeAbbreviation = 'Sta';
    if (strpos($voiceName, 'Wavenet') !== false) $typeAbbreviation = 'Wav';
    if (strpos($voiceName, 'News') !== false) $typeAbbreviation = 'New';
    if (strpos($voiceName, 'Casual') !== false) $typeAbbreviation = 'Cas';
    if (strpos($voiceName, 'Neural2') !== false) $typeAbbreviation = 'Neu';
    if (strpos($voiceName, 'Studio') !== false || strpos($voiceName, 'Chirp') !== false) $typeAbbreviation = 'Chi';
    if (strpos($voiceName, 'Polyglot') !== false) $typeAbbreviation = 'Pol';
    $parts = explode('-', $voiceName);
    $langCode = $parts[0] . '-' . $parts[1];
    $icon = $groupInfo['icon'];
    return $icon . ' ' . $langCode . '-' . $typeAbbreviation . ' | ' . $genderName . ' (' . $finalName . ')';
}

function get_google_gender($ssmlGender, $voiceName) {
    if ($ssmlGender == SsmlVoiceGender::MALE) return 'Male';
    if ($ssmlGender == SsmlVoiceGender::FEMALE) return 'Female';
    return 'Unknown';
}

function getLanguageCategory($langCode) {
    global $languageCategories;
    foreach ($languageCategories as $category => $codes) {
        if (in_array($langCode, $codes)) return $category;
    }
    return 'Global & Other';
}

// --- VOICE FETCHING FUNCTIONS ---
function fetch_google_voices() {
    global $voicePlanTiers;
    try {
        if (!defined('GOOGLE_APPLICATION_CREDENTIALS') || !file_exists(GOOGLE_APPLICATION_CREDENTIALS)) { return array(); }
        $textToSpeechClient = new TextToSpeechClient(array('credentials' => GOOGLE_APPLICATION_CREDENTIALS));
        $response = $textToSpeechClient->listVoices();
        $voices = $response->getVoices();
        $output_voices = array();

        foreach ($voices as $voice) {
            $voiceName = $voice->getName();
            $parts = explode('-', $voiceName);
            if (count($parts) < 3) continue;
            $langCode = $parts[0] . '-' . $parts[1];
            $groupName = classifyGoogleVoice($voiceName);
            if (!isset($voicePlanTiers[$groupName])) continue;
            $tierInfo = $voicePlanTiers[$groupName];
            $genderName = get_google_gender($voice->getSsmlGender(), $voiceName);
            $label = createBrandedLabel($voiceName, $genderName, $tierInfo);

            $output_voices[] = array( 
                'id' => $voiceName, 'label' => $label, 'is_custom' => false, 'provider' => 'google', 
                'gender' => $genderName, 'lang_code' => $langCode, 'lang_category' => getLanguageCategory($langCode),
                'category' => $groupName, 'isDisabled' => !$tierInfo['isActive'], 'sortOrder' => $tierInfo['sortOrder']
            );
        }
        $textToSpeechClient->close();

        usort($output_voices, function($a, $b) {
            if ($a['sortOrder'] == $b['sortOrder']) { return strcmp($a['id'], $b['id']); }
            return ($a['sortOrder'] < $b['sortOrder']) ? -1 : 1;
        });

        return $output_voices;
    } catch (Exception $e) {
        error_log("AxiMate get-voices.php Google Fetch ERROR: " . $e->getMessage());
        return array();
    }
}

function fetch_hume_voices() {
    if (!defined('HUME_API_KEY') || HUME_API_KEY === '') { return array(); }
    function guess_hume_gender($voice_name) {
        $name_lower = strtolower($voice_name);
        $female_keywords = array('female', 'woman', 'lady', 'girl', 'geraldine', 'wallace', 'imani', 'carter', 'elizabeth', 'pembroke', 'ava', 'song', 'demure', 'welsh lady', 'caring mother', 'inspiring woman', 'mysterious woman', 'expressive girl', 'seasoned midwestern actress', 'classical film actress', 'warm american female', 'american lead actress', 'indian actress', 'aunt tea', 'anna', 'kora', 'alice bennett');
        $male_keywords = array('male', 'man', 'guy', 'master', 'troll', 'protagonist', 'crier', 'podcast host', 'announcer', 'priest', 'captain', 'sad old british', 'scottish', 'wrestling', 'peasant man', 'bentley', 'lockwood', 'sinclair', 'narrator', 'awe inspired', 'sir spandrel', 'dramatic movie', 'vince douglas', 'campfire', 'tiktok', 'naturalist', 'children\'s book', 'conversationalist', 'irishman', 'kiwi guy', 'brooding intellectual', 'grizzled new yorker', 'opinionated', 'classical film actor', 'inspiring older', 'comedian', 'sitcom', 'yorkshire chap', 'indian actor', 'frat bro', 'colorful fashion', 'excitable british', 'steve frisch', 'podcaster', 'fastidious robo-butler', 'leon', 'ito', 'joseph alberici', 'unserious movie trailer');
        foreach ($female_keywords as $keyword) { if (strpos($name_lower, $keyword) !== false) return 'Female'; }
        foreach ($male_keywords as $keyword) { if (strpos($name_lower, $keyword) !== false) return 'Male'; }
        return 'Unknown';
    }
    $all_hume_voices = array();
    $hume_providers = array('HUME_AI' => 'hume_standard', 'CUSTOM_VOICE' => 'hume_custom');
    foreach ($hume_providers as $api_provider => $output_provider_tag) {
        $page_number = 0; $total_pages = 1;
        while ($page_number < $total_pages) {
            try {
                $endpoint = 'https://api.hume.ai/v0/tts/voices?provider=' . $api_provider . '&page_number=' . $page_number;
                $ch = curl_init();
                curl_setopt_array($ch, array(CURLOPT_URL => $endpoint, CURLOPT_RETURNTRANSFER => true, CURLOPT_HTTPHEADER => array('X-Hume-Api-Key: ' . HUME_API_KEY), CURLOPT_TIMEOUT => 30));
                $response_data = curl_exec($ch);
                $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                if ($http_code !== 200) { break; }
                $decoded_response = json_decode($response_data, true);
                if (json_last_error() !== JSON_ERROR_NONE) { break; }
                $voices_page = isset($decoded_response['voices_page']) ? $decoded_response['voices_page'] : array();
                foreach ($voices_page as $voice) {
                    if (isset($voice['id']) && isset($voice['name'])) {
                        $gender = guess_hume_gender($voice['name']);
                        $label = $voice['name'] . ' (' . $gender . ')';
                        $all_hume_voices[] = array('id' => $voice['id'], 'name' => $voice['name'], 'label' => $label, 'is_custom' => ($output_provider_tag === 'hume_custom'), 'provider' => $output_provider_tag, 'gender' => $gender);
                    }
                }
                if ($page_number === 0) { $total_pages = isset($decoded_response['total_pages']) ? (int)$decoded_response['total_pages'] : 1; }
                $page_number++;
            } catch (Exception $e) { break; }
        }
    }
    return $all_hume_voices;
}

// --- MAIN ROUTING ---
$provider = isset($_GET['provider']) ? $_GET['provider'] : 'google';
$final_data = array();

if ($provider === 'google') {
    $final_data = array(
        'voices' => fetch_google_voices(),
        'languageCategories' => $GLOBALS['languageCategories'],
        'languageLegend' => $GLOBALS['languageLegend'],
        'voiceTierLegend' => $GLOBALS['voiceTierLegend']
    );
} elseif ($provider === 'hume') {
    $final_data = array(
        'voices' => fetch_hume_voices()
    );
} else {
    send_error('Invalid provider specified.');
}

// --- FINAL JSON OUTPUT ---
// Clear the buffer of any stray output before sending the final JSON
ob_end_clean();
header('Content-Type: application/json; charset=utf-8');
echo json_encode($final_data, JSON_UNESCAPED_UNICODE);
exit;

?>