<?php
/*******************************************************************************
 * Company:        [Inroads, LLC]
 * Copyright:      (c) [2025] [Inroads, LLC]. All rights reserved.
 * Version:        1.0.0 // Handles secure template processing and generation
 * Date:           2025-07-28
 * Last Author:    [AI Assistant]
 *
 * Description:    Receives branding data, loads a base template, securely
 *                 replaces placeholders, and saves a new, customized HTML file.
 ******************************************************************************/

header('Content-Type: application/json');

// --- SECURITY: Define a whitelist of allowed templates to prevent path traversal attacks ---
$allowed_templates = array(
    'blue-modern' => 'web_templates/blue_modern.html',
    'dark-elegance' => 'web_templates/dark_elegance.html',
    'fresh-green' => 'web_templates/fresh_green.html',
    'vivid-purple' => 'web_templates/vivid_purple.html',
    'minimalist-gray' => 'web_templates/minimalist_gray.html'
);

// --- Directory Setup ---
$base_dir = dirname(__DIR__); // Assumes this script is in an 'api' folder.
$generated_dir = $base_dir . '/generated_pages/';
if (!is_dir($generated_dir)) {
    if (!mkdir($generated_dir, 0755, true)) {
        http_response_code(500);
        echo json_encode(array('error' => 'Failed to create generated_pages directory. Check permissions.'));
        exit;
    }
}

// --- Input Processing ---
$input = file_get_contents('php://input');
$data = json_decode($input, true);
if (json_last_error() !== JSON_ERROR_NONE || !$data) {
    http_response_code(400);
    echo json_encode(array('error' => 'Invalid JSON payload.'));
    exit;
}

// --- Validation and Sanitization ---
$template_key = isset($data['templateKey']) ? $data['templateKey'] : '';
$project_name = isset($data['projectName']) && !empty($data['projectName']) ? $data['projectName'] : 'untitled-project';

// SECURITY: Ensure the requested template is in our whitelist
if (!isset($allowed_templates[$template_key])) {
    http_response_code(400);
    echo json_encode(array('error' => 'Invalid template selected.'));
    exit;
}

$template_path = $base_dir . '/' . $allowed_templates[$template_key];

if (!file_exists($template_path)) {
    http_response_code(404);
    echo json_encode(array('error' => 'Template file not found on server.'));
    exit;
}

// --- Sanitize all user-provided branding data to prevent XSS ---
$placeholders = array();
$branding_data = isset($data['brandingData']) ? $data['brandingData'] : array();

// Use htmlspecialchars on all text-based content
$placeholders['{{HERO_MESSAGE}}'] = htmlspecialchars(isset($branding_data['hero-message']) ? $branding_data['hero-message'] : '', ENT_QUOTES, 'UTF-8');
$placeholders['{{AUDIO_TITLE}}'] = htmlspecialchars(isset($branding_data['audio-title']) ? $branding_data['audio-title'] : '', ENT_QUOTES, 'UTF-8');
$placeholders['{{COMPANY_NAME}}'] = htmlspecialchars(isset($branding_data['company-name']) ? $branding_data['company-name'] : '', ENT_QUOTES, 'UTF-8');
$placeholders['{{COMPANY_PHONE}}'] = htmlspecialchars(isset($branding_data['company-phone']) ? $branding_data['company-phone'] : '', ENT_QUOTES, 'UTF-8');
$placeholders['{{COMPANY_EMAIL}}'] = htmlspecialchars(isset($branding_data['company-email']) ? $branding_data['company-email'] : '', ENT_QUOTES, 'UTF-8');
$placeholders['{{COMPANY_ADDRESS}}'] = htmlspecialchars(isset($branding_data['company-address']) ? $branding_data['company-address'] : '', ENT_QUOTES, 'UTF-8');
$placeholders['{{PRIMARY_BUTTON_TEXT}}'] = htmlspecialchars(isset($branding_data['primary-button-text']) ? $branding_data['primary-button-text'] : '', ENT_QUOTES, 'UTF-8');
$placeholders['{{SECONDARY_BUTTON_TEXT}}'] = htmlspecialchars(isset($branding_data['secondary-button-text']) ? $branding_data['secondary-button-text'] : '', ENT_QUOTES, 'UTF-8');

// Sanitize URLs to ensure they are safe
$placeholders['{{COMPANY_WEBSITE}}'] = filter_var(isset($branding_data['company-website']) ? $branding_data['company-website'] : '', FILTER_SANITIZE_URL);
$placeholders['{{PRIMARY_BUTTON_LINK}}'] = filter_var(isset($branding_data['primary-button-link']) ? $branding_data['primary-button-link'] : '', FILTER_SANITIZE_URL);
$placeholders['{{SECONDARY_BUTTON_LINK}}'] = filter_var(isset($branding_data['secondary-button-link']) ? $branding_data['secondary-button-link'] : '', FILTER_SANITIZE_URL);

// Handle image data (assuming base64 data URL)
$placeholders['{{BACKGROUND_IMAGE_URL}}'] = isset($branding_data['background-image']) ? $branding_data['background-image'] : '';
$placeholders['{{LOGO_IMAGE_URL}}'] = isset($branding_data['company-logo']) ? $branding_data['company-logo'] : '';


// --- Template Processing ---
$template_content = file_get_contents($template_path);
$final_html = str_replace(array_keys($placeholders), array_values($placeholders), $template_content);

// --- Save Final HTML File ---
$safe_project_name = preg_replace('/[^a-zA-Z0-9_-]/', '_', $project_name);
$output_filename = $safe_project_name . '_' . time() . '.html';
$output_filepath = $generated_dir . $output_filename;

if (file_put_contents($output_filepath, $final_html)) {
    // Calculate the public URL for the new file
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'];
    $path = dirname($_SERVER['SCRIPT_NAME'], 2); // Go up two levels from /api/
    $final_url = rtrim($protocol . $host . $path, '/') . '/generated_pages/' . $output_filename;

    echo json_encode(array(
        'success' => true,
        'message' => 'Webpage updated and saved successfully!',
        'url' => $final_url
    ));
} else {
    http_response_code(500);
    echo json_encode(array('error' => 'Failed to write final HTML file. Check directory permissions.'));
}
?>