<?php
/*******************************************************************************
 * Company:        [Inroads, LLC]
 * Copyright:      (c) [2025] [Inroads, LLC]. All rights reserved.
 * Version:        1.0.0 // Initial release
 * Date:           2025-07-23
 *
 * Description:    Securely deletes a specified image from the saved_images directory.
 ******************************************************************************/

header('Content-Type: application/json');

$upload_dir = '../saved_images/';

$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!isset($data['filename']) || empty($data['filename'])) {
    http_response_code(400);
    echo json_encode(['error' => 'No filename provided.']);
    exit;
}

$filename = $data['filename'];

// SECURITY: Crucial validation to prevent directory traversal attacks.
// We get the real path, ensure it's within our allowed directory, and check the file exists.
$base_path = realpath($upload_dir);
$file_path = realpath($upload_dir . $filename);

if ($file_path === false || strpos($file_path, $base_path) !== 0) {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden: Invalid file path.']);
    exit;
}

if (is_file($file_path)) {
    if (unlink($file_path)) {
        echo json_encode(['success' => true, 'message' => 'Image deleted successfully.']);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Could not delete the file. Check permissions.']);
    }
} else {
    http_response_code(404);
    echo json_encode(['error' => 'File not found.']);
}
?>