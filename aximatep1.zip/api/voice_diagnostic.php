<?php
// This is a diagnostic script. It will test the output of get-voices.php directly.
header('Content-Type: text/plain');
echo "===============================================\n";
echo "AXIMATE VOICE DIAGNOSTIC TOOL\n";
echo "===============================================\n\n";

// --- Configuration ---
// Determine the base URL dynamically
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'];
// Get the path of the current script and go one level up for the base API directory
$path = dirname($_SERVER['PHP_SELF']);
$base_url = rtrim($protocol . $host . $path, '/') . '/';

// Define the URLs to test
$google_voices_url = $base_url . 'get-voices.php?provider=google&lang_code=en-US';
$hume_voices_url = $base_url . 'get-voices.php?provider=hume&lang_code=en-US'; // lang_code is ignored by hume but good to test

// --- Function to perform the test ---
function run_test($url, $description) {
    echo "--- Testing: " . $description . " ---\n";
    echo "Requesting URL: " . $url . "\n\n";

    // Use file_get_contents for simplicity as it's a local request
    $response = @file_get_contents($url);

    if ($response === false) {
        echo "RESULT: FAILED TO FETCH\n";
        echo "The script could not connect to the URL. This might indicate a server configuration issue or a fatal error in get-voices.php.\n";
    } else {
        echo "RAW RESPONSE FROM SCRIPT:\n";
        echo "--------------------------\n";
        echo $response;
        echo "\n--------------------------\n\n";
        
        // Attempt to decode and analyze the JSON
        $data = json_decode($response, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            echo "ANALYSIS: JSON is valid.\n";
            if (isset($data['error'])) {
                echo "ANALYSIS: The script returned an error message: " . htmlspecialchars($data['error']) . "\n";
            } elseif (is_array($data) && !empty($data)) {
                $first_voice_label = isset($data[0]['label']) ? $data[0]['label'] : 'N/A';
                echo "ANALYSIS: Success. Found " . count($data) . " voices.\n";
                echo "ANALYSIS: The first voice returned is: '" . htmlspecialchars($first_voice_label) . "'\n";
            } else {
                echo "ANALYSIS: Response is valid JSON but is empty or has an unknown structure.\n";
            }
        } else {
            echo "ANALYSIS: FAILED. The response is NOT valid JSON. This indicates a PHP error is breaking the output.\n";
        }
    }
    echo "\n\n";
}

// --- Execute Tests ---
run_test($google_voices_url, "Fetch GOOGLE Voices (for en-US)");
run_test($hume_voices_url, "Fetch HUME Voices");

echo "===============================================\n";
echo "DIAGNOSTIC COMPLETE\n";
echo "===============================================\n";

?>