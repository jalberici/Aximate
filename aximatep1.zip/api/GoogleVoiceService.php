<?php
/*******************************************************************************
 * AxiMate Google Voice Service
 * Version: 1.0.0
 * Description: A robust, cache-aware service to fetch, parse, sort, and
 *              format the Google Voice list from a local CSV file.
 *              Built for compatibility with PHP 5.6+
 ******************************************************************************/

/**
 * The main function to get all processed and formatted Google voices.
 * It uses a file-based cache to ensure high performance.
 *
 * @return array The structured array of voices, grouped and sorted.
 */
function getGoogleFormattedVoices() {
    $cache_dir = dirname(__DIR__) . '/cache';
    $cache_file = $cache_dir . '/google_voices.json';
    $cache_lifetime_seconds = 6 * 3600; // 6 hours

    // Create cache directory if it doesn't exist
    if (!is_dir($cache_dir)) {
        mkdir($cache_dir, 0755, true);
    }

    // 1. Check Cache: Return cached data if it's fresh
    if (file_exists($cache_file) && (time() - filemtime($cache_file) < $cache_lifetime_seconds)) {
        $cached_data = file_get_contents($cache_file);
        return json_decode($cached_data, true);
    }

    // 2. Fetch Live Data: Read from the master CSV file
    $csv_path = dirname(__DIR__) . '/data/AxiMate_Voice_List.csv';
    if (!file_exists($csv_path)) {
        // In a real app, you would handle this error more gracefully
        return array();
    }

    $voices = array();
    if (($handle = fopen($csv_path, "r")) !== FALSE) {
        $header = fgetcsv($handle); // Read and discard header row
        while (($row = fgetcsv($handle)) !== FALSE) {
            $voices[] = array_combine($header, $row);
        }
        fclose($handle);
    }

    // 3. Process, Filter, and Group the Data
    $google_voices = array();
    foreach ($voices as $voice) {
        if (isset($voice['Vendor']) && $voice['Vendor'] === 'Google' && !empty($voice['final_label'])) {
            $group_name = $voice['voice_group'];
            if (!isset($google_voices[$group_name])) {
                $google_voices[$group_name] = array();
            }
            $google_voices[$group_name][] = $voice;
        }
    }

    // 4. Sort Voices Within Each Group
    foreach ($google_voices as $group_name => &$group_voices) {
        usort($group_voices, 'sortVoicesCallback');
    }
    unset($group_voices); // Unset reference

    // 5. Structure the final output and Sort the Groups
    $final_structured_list = array();
    foreach ($google_voices as $group_name => $sorted_voices) {
        $group_prefix = strtolower(substr($group_name, 0, strpos($group_name, '-')));
        $final_structured_list[] = array(
            'group_name' => $group_name,
            'prefix' => $group_prefix, // for sorting
            'voices' => array_map('formatVoiceForOutput', $sorted_voices)
        );
    }
    usort($final_structured_list, 'sortGroupsCallback');

    // 6. Update Cache
    file_put_contents($cache_file, json_encode($final_structured_list));

    return $final_structured_list;
}

// --- Helper Functions for Sorting and Formatting ---

/**
 * Callback for usort to sort voice groups logically.
 */
function sortGroupsCallback($a, $b) {
    $order = array('aximate-standard' => 1, 'aximate-provoice' => 2, 'aximate-premium' => 3);
    $a_order = isset($order[$a['prefix']]) ? $order[$a['prefix']] : 99;
    $b_order = isset($order[$b['prefix']]) ? $order[$b['prefix']] : 99;

    if ($a_order != $b_order) {
        return $a_order - $b_order;
    }
    return strcmp($a['group_name'], $b['group_name']); // Alphabetical within category
}

/**
 * Callback for usort to sort voices by Region -> Gender -> Name.
 */
function sortVoicesCallback($a, $b) {
    $a_details = parseFinalLabel($a['final_label']);
    $b_details = parseFinalLabel($b['final_label']);

    // 1. Sort by Region
    if ($a_details['region'] != $b_details['region']) {
        return strcmp($a_details['region'], $b_details['region']);
    }
    // 2. Sort by Gender (Female first)
    if ($a_details['gender'] != $b_details['gender']) {
        return ($a_details['gender'] === 'Female') ? -1 : 1;
    }
    // 3. Sort by Name
    return strcmp($a_details['name'], $b_details['name']);
}

/**
 * Parses the final_label to extract details for sorting.
 */
function parseFinalLabel($label) {
    $parts = explode('|', $label);
    $details = array('region' => '', 'name' => '', 'gender' => '');

    if (count($parts) === 2) {
        // Extract Region
        preg_match('/\(([^)]+)\)/', $parts[0], $region_match);
        $details['region'] = isset($region_match[1]) ? $region_match[1] : 'N/A';
        // Extract Name
        preg_match('/^(.*?)\s*\(/', trim($parts[1]), $name_match);
        $details['name'] = isset($name_match[1]) ? trim($name_match[1]) : 'N/A';
        // Extract Gender
        preg_match('/\(([^)]+)\)/', $parts[1], $gender_match);
        $details['gender'] = isset($gender_match[1]) ? $gender_match[1] : 'N/A';
    }
    return $details;
}

/**
 * Formats a single voice row for the final JSON output.
 */
function formatVoiceForOutput($voice) {
    $group_prefix = strtolower(substr($voice['voice_group'], 0, strpos($voice['voice_group'], '-')));
    $icon = '&#9733;'; // Default
    if ($group_prefix === 'aximate-provoice') $icon = '&#9819;';
    if ($group_prefix === 'aximate-premium') $icon = '&#9819;&#9819;';

    return array(
        'value' => $voice['original_google_voice_name'],
        'display' => $icon . ' ' . $voice['final_label']
    );
}
?>