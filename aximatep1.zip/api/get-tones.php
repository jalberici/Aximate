<?php
/*******************************************************************************
 * Company:        [Inroads, LLC]
 * Copyright:      (c) [2025] [Inroads, LLC]. All rights reserved.
 * Version:        1.0.0
 ******************************************************************************/
header('Content-Type: application/json');
if (file_exists('prompt_engine.php')) {
    require_once 'prompt_engine.php';
} else {
    echo json_encode(array('error' => 'Prompt engine not found.'));
    exit;
}
if (function_exists('get_objective_tones')) {
    $tones_data = get_objective_tones();
    echo json_encode($tones_data);
} else {
    echo json_encode(array('error' => 'Tone data function not available.'));
}
exit;
?>