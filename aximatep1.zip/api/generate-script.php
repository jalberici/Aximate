<?php
/*******************************************************************************
 * Company:        [Inroads, LLC]
 * Copyright:      (c) [2025] [Inroads, LLC]. All rights reserved.
 * Version:        90.0.0 (DEFINITIVE - ROBUST LOGGING & ERROR HANDLING)
 * Date:           2025-08-29
 * Last Author:    [Gemini]
 *
 * Description:    This is the definitive, production-ready version. It adds
 *                 robust logging and validation to handle cases where the AI
 *                 returns a non-JSON response, which causes silent failures.
 *                 It will now log the AI's exact response for debugging and
 *                 return a clear error to the user, resolving the issue.
 ******************************************************************************/

// Use a more compatible path constant for PHP 5.x
$log_path = dirname(__FILE__) . '/ai_debug_log.txt';
ini_set('error_log', $log_path);

if (file_exists(dirname(dirname(__FILE__)) . '/config/config.php')) {
    require_once dirname(dirname(__FILE__)) . '/config/config.php';
}

// --- Error Handling ---
function handle_api_error($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) { return false; }
    http_response_code(500);
    echo json_encode(array('error' => "A server-side PHP error occurred. Check server logs for details."));
    error_log("PHP Warning/Error: $message in $file on line $line");
    exit;
}
set_error_handler('handle_api_error');

function handle_fatal_error() {
    $error = error_get_last();
    if ($error !== null && in_array($error['type'], array(E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR, E_PARSE))) {
        http_response_code(500);
        if (!headers_sent()) {
            header('Content-Type: application/json');
        }
        echo json_encode(array( 'error' => 'A fatal PHP error occurred on the server.'));
        error_log("Fatal PHP Error: " . print_r($error, true));
    }
}
register_shutdown_function('handle_fatal_error');

header('Content-Type: application/json');

if (file_exists('prompt_engine.php')) {
    require_once 'prompt_engine.php';
} else {
    // Define a fallback if the file is missing to prevent fatal errors
    function build_master_prompt($objective, $params) {
        return "Objective: " . $objective . "\nDetails: " . json_encode($params);
    }
}


function send_json_response($data, $http_code = 200) {
    http_response_code($http_code);
    echo json_encode($data);
    exit;
}

function call_llama_api($payload) {
    $api_endpoint = defined('AI_API_ENDPOINT') ? AI_API_ENDPOINT : '';
    $api_key = defined('AI_API_KEY') ? AI_API_KEY : '';
    if (empty($api_endpoint) || empty($api_key)) {
        send_json_response(array('error' => 'AI API endpoint or key is not configured on the server.'), 500);
    }

    $ch = curl_init($api_endpoint);
    curl_setopt_array($ch, array(
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_TIMEOUT => 150,
        CURLOPT_HTTPHEADER => array('Content-Type: application/json', 'Authorization: Bearer ' . $api_key)
    ));
    $response = curl_exec($ch);
    $curl_error_message = curl_error($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($curl_error_message) {
        send_json_response(array('error' => 'cURL Error: ' . $curl_error_message), 500);
    }
    if ($http_code >= 400) {
        send_json_response(array('error' => 'API Error: The AI provider returned an HTTP ' . $http_code, 'details' => $response), $http_code);
    }

    $api_data = json_decode($response, true);
    if ($api_data === null && json_last_error() !== JSON_ERROR_NONE) {
        // This is not a fatal error, but the AI response was not JSON. Log and return the raw text.
        error_log("CRITICAL: AI response was not valid JSON. Returning raw text for processing.");
        return $response; // Return the raw non-JSON string
    }

    if (!isset($api_data['choices'][0]['message']['content'])) {
        send_json_response(array('error' => 'The AI response structure was invalid. Missing expected content path.', 'raw_response' => $response), 500);
    }
    
    return trim($api_data['choices'][0]['message']['content']);
}

function is_valid_script_line($line) {
    return is_array($line) && isset($line['speaker']) && isset($line['text']) && trim($line['speaker']) !== '' && trim($line['text']) !== '';
}


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response(array('error' => 'Method not allowed'), 405);
}

$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    send_json_response(array('error' => 'Invalid JSON input'), 400);
}
$intent = isset($data['primaryIntent']) ? trim($data['primaryIntent']) : '';
if (empty($intent)) {
    send_json_response(array('error' => 'Primary intent is required.'), 400);
}

$objective = isset($data['objective']) ? $data['objective'] : 'custom';
$speakers_value = isset($data['speakers']) ? $data['speakers'] : '1';
if ($speakers_value === 'single') { $numSpeakers = 1; } else { $numSpeakers = is_numeric($speakers_value) ? (int)$speakers_value : 2; }

if ($numSpeakers === 1) {
    $speakerInstruction = "a monologue with 1 speaker named 'Narrator'.";
} else {
    $speakerInstruction = "a dialogue between " . $numSpeakers . " speakers. Invent creative names for the speakers.";
}

$creativity_input = isset($data['creativity']) ? $data['creativity'] : 'Original';
$temperature_map = array('Deterministic' => 0.0, 'Original' => 0.5, 'Creative' => 0.8, 'Imaginative' => 1.0);
$temperature = isset($temperature_map[$creativity_input]) ? $temperature_map[$creativity_input] : 0.5;

$params = array(
    'intent' => $intent,
    'context' => isset($data['context']) ? trim($data['context']) : '',
    'tone' => isset($data['tone']) ? $data['tone'] : 'Neutral',
    'time' => isset($data['time']) ? (int)$data['time'] : 60,
    'speakerInstruction' => $speakerInstruction,
    'vocalStyle' => isset($data['vocalStyle']) ? $data['vocalStyle'] : 'conversational',
    'language' => isset($data['language']) ? $data['language'] : 'en-US'
);

$masterPrompt = build_master_prompt($objective, $params);
error_log("------ NEW AI REQUEST ------\n" . $masterPrompt . "\n--------------------------\n");

$apiPayload = array(
    'model' => defined('AI_SCRIPT_MODEL') ? AI_SCRIPT_MODEL : 'gpt-3.5-turbo',
    'messages' => array(array('role' => 'user', 'content' => $masterPrompt)),
    'temperature' => $temperature,
    'max_tokens' => 2500
);

$raw_content_from_api = call_llama_api($apiPayload);
error_log("------ RAW AI RESPONSE ------\n" . $raw_content_from_api . "\n-------------------------\n");

// --- START: ROBUST JSON PARSING & VALIDATION ---
$sanitized_content = preg_replace('/^```(?:json)?\s*|\s*```$/', '', $raw_content_from_api);
$parsed_json = json_decode($sanitized_content, true);

// WHY: This is the critical step. We check if the AI's response was valid JSON.
// If not, we log the bad response and send a clear error to the user.
if (json_last_error() !== JSON_ERROR_NONE) {
    $error_message = 'The AI returned a response that was not valid JSON. This can happen with complex or unclear prompts. Please check the ai_debug_log.txt file on the server for the exact response from the AI.';
    error_log("FATAL: AI response was not valid JSON. JSON Error: " . json_last_error_msg());
    send_json_response(array('error' => $error_message, 'raw_response' => $sanitized_content), 500);
}
// --- END: ROBUST JSON PARSING & VALIDATION ---

if (isset($parsed_json['script']) && is_array($parsed_json['script'])) {
    $validated_script = array_filter($parsed_json['script'], 'is_valid_script_line');
    // Re-index the array to ensure it's a simple array for JSON encoding
    $parsed_json['script'] = array_values($validated_script);
}

if (!$parsed_json || !isset($parsed_json['script']) || !is_array($parsed_json['script']) || empty($parsed_json['script']) || !isset($parsed_json['imagePrompt']) || !is_string($parsed_json['imagePrompt'])) {
    send_json_response(array('error' => 'The AI returned a valid JSON response, but it was missing the required script or imagePrompt sections. Please try again or adjust your prompt.', 'raw_response' => $sanitized_content), 500);
}

send_json_response($parsed_json);
?>