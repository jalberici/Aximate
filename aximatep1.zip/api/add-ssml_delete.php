<?php
/*******************************************************************************
 * Company:        [Inroads, LLC]
 * Copyright:      (c) [2025] [Inroads, LLC]. All rights reserved.
 * Version:        1.0.1 (Definitive & Final)
 * Date:           2025-08-03
 * Last Author:    [AI Assistant]
 *
 * Description:    This script is the AI-powered SSML Enrichment Engine.
 *                 It takes a plain text script and makes a second LLM call
 *                 to creatively add rich SSML tags for realistic voice direction.
 *                 This version is confirmed compatible with PHP 5.6.
 ******************************************************************************/
set_time_limit(180);
ini_set('memory_limit', '256M');
ob_start();

function send_json_response($data, $http_code = 200) {
    if (headers_sent()) { error_log("Headers already sent."); exit; }
    while (ob_get_level() > 0) { ob_end_clean(); }
    http_response_code($http_code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

require_once '../config/config.php';
if (!defined('AI_API_KEY') || !defined('AI_API_ENDPOINT') || !defined('AI_SCRIPT_MODEL')) {
    send_json_response(['error' => 'Server Configuration Error: AI API constants are not defined in config.php.'], 500);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { send_json_response(['error' => 'Method not allowed'], 405); }
$input = json_decode(file_get_contents('php://input'), true);
if (json_last_error() !== JSON_ERROR_NONE) { send_json_response(['error' => 'Invalid JSON input'], 400); }

$plain_text_script = isset($input['script']) ? trim($input['script']) : '';
if (empty($plain_text_script)) {
    send_json_response(['error' => 'Invalid input: script text is required.'], 400);
}

$prompt_template = <<<PROMPT
You are an expert voice coach and SSML author. Your task is to take the following plain text script and enrich it with SSML tags to make it sound incredibly realistic and human.

**RULES:**
1.  Wrap the ENTIRE output in a single `<speak>` tag.
2.  For each line, convert the speaker's name (e.g., "Alex:") into a valid `<voice>` tag (e.g., `<voice name="Alex">...</voice>`).
3.  Inside each `<voice>` tag, creatively add SSML tags like `<break time="...s"/>` for natural pauses, and `<prosody rate="..." pitch="...">` to add emotion and vary the speech.
4.  Do NOT alter the original dialogue text. Only add SSML tags around and within it.

**PLAIN TEXT SCRIPT TO CONVERT:**
---
__SCRIPT_CONTENT__
---

**EXAMPLE OF PERFECT OUTPUT:**
<speak>
<voice name="Alex">Hello there, how are you today?<break time="0.5s"/></voice>
<voice name="Samantha"><prosody rate="slow">I am doing great,</prosody> thank you for asking!</voice>
</speak>

Now, convert the provided script into rich SSML.
PROMPT;

$prompt = str_replace('__SCRIPT_CONTENT__', $plain_text_script, $prompt_template);
$payload = json_encode(['model' => AI_SCRIPT_MODEL, 'messages' => [['role' => 'user', 'content' => $prompt]], 'temperature' => 0.7]);

$ch = curl_init(AI_API_ENDPOINT);
curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_POSTFIELDS => $payload, CURLOPT_TIMEOUT => 150, CURLOPT_CONNECTTIMEOUT => 20, CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Authorization: Bearer ' . AI_API_KEY]]);
$response = curl_exec($ch);
$curl_error = curl_error($ch);
curl_close($ch);

if ($curl_error) {
    send_json_response(['error' => "cURL Error: " . $curl_error], 500);
}

$api_data = json_decode($response, true);
if (json_last_error() !== JSON_ERROR_NONE) {
    send_json_response(['error' => 'Failed to decode API response. Response was: ' . $response], 500);
}

if (isset($api_data['error'])) {
    $error_message = isset($api_data['error']['message']) ? $api_data['error']['message'] : 'Unknown API error';
    send_json_response(['error' => 'AI API Error: ' . $error_message], 500);
}

$ssml_content = isset($api_data['choices'][0]['message']['content']) ? trim($api_data['choices'][0]['message']['content']) : '';
if (empty($ssml_content)) {
    send_json_response(['error' => 'AI returned an empty SSML response.'], 500);
}

$ssml_content = preg_replace('/^```(xml|ssml)?\s*/', '', $ssml_content);
$ssml_content = preg_replace('/```$/s', '', $ssml_content);
$ssml_content = trim($ssml_content);

send_json_response(['ssml' => $ssml_content]);
?>