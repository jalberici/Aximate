<?php
/*******************************************************************************
 * Company:        [Inroads, LLC]
 * Copyright:      (c) [2025] [Inroads, LLC]. All rights reserved.
 * Version:        87.0.0 (DEFINITIVE & PHP 5.6 COMPATIBLE FIX)
 * Date:           2025-08-28
 * Last Author:    [Gemini]
 *
 * Description:    This is the definitive, stable, and fully compatible version.
 *                 It rewrites the get_objective_tones() function to use the
 *                 traditional array() syntax, which is compatible with PHP 5.6.
 *                 This resolves the final "Parse error" and makes the script
 *                 generation fully functional.
 ******************************************************************************/

function get_objective_tones() {
    // --- START: PHP 5.6 COMPATIBILITY FIX ---
    // WHY: Replaced all modern shorthand array brackets ([]) with the
    // traditional array() constructor. This is the change that fixes the
    // "Parse error" on PHP 5.6 servers.
    return array(
        'product_explainer' => array('Confident', 'Clear', 'Professional', 'Reassuring', 'Engaging'),
        'promo_cta' => array('Energetic', 'Upbeat', 'Persuasive', 'Compelling', 'Urgent'),
        'testimonial' => array('Authentic', 'Sincere', 'Relatable', 'Enthusiastic', 'Trusting'),
        'lead_gen' => array('Friendly', 'Helpful', 'Low-pressure', 'Clear', 'Inviting'),
        'lead_nurture' => array('Warm', 'Informative', 'No-pressure', 'Thoughtful', 'Supportive'),
        'storytelling' => array('Intimate', 'Expressive', 'Dramatic', 'Whimsical', 'Mysterious', 'Humorous'),
        'podcast_monologue' => array('Engaging', 'Articulate', 'Confident', 'Conversational', 'Informative'),
        'podcast_interview' => array('Curious', 'Attentive', 'Spontaneous', 'Natural', 'Conversational'),
        'company_update' => array('Professional', 'Clear', 'Encouraging', 'Sincere', 'Informative'),
        'customer_reply' => array('Empathetic', 'Calm', 'Clear', 'Reassuring', 'Supportive'),
        'training_module' => array('Clear', 'Methodical', 'Patient', 'Encouraging', 'Professional'),
        'urgent_alert' => array('Crisp', 'Authoritative', 'Urgent', 'Clear', 'Direct'),
        'friendly_reminder' => array('Warm', 'Gentle', 'Helpful', 'Positive', 'Friendly')
    );
    // --- END: PHP 5.6 COMPATIBILITY FIX ---
}

function get_copywriter_persona_style($objective) {
    // This function was already compatible. No changes needed.
    $personas = array(
        'custom' => 'Write with a research-driven, intelligent, and customer-focused style. ',
        'product_explainer' => 'Write with a clear, precise, and benefit-oriented style that educates. ',
        'promo_cta' => 'Write with an urgent, direct-response style and a strong call to action. ',
        'testimonial' => 'Write with a credible, believable style that builds trust. ',
        'lead_gen' => 'Write with a curiosity-driven style that compels the listener to want more. ',
        'lead_nurture' => 'Write with a relationship-building style using psychological triggers. ',
        'storytelling' => 'Craft elegant, immersive narratives with psychological depth. ',
        'podcast_monologue' => 'Write with an authentic, conversational, and rapport-building style. ',
        'podcast_interview' => 'Write as a realistic podcast where speakers naturally talk over each other and have spontaneous reactions. ',
        'company_update' => 'Write with clear, engaging corporate language with a touch of wit. ',
        'customer_reply' => 'Write with an empathetic, personalized style that addresses specific needs. ',
        'training_module' => 'Write with a digestible, actionable style that makes complex topics easy. ',
        'urgent_alert' => 'Write with attention-grabbing, direct, and critical messaging. ',
        'friendly_reminder' => 'Write with a gentle, warm, and relationship-focused follow-up style. '
    );
    return isset($personas[$objective]) ? $personas[$objective] : $personas['custom'];
}

function build_master_prompt($objective, $params) {
    // This function was already compatible. No changes needed.
    $style_instruction = get_copywriter_persona_style($objective);
    $injected_context = $style_instruction . $params['context'];
    $creative_brief = "
- **Intent:** \"{$params['intent']}\"
- **Tone:** {$params['tone']}
- **Vocal Style:** {$params['vocalStyle']}
- **Language:** {$params['language']}
- **Duration:** {$params['time']}s
- **Speakers:** {$params['speakerInstruction']}
- **Context:** \"{$injected_context}\"
";
    // --- START: FINAL PROMPT LOGIC ---
    $final_prompt = <<<PROMPT
You are an expert AI scriptwriter and voice performance director. Your primary goal is to create natural, human-sounding dialogue that is ready for text-to-speech (TTS) conversion.

**Your Most Important Task: Integrate SSML for Performance**
Analyze the dialogue's emotional context, tone, and intent from the Creative Brief. Then, embed SSML (Speech Synthesis Markup Language) tags directly into the dialogue text. This is mandatory.
- **For Pauses:** Use `<break time="..."/>` to create natural hesitations. For example: `Well,<break time="400ms"/> I'm not sure.`
- **For Emphasis:** Wrap key words in `<emphasis level="moderate">...</emphasis>` to make the delivery more engaging. For example: `It was <emphasis level="moderate">huge</emphasis>!`
- **For Tone (Rarely):** Only if essential, use `<prosody>` for effects like whispering. Example: `<prosody volume="soft">it's a secret.</prosody>`

**Secondary Rules:**
- **No Name Repetition:** Do not have characters say each other's names repeatedly. It sounds robotic.
- **Natural Dialogue:** Use ellipses (...) for trailing thoughts and varied sentence lengths.

**Strict Output Format:**
Your entire response MUST be a single, valid JSON object. Do not include any text before or after the JSON.
The JSON object must have exactly two keys:
1.  `"script"`: An array of objects. Each object must have a `"speaker"` (string) and a `"text"` (string) key. The `"text"` value **must** contain the dialogue with the SSML tags you added.
2.  `"imagePrompt"`: A detailed description for an image generator based on the script's theme.

Do NOT use performance notes like `(sadly)`. Only use the SSML tags as instructed above.

---
**CREATIVE BRIEF:**
{$creative_brief}
---
PROMPT;
    // --- END: FINAL PROMPT LOGIC ---
    return $final_prompt;
}
?>