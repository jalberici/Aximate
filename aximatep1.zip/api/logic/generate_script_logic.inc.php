<?php
/*******************************************************************************
 * Logic include for generating scripts.
 * This version has a simplified prompt for higher reliability and better
 * error checking on the AI API response.
 ******************************************************************************/

// Check for API-level errors first (e.g., bad API key, rate limits)
$response_data = json_decode($response, true);
if (isset($response_data['error'])) {
    http_response_code(502); // Bad Gateway
    $error_message = isset($response_data['error']['message']) ? $response_data['error']['message'] : 'An unknown error occurred with the AI service.';
    error_log("AI API Error: " . $error_message);
    echo json_encode(array('error' => 'The AI provider returned an error: ' . $error_message));
    exit;
}

// Proceed if no API-level error was found
$data = json_decode(file_get_contents('php://input'), true);
$core_idea = isset($data['core_idea']) ? trim($data['core_idea']) : '';
$time = isset($data['time']) ? (int)$data['time'] : 60;
if (empty($core_idea) || $time < 1) {
    http_response_code(400);
    echo json_encode(array('error' => 'Invalid input'));
    exit;
}
$creativity = isset($data['creativity']) ? $data['creativity'] : 'Original';
$tone = isset($data['tone']) ? $data['tone'] : 'Neutral';
$language = isset($data['language']) ? $data['language'] : 'en-US';

// A simplified and more direct prompt for the AI model
$prompt = <<<EOT
You are a script generation AI. Your task is to create a script based on the following details.
- Core Idea: '$core_idea'
- Target Duration: Approximately $time seconds.
- Tone: $tone
- Creativity: $creativity
- Language: $language

You MUST follow these rules exactly:
1.  Divide the script between at least two speakers (e.g., Narrator1, Character1).
2.  Your entire output must be a single, valid JSON object and nothing else. Do not add any introductory text or explanations.
3.  The JSON object must have two keys: "script" and "ssml".
4.  The "script" value must be plain text with speaker names and newlines, like "Narrator1: Hello.\\nCharacter1: Hi there."
5.  The "ssml" value must be a valid SSML string, starting with <speak> and using <voice name="SpeakerName"> tags for each speaker line.

Example of your required output format:
{"script": "Narrator1: The sun rises.", "ssml": "<speak><voice name=\"Narrator1\">The sun rises.<break time=\"0.5s\"/></voice></speak>"}
EOT;

$payload = json_encode(array(
    'model' => AI_MODEL_NAME,
    'messages' => array(array('role' => 'user', 'content' => $prompt)),
    'temperature' => 0.2
));

$ch = curl_init(AI_API_ENDPOINT);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'Authorization: Bearer ' . AI_API_KEY));
$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($http_code !== 200) {
    http_response_code(502);
    echo json_encode(array('error' => 'The AI script service failed to respond.'));
    exit;
}

$api_data = json_decode($response, true);
$content = isset($api_data['choices'][0]['message']['content']) ? $api_data['choices'][0]['message']['content'] : '';

// Attempt to decode the AI's content
$result = json_decode($content, true);

// If decoding fails, try to salvage it before giving up
if (json_last_error() !== JSON_ERROR_NONE) {
    // This regex is a safety net to extract a JSON object from surrounding text.
    preg_match('/\{.*\}/s', $content, $matches);
    if (isset($matches[0])) {
        $result = json_decode($matches[0], true);
    }
}

// Final check: if we still don't have a valid structure, fail gracefully.
if (!is_array($result) || !isset($result['ssml']) || !isset($result['script'])) {
    http_response_code(500);
    error_log("AI service returned malformed content for script: " . $content);
    echo json_encode(array('error' => 'The AI script service returned an invalid response. Please try again.'));
    exit;
}

echo json_encode($result);
?>