
<?php
// api/logic/get_voices_logic.inc.php

if (!defined('GOOGLE_TTS_API_KEY') || empty(GOOGLE_TTS_API_KEY) || GOOGLE_TTS_API_KEY === 'YOUR_GOOGLE_CLOUD_API_KEY') {
    http_response_code(503);
    error_log('FATAL: GOOGLE_TTS_API_KEY is not defined in config.php.');
    echo json_encode(array('error' => 'Voice service is misconfigured.'));
    exit;
}

$api_url = 'https://texttospeech.googleapis.com/v1/voices?key=' . GOOGLE_TTS_API_KEY;
$ch = curl_init($api_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
curl_setopt($ch, CURLOPT_TIMEOUT, 20);
$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curl_error = curl_error($ch);
curl_close($ch);

if ($curl_error || $http_code !== 200) {
    http_response_code(502);
    error_log("Google TTS API Error: HTTP $http_code, cURL Error: $curl_error");
    echo json_encode(array('error' => 'Failed to retrieve voice list from the provider.'));
    exit;
}

$response_data = json_decode($response, true);
if (!isset($response_data['voices']) || !is_array($response_data['voices'])) {
    http_response_code(500);
    echo json_encode(array('error' => 'Received an invalid response from the voice service provider.'));
    exit;
}

$all_voices = $response_data['voices'];
$processed_voices = array();
foreach ($all_voices as $voice) {
    $voice_name = isset($voice['name']) ? $voice['name'] : '';
    $lang_code = isset($voice['languageCodes'][0]) ? $voice['languageCodes'][0] : '';
    if (strpos($lang_code, 'en-') === 0) {
        $type_label = 'Standard';
        if (stripos($voice_name, 'Wavenet') !== false) { $type_label = 'WaveNet'; } 
        elseif (stripos($voice_name, 'Neural2') !== false) { $type_label = 'Neural2'; } 
        elseif (stripos($voice_name, 'Studio') !== false) { $type_label = 'Studio'; } 
        elseif (stripos($voice_name, 'Chirp') !== false) { $type_label = 'Chirp'; }
        
        $gender_label = (isset($voice['ssmlGender']) && $voice['ssmlGender'] === 'FEMALE') ? 'Female' : 'Male';
        $display_name = str_replace($lang_code . '-', '', $voice_name) . ' (' . $gender_label . ')';
        
        if (!isset($processed_voices[$type_label])) { $processed_voices[$type_label] = array(); }
        $processed_voices[$type_label][] = array('id' => $voice_name, 'name' => $display_name);
    }
}
echo json_encode($processed_voices);
?>