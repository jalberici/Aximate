<?php
/*******************************************************************************
 * Company:        [Inroads, LLC]
 * Copyright:      (c) [2025] [Inroads, LLC]. All rights reserved.
 * Version:        130.0.0 (STABLE & FINAL - SSML/TEXT AWARE)
 * Date:           2025-08-31
 * Last Author:    [Gemini]
 *
 * Description:    This is the definitive, stable, and final version for Google
 *                 TTS. It correctly handles Chirp voices by sending plain text
 *                 instead of SSML, fixing all generation errors. SSML is
 *                 preserved for all other compatible voice types.
 ******************************************************************************/

ini_set('display_errors', 0);
error_reporting(E_ALL);
header('Content-Type: application/json');

require_once dirname(dirname(__FILE__)) . '/vendor/autoload.php';
use Google\Cloud\TextToSpeech\V1\TextToSpeechClient;
use Google\Cloud\TextToSpeech\V1\SynthesisInput;
use Google\Cloud\TextToSpeech\V1\VoiceSelectionParams;
use Google\Cloud\TextToSpeech\V1\AudioConfig;
use Google\Cloud\TextToSpeech\V1\AudioEncoding;
use Google\Cloud\TextToSpeech\V1\SsmlVoiceGender;

$config_path = dirname(dirname(__FILE__)) . '/config/config.php';
if (!file_exists($config_path)) { send_error('Server configuration file is missing.'); }
require_once $config_path;

function send_error($message, $log_message = null) {
    error_log("AxiMate generate-audio.php ERROR: " . ($log_message ?: $message));
    http_response_code(500);
    echo json_encode(array('success' => false, 'error' => $message));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(array('success' => false, 'error' => 'Method Not Allowed'));
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (json_last_error() !== JSON_ERROR_NONE) {
    send_error('Invalid JSON input.');
}

$action = isset($input['action']) ? $input['action'] : null;

try {
    if (!defined('GOOGLE_APPLICATION_CREDENTIALS') || !file_exists(GOOGLE_APPLICATION_CREDENTIALS)) {
        send_error('Google Credentials not configured or file not found.');
    }
    $client = new TextToSpeechClient(array('credentials' => GOOGLE_APPLICATION_CREDENTIALS));

    if ($action === 'preview_voice') {
        $voiceId = isset($input['voiceId']) ? $input['voiceId'] : null;
        if (!$voiceId) { send_error('Voice ID is required for preview.'); }

        $synthesisInput = (new SynthesisInput())->setText('This is a preview of the selected voice.');
        
        $langCode = preg_match('/^([a-z]{2,3}-[A-Z]{2,3})/', $voiceId, $matches) ? $matches[0] : 'en-US';
        
        $voice = (new VoiceSelectionParams())->setName($voiceId)->setLanguageCode($langCode);
        $audioConfig = (new AudioConfig())->setAudioEncoding(AudioEncoding::MP3);

        $response = $client->synthesizeSpeech($synthesisInput, $voice, $audioConfig);
        $audioContent = $response->getAudioContent();

        $output_dir = dirname(__DIR__) . '/audio_outputs/temp/';
        if (!is_dir($output_dir) && !@mkdir($output_dir, 0755, true)) {
            send_error('Failed to create temporary audio directory.');
        }
        $filename = 'preview_' . preg_replace('/[^a-zA-Z0-9_-]/', '_', $voiceId) . '.mp3';
        $filepath = $output_dir . $filename;
        file_put_contents($filepath, $audioContent);

        $relative_url = 'audio_outputs/temp/' . $filename . '?t=' . time();
        echo json_encode(array('success' => true, 'audioUrl' => $relative_url));

    } elseif ($action === 'generate_audio') {
        $script = isset($input['script']) ? $input['script'] : null;
        $voiceMap = isset($input['voiceMap']) ? $input['voiceMap'] : null;
        $projectId = isset($input['projectId']) ? $input['projectId'] : null;

        if (!$script || !$voiceMap || !$projectId) { send_error('Missing required data for audio generation.'); }

        $finalAudioContent = '';
        foreach ($script as $line) {
            $speaker = isset($line['speaker']) ? $line['speaker'] : null;
            $ssml_text = isset($line['text']) ? $line['text'] : '';
            if (!$speaker || empty(trim($ssml_text))) continue;

            $voiceId = isset($voiceMap[$speaker]['id']) ? $voiceMap[$speaker]['id'] : null;
            $pitch = isset($voiceMap[$speaker]['pitch']) ? (float)$voiceMap[$speaker]['pitch'] : 0.0;
            $langCode = isset($voiceMap[$speaker]['lang']) ? $voiceMap[$speaker]['lang'] : 'en-US';

            if (!$voiceId) { send_error("No voice ID found for speaker {$speaker}."); }

            $voice = (new VoiceSelectionParams())->setName($voiceId)->setLanguageCode($langCode);
            $audioConfig = (new AudioConfig())->setAudioEncoding(AudioEncoding::MP3);

            // --- THE DEFINITIVE FIX ---
            // WHY: Chirp voices do not support SSML. We must detect them and send plain text.
            if (strpos($voiceId, 'Chirp') !== false) {
                // For Chirp, strip SSML and use setText(). Do NOT set pitch/rate.
                $plain_text = strip_tags($ssml_text);
                $synthesisInput = (new SynthesisInput())->setText($plain_text);
            } else {
                // For all other voices, use setSsml() and include pitch/rate adjustments.
                $synthesisInput = (new SynthesisInput())->setSsml("<speak>{$ssml_text}</speak>");
                $audioConfig->setSpeakingRate(1.0);
                $audioConfig->setPitch($pitch);
            }
            // --- END OF DEFINITIVE FIX ---

            $response = $client->synthesizeSpeech($synthesisInput, $voice, $audioConfig);
            $finalAudioContent .= $response->getAudioContent();
        }

        if (empty($finalAudioContent)) { send_error('No audio was generated. The script might be empty or invalid.'); }

        $output_dir = dirname(__DIR__) . '/outputs/' . $projectId . '/';
        if (!is_dir($output_dir) && !@mkdir($output_dir, 0755, true)) {
            send_error('Failed to create project output directory.');
        }
        $filename = 'generated_audio_' . time() . '.mp3';
        $filepath = $output_dir . $filename;
        file_put_contents($filepath, $finalAudioContent);

        $relative_url = 'outputs/' . $projectId . '/' . $filename;
        echo json_encode(array('success' => true, 'audioUrl' => $relative_url, 'fileName' => $filename));

    } else {
        send_error('Invalid action specified.');
    }

    $client->close();

} catch (Exception $e) {
    // Send the specific, detailed error message back to the browser.
    send_error($e->getMessage(), $e->getMessage());
}

exit;
?>