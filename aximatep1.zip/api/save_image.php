<?php
/*******************************************************************************
 * Company:        [Inroads, LLC]
 * Copyright:      (c) [2025] [Inroads, LLC]. All rights reserved.
 * Version:        1.3.1 // Verified directory consistency
 * Date:           2025-08-23
 *
 * Description:    Handles saving of canvas image data to the correct
 *                 `saved_images` directory. No functional changes were
 *                 needed as it already used the correct path.
 ******************************************************************************/

// save_image.php - Image saving endpoint
header('Content-Type: application/json');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0); // Set to 1 for debugging

// Check request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(array('error' => 'Method not allowed. Use POST.'));
    exit;
}

// Get and validate JSON input
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(array('error' => 'Invalid JSON payload: ' . json_last_error_msg()));
    exit;
}

// Validate required data
$projectId = isset($data['projectId']) ? (int)$data['projectId'] : 0;
if ($projectId === 0) {
    http_response_code(400);
    echo json_encode(array('error' => 'Project ID is required.'));
    exit;
}

if (!isset($data['imageData']) || empty($data['imageData'])) {
    http_response_code(400);
    echo json_encode(array('error' => 'No image data provided.'));
    exit;
}

// Create project-specific upload directory if it doesn't exist
$upload_dir = dirname(__DIR__) . '/saved_images/' . $projectId . '/';
if (!is_dir($upload_dir)) {
    if (!mkdir($upload_dir, 0755, true)) {
        http_response_code(500);
        echo json_encode(array('error' => 'Failed to create saved_images project directory. Check permissions.'));
        exit;
    }
}


// Extract and validate base64 data
if (preg_match('/^data:image\/(\w+);base64,/', $data['imageData'], $type)) {
    $imageData = substr($data['imageData'], strpos($data['imageData'], ',') + 1);
    $imageType = strtolower($type[1]);
    
    $allowedTypes = array('png', 'jpg', 'jpeg', 'gif', 'webp');
    if (!in_array($imageType, $allowedTypes)) {
        http_response_code(400);
        echo json_encode(array('error' => 'Invalid image type. Allowed types: ' . implode(', ', $allowedTypes)));
        exit;
    }
    
    $imageData = base64_decode($imageData);
    if ($imageData === false) {
        http_response_code(400);
        echo json_encode(array('error' => 'Base64 decode failed.'));
        exit;
    }
} else {
    http_response_code(400);
    echo json_encode(array('error' => 'Invalid data URI scheme. Expected data:image/[type];base64,[data]'));
    exit;
}

// Generate filename
$filename = 'canvas_save_' . time() . '.png';
$filepath = $upload_dir . $filename;

// Save the image
if (file_put_contents($filepath, $imageData) !== false) {
    // Calculate the public-facing URL
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'];
    
    $script_dir = dirname($_SERVER['SCRIPT_NAME']); // e.g., /.../api
    $base_path = rtrim(dirname($script_dir), '/'); // e.g., /...
    
    $imageUrl = $protocol . $host . $base_path . '/saved_images/' . $projectId . '/' . $filename;
    
    echo json_encode(array(
        'success' => true,
        'message' => "Image saved successfully as '{$filename}'!",
        'imageUrl' => $imageUrl
    ));
} else {
    http_response_code(500);
    echo json_encode(array(
        'success' => false,
        'error' => 'Failed to save image. Check directory permissions and disk space.'
    ));
}
?>