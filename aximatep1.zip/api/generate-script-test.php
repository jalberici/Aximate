<?php
/*******************************************************************************
 * Company:        [Inroads, LLC]
 * Copyright:      (c) [2025] [Inroads, LLC]. All rights reserved.
 * Version:        11.0.0 (STRATEGY: Reverted to Legacy Google TTS REST API)
 * Date:           2025-08-24
 * Last Author:    [Gemini AI]
 *
 * Description:    This version abandons the modern Google Cloud Client Library
 *                 in favor of a direct cURL call to the Google TTS REST API.
 *                 This removes all dependencies on Composer, gRPC, and Protobuf,
 *                 making it fully compatible with legacy PHP 5.6 environments
 *                 while retaining full SSML support.
 ******************************************************************************/
ini_set('display_errors', 1); error_reporting(E_ALL); set_time_limit(300);
require_once __DIR__ . '/../config/config.php';

// --- UTILITY FUNCTIONS ---
function log_error($message) {
    $log_dir = dirname(__DIR__) . '/logs/';
    if (!is_dir($log_dir)) { @mkdir($log_dir, 0755, true); }
    @file_put_contents($log_dir . 'audio_gen_error.log', date('Y-m-d H:i:s') . " - " . $message . "\n", FILE_APPEND);
}

function send_json_response($data, $http_code = 200) {
    http_response_code($http_code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

/**
 * Converts simple editor HTML into Google-compliant SSML.
 */
function convertHtmlToSsml($html) {
    if (empty(trim($html))) return '<speak></speak>';
    $doc = new DOMDocument();
    @$doc->loadHTML('<?xml encoding="utf-8" ?><body>' . $html . '</body>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    $xpath = new DOMXPath($doc);
    foreach ($xpath->query('//strong | //b') as $node) {
        $newNode = $doc->createElement('emphasis', htmlspecialchars($node->nodeValue));
        $newNode->setAttribute('level', 'strong');
        $node->parentNode->replaceChild($newNode, $node);
    }
    foreach ($xpath->query('//span[@data-style="whisper"]') as $node) {
        $newNode = $doc->createElement('prosody', htmlspecialchars($node->nodeValue));
        $newNode->setAttribute('volume', 'soft');
        $newNode->setAttribute('rate', 'slow');
        $node->parentNode->replaceChild($newNode, $node);
    }
    foreach ($xpath->query('//span[@data-perform="long-pause"]') as $node) {
        $newNode = $doc->createElement('break');
        $newNode->setAttribute('time', '1s');
        $node->parentNode->replaceChild($newNode, $node);
    }
    $body = $doc->getElementsByTagName('body')->item(0);
    $innerXml = '';
    foreach ($body->childNodes as $child) { $innerXml .= $doc->saveXML($child); }
    return '<speak>' . $innerXml . '</speak>';
}

// --- CONFIGURATION CHECK ---
if (!defined('GOOGLE_TTS_API_KEY') || !defined('GOOGLE_TTS_API_ENDPOINT')) {
    log_error('FATAL: GOOGLE_TTS_API_KEY or ENDPOINT is not defined.');
    send_json_response(['error' => 'Server Configuration Error for Google TTS.'], 503);
}

// --- MAIN LOGIC ---
$input = json_decode(file_get_contents('php://input'), true);
if (json_last_error() !== JSON_ERROR_NONE) {
    send_json_response(['error' => 'Invalid JSON payload.'], 400);
}

$action = isset($input['action']) ? $input['action'] : '';

/**
 * Function to call the Google TTS REST API using cURL.
 */
function call_google_tts_api($payload) {
    $api_url = GOOGLE_TTS_API_ENDPOINT . '?key=' . GOOGLE_TTS_API_KEY;
    $ch = curl_init($api_url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_TIMEOUT => 90
    ]);
    $response_body = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($http_code !== 200) {
        log_error("Google TTS API Error: HTTP {$http_code}. Response: " . substr($response_body, 0, 500));
        return null;
    }
    
    $responseData = json_decode($response_body, true);
    if (isset($responseData['audioContent'])) {
        return base64_decode($responseData['audioContent']);
    }
    return null;
}

// --- HANDLE VOICE PREVIEW ---
if ($action === 'preview_voice') {
    $voiceName = isset($input['voiceId']) ? $input['voiceId'] : '';
    if (empty($voiceName)) { send_json_response(['error' => 'Voice ID required.'], 400); }
    
    $lang_code = implode('-', array_slice(explode('-', $voiceName), 0, 2));
    
    $payload = [
        'input' => ['text' => 'This is a preview of the selected voice.'],
        'voice' => ['languageCode' => $lang_code, 'name' => $voiceName],
        'audioConfig' => ['audioEncoding' => 'MP3']
    ];
    
    $audioContent = call_google_tts_api($payload);
    if ($audioContent) {
        header('Content-Type: audio/mpeg');
        echo $audioContent;
    } else {
        send_json_response(['error' => 'Failed to generate voice preview.'], 500);
    }
    exit;
}

// --- HANDLE FULL AUDIO GENERATION ---
if ($action === 'generate_audio') {
    if (empty($input['script']) || empty($input['voiceMap'])) { send_json_response(['error' => 'Script and Voice Map required.'], 400); }

    $script = $input['script'];
    $voice_map = $input['voiceMap'];
    $audio_snippets = [];

    foreach ($script as $line) {
        if (!isset($line['speaker'], $line['text']) || empty(trim(strip_tags($line['text'])))) continue;
        
        $speaker = $line['speaker'];
        if (!isset($voice_map[$speaker])) { log_error("No voice mapping for: {$speaker}"); continue; }

        $voice_details = $voice_map[$speaker];
        $ssml_text = convertHtmlToSsml($line['text']);
        $lang_code = implode('-', array_slice(explode('-', $voice_details['id']), 0, 2));

        $payload = [
            'input' => ['ssml' => $ssml_text],
            'voice' => ['languageCode' => $lang_code, 'name' => $voice_details['id']],
            'audioConfig' => ['audioEncoding' => 'MP3']
        ];
        
        $audioContent = call_google_tts_api($payload);
        if ($audioContent) {
            $audio_snippets[] = $audioContent;
        }
    }

    if (empty($audio_snippets)) { send_json_response(['error' => 'Audio generation failed.'], 500); }

    $full_audio_content = implode('', $audio_snippets);
    $project_id = isset($input['projectId']) ? preg_replace('/[^a-zA-Z0-9_-]/', '', $input['projectId']) : 'general';
    $audio_dir = dirname(__DIR__) . '/outputs/' . $project_id . '/audio/';
    if (!is_dir($audio_dir)) { @mkdir($audio_dir, 0755, true); }
    $filename = 'audio_final_google_' . md5(uniqid()) . '.mp3';
    if (file_put_contents($audio_dir . $filename, $full_audio_content) === false) { send_json_response(['error' => 'Failed to save final audio file.'], 500); }

    $relative_audio_url = 'outputs/' . $project_id . '/audio/' . $filename;
    send_json_response(['success' => true, 'audioUrl' => $relative_audio_url, 'fileName' => $filename]);
}

send_json_response(['error' => 'A valid action is required.'], 400);
?>