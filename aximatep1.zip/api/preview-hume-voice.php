<?php
/*******************************************************************************
 * Service:        Hume Voice Preview (Unified)
 * Version:        8.0.0 (STABLE & FINAL - Evidence-Based Fix)
 * Date:           2025-09-01
 * Last Author:    [Gemini]
 *
 * Description:    This is the definitive, stable version. It uses the correct
 *                 /v0/tts/file endpoint combined with the correct 'utterances'
 *                 payload structure, as proven by all diagnostic tests. This
 *                 is the final and correct implementation.
 ******************************************************************************/

ini_set('display_errors', 0);
error_reporting(E_ALL);
header('Content-Type: application/json');

function send_json_error($message, $log_message = null) {
    error_log("AxiMate preview-hume-voice.php ERROR: " . ($log_message ?: $message));
    http_response_code(500);
    echo json_encode(array('success' => false, 'error' => $message));
    exit;
}

$config_path = dirname(__FILE__) . '/../config/config.php';
if (!file_exists($config_path)) { send_json_error('Configuration file not found'); }
require_once $config_path;

if (!defined('HUME_API_KEY') || empty(HUME_API_KEY)) { send_json_error('Hume API key is not configured'); }

$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (json_last_error() !== JSON_ERROR_NONE) { send_json_error('Invalid JSON input'); }

$voice = isset($data['voice']) ? $data['voice'] : null;
if (empty($voice) || !isset($voice['id'])) {
    http_response_code(400);
    send_json_error('Missing or incomplete voice object from frontend.', 'Received data: ' . $input);
}

try {
    // --- START: THE DEFINITIVE FIX (Correct Endpoint & Payload) ---
    $voice_payload_object = array('id' => $voice['id']);
    if (isset($voice['provider']) && $voice['provider'] === 'hume_standard') {
        $voice_payload_object['provider'] = 'HUME_AI';
    }

    $payload = array(
        'utterances' => array(
            array(
                'text' => 'This is a preview of the selected Hume voice.', 
                'voice' => $voice_payload_object
            )
        )
    );
    
    $json_payload = json_encode($payload);
    // Use the proven endpoint for direct file downloads
    $endpoint = 'https://api.hume.ai/v0/tts/file';
    // --- END: THE DEFINITIVE FIX (Correct Endpoint & Payload) ---

    $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $endpoint,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $json_payload,
        CURLOPT_HTTPHEADER => array('Content-Type: application/json', 'X-Hume-Api-Key: ' . HUME_API_KEY),
        CURLOPT_TIMEOUT => 30
    ));
    
    $response_data = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $content_type = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $curl_error = curl_error($ch);
    curl_close($ch);
    
    if ($curl_error) { throw new Exception('cURL error: ' . $curl_error); }
    if ($http_code !== 200) { throw new Exception('API returned HTTP ' . $http_code . ': ' . substr($response_data, 0, 500)); }
    if (strpos(strtolower($content_type), 'audio') === false) { throw new Exception('API did not return an audio file. Response: ' . substr($response_data, 0, 500));}
    
    $output_dir = dirname(__FILE__) . '/../audio_outputs/temp/';
    if (!is_dir($output_dir) && !mkdir($output_dir, 0755, true)) { throw new Exception('Failed to create temp directory'); }
    
    $filename = 'hume_preview_' . preg_replace('/[^a-zA-Z0-9_-]/', '_', $voice['id']) . '.mp3';
    $file_path = $output_dir . $filename;
    
    if (file_put_contents($file_path, $response_data) === false) { throw new Exception('Failed to save audio file'); }
    
    $relative_url = 'audio_outputs/temp/' . $filename . '?t=' . time();
    
    echo json_encode(array('success' => true, 'audioUrl' => $relative_url));
    
} catch (Exception $e) {
    send_json_error($e->getMessage());
}
?>