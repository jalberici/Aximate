<?php
// api/generate-image-prompt.php (NEW - The AI Visual Director)

ini_set('display_errors', 1);
error_reporting(E_ALL);
set_time_limit(180);

require_once __DIR__ . '/../config/config.php';

function send_json_error($message, $http_code = 500) {
    http_response_code($http_code);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => $message]);
    exit;
}

$apiKey = defined('GROQ_API_KEY') ? GROQ_API_KEY : '';
if (empty($apiKey)) {
    send_json_error('Server configuration error: GROQ_API_KEY not found.');
}

$input = json_decode(file_get_contents('php://input'), true);
if (json_last_error() !== JSON_ERROR_NONE || !isset($input['script_text']) || empty($input['script_text'])) {
    send_json_error('Invalid or missing script text.', 400);
}

$script_text = $input['script_text'];

// --- THE AI VISUAL DIRECTOR PROMPT ---
$prompt = <<<PROMPT
**AI Visual Director Prompt: Script-to-Image Generation**
**Goal:** Analyze the provided script to generate a single, highly detailed, and optimized text-to-image prompt. The image must visually capture the central message, mood, and dramatic moment of the scene.

**Instructions:**
From the provided script, extract or infer the following visual elements and combine them into a single, cohesive, powerful paragraph.

- **Scene:** The core setting and atmosphere.
- **Character/Subject:** The main subject, their appearance, and emotional state.
- **Action:** The central action or pose.
- **Lighting & Color:** The lighting style and overall color palette.
- **Style:** A specific artistic or photographic style.
- **Quality:** Descriptive keywords for high-quality generation.

**Final Image Prompt:**
(Combine all elements into a single paragraph without headings.)

**[PASTE FULL SCRIPT HERE]**
{$script_text}
PROMPT;

// --- API CALL ---
$payload = json_encode([
    'model' => 'llama3-70b-8192',
    'messages' => [['role' => 'user', 'content' => $prompt]],
    'temperature' => 0.6,
    'max_tokens' => 300,
    'top_p' => 1,
    'stream' => false
]);

$ch = curl_init('https://api.groq.com/openai/v1/chat/completions');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $payload,
    CURLOPT_HTTPHEADER => [
        'Authorization: Bearer ' . $apiKey,
        'Content-Type: application/json'
    ]
]);

$response_body = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($http_code !== 200) {
    send_json_error("Error from AI service (HTTP {$http_code}): " . $response_body, $http_code);
}

$api_response = json_decode($response_body, true);
$image_prompt = $api_response['choices'][0]['message']['content'] ?? '';

if (empty($image_prompt)) {
    send_json_error("The AI failed to generate a valid image prompt.");
}

header('Content-Type: application/json');
echo json_encode(['success' => true, 'imagePrompt' => trim($image_prompt)]);
exit;