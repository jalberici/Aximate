<?php
/*******************************************************************************
 * Version:        11.1.0 (STABLE & FINAL - Mirrored to Preview Logic)
 * Description:    This is the definitive, stable version. Its logic now
 *                 perfectly mirrors the working preview-hume-voice.php script,
 *                 using the correct /v0/tts/file endpoint and payload structure
 *                 as proven by all diagnostic tests. This is the final fix.
 ******************************************************************************/

ini_set('display_errors', 0);
error_reporting(E_ALL);
header('Content-Type: application/json');

function send_error($message, $log_message = null) {
    error_log("AxiMate custom-voice-service.php ERROR: " . ($log_message ?: $message));
    http_response_code(500);
    echo json_encode(array('success' => false, 'error' => $message));
    exit;
}

require_once dirname(__DIR__) . '/config/config.php';

if (!defined('HUME_API_KEY') || HUME_API_KEY === '') {
    send_error('Hume API key is not configured on the server.');
}

$input = file_get_contents('php://input');
$data = json_decode($input, true);

$project_id = isset($data['projectId']) ? $data['projectId'] : null;
$script = isset($data['script']) ? $data['script'] : null;
$voiceMap = isset($data['voiceMap']) ? $data['voiceMap'] : null;

if (!$project_id || !$script || !$voiceMap || !is_array($script)) {
    http_response_code(400);
    send_error('Missing or invalid structured data from frontend.');
}

try {
    // --- START: THE DEFINITIVE FIX (Mirrored to working preview logic) ---
    $utterances = array();
    foreach ($script as $line) {
        $speaker = isset($line['speaker']) ? $line['speaker'] : null;
        $ssml_text = isset($line['text']) ? $line['text'] : '';
        if (!$speaker || empty($ssml_text)) continue;

        $voice_data = isset($voiceMap[$speaker]) ? $voiceMap[$speaker] : null;
        // This is the check that is failing. We now use the full object from index.php
        if (empty($voice_data) || !isset($voice_data['id']) || !isset($voice_data['provider'])) { 
            throw new Exception("Missing or incomplete voice object from frontend for speaker: " . htmlspecialchars($speaker)); 
        }
        
        $voice_payload_object = array('id' => $voice_data['id']);
        if ($voice_data['provider'] === 'hume_standard') {
            $voice_payload_object['provider'] = 'HUME_AI';
        }

        $plain_text = strip_tags($ssml_text);
        $utterances[] = array('text' => $plain_text, 'voice' => $voice_payload_object);
    }

    if (empty($utterances)) { throw new Exception("The script was empty after processing."); }

    $payload = array('utterances' => $utterances);
    $json_payload = json_encode($payload);
    $endpoint = 'https://api.hume.ai/v0/tts/file';
    // --- END: THE DEFINITIVE FIX (Mirrored to working preview logic) ---

    $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $endpoint,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $json_payload,
        CURLOPT_HTTPHEADER => array('Content-Type: application/json', 'X-Hume-Api-Key: ' . HUME_API_KEY),
        CURLOPT_TIMEOUT => 150
    ));
    
    $response_data = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $content_type = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($curl_error) { throw new Exception('cURL Error: ' . $curl_error); }
    if ($http_code !== 200) { throw new Exception("API Error (HTTP {$http_code}): " . $response_data); }
    if (strpos(strtolower($content_type), 'audio') === false) { throw new Exception('API did not return an audio file. Response: ' . substr($response_data, 0, 500));}
    
    $filename = 'hume_multivoice_' . time() . '.mp3';
    $output_dir = dirname(__DIR__) . '/outputs/' . $project_id . '/';
    if (!is_dir($output_dir) && !@mkdir($output_dir, 0755, true)) { throw new Exception('Failed to create output directory on the server.'); }
    if (file_put_contents($output_dir . $filename, $response_data) === false) { throw new Exception('Failed to save the downloaded audio file to the server.'); }
    
    $relative_url = 'outputs/' . $project_id . '/' . $filename;
    
    echo json_encode(array('success' => true, 'audioUrl' => $relative_url, 'fileName' => $filename));

} catch (Exception $e) {
    send_error($e->getMessage());
}
?>