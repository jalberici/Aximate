<?php
/*******************************************************************************
 * Company:        [Inroads, LLC]
 * Copyright:      (c) [2025] [Inroads, LLC]. All rights reserved.
 * Version:        2.0.0 (STABILITY & SECURITY FIX)
 * Date:           2025-08-23
 * Last Author:    [Gemini AI]
 * Filename:       api/update-project.php
 * Description:    Handles secure updates for project variables.
 *                 - Corrected data parsing for FormData.
 *                 - Fixed variable name mismatch in whitelist logic.
 ******************************************************************************/

header('Content-Type: application/json');
require_once '../config/db_config.php';

// --- DATA SOURCE CORRECTION ---
// Your JavaScript is sending data as FormData, not JSON.
// We must read from the $_POST superglobal.
if (empty($_POST) || !isset($_POST['project_id']) || !is_numeric($_POST['project_id']) || !isset($_POST['field_name']) || !isset($_POST['field_value'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid or incomplete input.']);
    exit;
}

$projectId = (int)$_POST['project_id'];
$fieldName = $_POST['field_name'];
$fieldValue = $_POST['field_value'];

// --- SECURITY: WHITELIST OF UPDATABLE COLUMNS ---
// This prevents users from trying to update columns like `id` or `created_at`.
$allowed_fields = [
    // Project Details
    'project_name',
    'layout_key',

    // Company Branding
    'company_logo_path',
    'company_title',
    'company_phone',
    'company_email',
    'company_address',
    'company_website',

    // Hero & Audio Content
    'hero_title',
    'audio_title',
    'background_image_path',

    // Hero Styling
    'hero_font_color',
    'hero_font_size',
    'hero_font_family',
    'hero_font_bold',
    'hero_font_italic',
    'hero_font_underline',
    'hero_position',

    // Audio Title Styling
    'audio_font_color',
    'audio_font_size',
    'audio_font_family',
    'audio_font_bold',
    'audio_font_italic',
    'audio_font_underline',

    // Buttons
    'primary_button_title',
    'primary_button_link',
    'secondary_button_title',
    'secondary_button_link'
];

// --- LOGIC VALIDATION ---
// Check if the single field we received is on the whitelist.
if (!in_array($fieldName, $allowed_fields)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'No valid fields to update.']);
    exit;
}

// --- DATABASE UPDATE LOGIC ---
// Build the query securely for a single field update.
$sql = "UPDATE `projects` SET `" . $fieldName . "` = ? WHERE `id` = ?";

// Use prepared statements to prevent SQL injection
$stmt = $mysqli->prepare($sql);

if ($stmt === false) {
    http_response_code(500);
    error_log("SQL prepare failed: " . $mysqli->error); // Log the actual error for debugging
    echo json_encode(['success' => false, 'error' => 'Database error.']);
    exit;
}

// Bind the parameters: one string (s) and one integer (i)
$stmt->bind_param('si', $fieldValue, $projectId);

// Execute the statement and respond
if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Project updated successfully.']);
} else {
    http_response_code(500);
    error_log("SQL execute failed: " . $stmt->error); // Log the actual error
    echo json_encode(['success' => false, 'error' => 'Database update failed.']);
}

$stmt->close();
$mysqli->close();
?>