<?php
/*******************************************************************************
 * Company:        [Inroads, LLC]
 * Copyright:      (c) [2025] [Inroads, LLC]. All rights reserved.
 * Version:        1.1.0 // Feat: Robust Image Library API
 * Date:           2025-07-27
 * Last Author:    [AI Assistant]
 *
 * Description:    API endpoint to list images for a specific project. This
 *                 version adds robust error handling to prevent non-JSON
 *                 output, which was causing parsing errors on the frontend.
 ******************************************************************************/

// --- CRITICAL: Prevent any PHP warnings/errors from breaking JSON output ---
error_reporting(0);
ini_set('display_errors', 0);

// Set the content type to JSON immediately.
header('Content-Type: application/json');

// Basic security: Ensure it's a GET request
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('HTTP/1.1 405 Method Not Allowed');
    echo json_encode(['success' => false, 'error' => 'Method Not Allowed.']);
    exit;
}

// Get project ID from query string
$projectId = isset($_GET['project_id']) ? (int)$_GET['project_id'] : 0;

if ($projectId <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid project ID provided.']);
    exit;
}

// --- IMPORTANT PATH CONFIGURATION ---
// The physical path to the images directory.
$image_dir_physical_path = __DIR__ . '/../uploads/project_images/' . $projectId;

// Calculate the public base URL to construct image URLs.
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'];
$base_path = dirname(dirname($_SERVER['PHP_SELF']));
$base_url = rtrim($protocol . $host . $base_path, '/');

// The public URL path to the images directory.
$image_url_public_path = $base_url . '/uploads/project_images/' . $projectId;

$response = array(
    'success' => true,
    'images' => array()
);

// Check if the directory exists. If not, return an empty list.
if (!is_dir($image_dir_physical_path)) {
    echo json_encode($response);
    exit;
}

// Use a try-catch block for file system operations to handle permission errors.
try {
    $files = scandir($image_dir_physical_path);
    if ($files === false) {
        throw new Exception("Could not read directory. Check permissions.");
    }

    $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];

    foreach ($files as $file) {
        if ($file === '.' || $file === '..') {
            continue;
        }
        
        $file_path = $image_dir_physical_path . '/' . $file;
        $file_extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));

        // Ensure it's a file and has an allowed extension.
        if (is_file($file_path) && in_array($file_extension, $allowed_extensions)) {
            $response['images'][] = array(
                'url' => $image_url_public_path . '/' . rawurlencode($file),
                'name' => htmlspecialchars($file)
            );
        }
    }
} catch (Exception $e) {
    // If any error occurs, return a JSON error message.
    $response['success'] = false;
    $response['error'] = $e->getMessage();
}

echo json_encode($response);
exit;

?>