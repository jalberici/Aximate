<?php
/*******************************************************************************
 * Company:        [Inroads, LLC]
 * Copyright:      (c) [2025] [Inroads, LLC]. All rights reserved.
 * Version:        1.0.0
 * Date:           2025-07-13
 * Last Author:    [JJA]
 *
 * Description:    Single API Gateway for all backend actions. This sidesteps
 *                 any server-side .htaccess or rewrite issues.
 ******************************************************************************/

//header('Content-Type: application/json');
require_once 'config/config.php';

// Determine the requested action from the URL query string.
$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    case 'getVoices':
        // This action handles GET requests for the voice list.
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            http_response_code(405);
            echo json_encode(array('error' => 'Method not allowed for this action.'));
            exit;
        }
        // Execute the voice fetching logic.
        require_once 'api/logic/get_voices_logic.inc.php';
        break;

    case 'generateScript':
        // This action handles POST requests for script generation.
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(array('error' => 'Method not allowed for this action.'));
            exit;
        }
        // Execute the script generation logic.
        require_once 'api/logic/generate_script_logic.inc.php';
        break;

    default:
        // Handle any unknown or missing actions.
        http_response_code(400);
        echo json_encode(array('error' => 'Bad Request: No valid action specified.'));
        break;
}
?>