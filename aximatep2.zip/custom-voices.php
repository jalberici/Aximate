<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
/*******************************************************************************
 * Page:           Custom Voice Management Dashboard
 * Version:        3.1.0 (DEFINITIVE FIX: All UI/UX Features Included)
 * Last Author:    [Gemini]
 ******************************************************************************/
require_once __DIR__ . '/config/config.php';

// --- Global variables for this page ---
$project = null;
$custom_voices = [];
$projectId = isset($_GET['project_id']) ? (int)$_GET['project_id'] : 0;
$base_url = '';

// --- Calculate Base URL ---
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'];
$path = dirname($_SERVER['PHP_SELF']);
$base_url = rtrim($protocol . $host . $path, '/') . '/';

if ($projectId <= 0) {
    header("Location: " . $base_url);
    exit;
}

// --- START: Data Fetching Block ---
$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($mysqli->connect_error) { die("Critical Error: Database connection failed: " . $mysqli->connect_error); }

// Fetch project name for display
$stmt = $mysqli->prepare("SELECT project_name FROM `projects` WHERE `id` = ?");
if ($stmt === false) { die("Critical Error: Failed to prepare project query."); }
$stmt->bind_param('i', $projectId);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) { $project = $result->fetch_assoc(); }
$stmt->close();

// Fetch existing custom voices for this project
$stmt = $mysqli->prepare("SELECT * FROM `custom_voices` WHERE `project_id` = ? ORDER BY last_modified DESC");
if ($stmt === false) { die("Critical Error: Failed to prepare custom voices query."); }
$stmt->bind_param('i', $projectId);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) { $custom_voices[] = $row; }
$stmt->close();
$mysqli->close();

$languages = array( "en-US" => "English (USA)", "en-GB" => "English (UK)", "es-ES" => "Spanish (Spain)" );
asort($languages);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Custom Voice Management - AxiMate Content Studio</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body style="background-color: #f8f9fa;">
    <input type="hidden" id="projectId" value="<?php echo htmlspecialchars($projectId, ENT_QUOTES, 'UTF-8'); ?>">
    <nav class="navbar navbar-expand-lg navbar-light bg-white" style="border-bottom: 1px solid #e0e0e0;">
        <div class="container-fluid px-2 px-md-4">
            <a class="navbar-brand d-flex align-items-center" href="index.php?project_id=<?php echo htmlspecialchars($projectId, ENT_QUOTES, 'UTF-8'); ?>">
                <i class="fas fa-arrow-left me-3"></i>
                <span class="fw-bold fs-5">Back to Project: <?php echo htmlspecialchars($project['project_name']); ?></span>
            </a>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="row">
            <!-- Add New Voice Form -->
            <div class="col-lg-5 mb-4">
                <div class="card">
                    <div class="card-body p-4">
                        <h4 class="card-title mb-4"><i class="fas fa-plus-circle me-2"></i>Add New Custom Voice</h4>
                        <form id="addVoiceForm" enctype="multipart/form-data">
                            <div class="mb-3"><label for="customVoiceProvider" class="form-label">Voice Provider</label><select class="form-select" id="customVoiceProvider" name="provider" required><option value="hume">Hume AI</option><option value="google">Google Cloud</option></select></div>
                            <div class="mb-3"><label for="customVoiceName" class="form-label">Display Name</label><input type="text" class="form-control" id="customVoiceName" name="voice_name" placeholder="e.g., Joseph Alberici" required></div>
                            <div class="mb-3"><label for="customVoiceId" class="form-label">Voice ID</label><input type="text" class="form-control" id="customVoiceId" name="voice_id" placeholder="Paste the unique Voice ID" required></div>
                            <div class="mb-3"><label for="customVoiceLanguage" class="form-label">Voice Language</label><select class="form-select" id="customVoiceLanguage" name="language_code" required><option value="">-- Select --</option><?php foreach ($languages as $code => $name) { echo "<option value=\"".htmlspecialchars($code)."\">".htmlspecialchars($name)."</option>"; } ?></select></div>
                            <div class="mb-3"><label for="customVoiceDescription" class="form-label">Description</label><textarea class="form-control" id="customVoiceDescription" name="description" rows="3" placeholder="e.g., Calm and professional tone for explainers."></textarea></div>
                            <div class="mb-3"><label for="previewAudio" class="form-label">Preview Audio Sample (.mp3)</label><input type="file" class="form-control" id="previewAudio" name="preview_audio" accept=".mp3,audio/mpeg" required></div>
                            <button type="submit" id="saveVoiceBtn" class="btn btn-primary w-100">Save Voice</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- List of Custom Voices -->
            <div class="col-lg-7">
                <h3 class="mb-4">Project Custom Voices</h3>
                <div class="card">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0 align-middle">
                            <thead><tr><th>Name & Description</th><th>Provider</th><th>Language</th><th>Actions</th></tr></thead>
                            <tbody>
                                <?php if (empty($custom_voices)): ?>
                                    <tr><td colspan="4" class="text-center text-muted p-4">No custom voices have been added to this project yet.</td></tr>
                                <?php else: ?>
                                    <?php foreach ($custom_voices as $voice): ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo htmlspecialchars($voice['voice_name']); ?></strong><br>
                                                <small class="text-muted"><?php echo htmlspecialchars($voice['description']); ?></small>
                                            </td>
                                            <td><?php echo htmlspecialchars(ucfirst($voice['provider'])); ?></td>
                                            <td><?php echo htmlspecialchars(isset($languages[$voice['language_code']]) ? $languages[$voice['language_code']] : $voice['language_code']); ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-outline-danger delete-voice-btn" data-id="<?php echo $voice['id']; ?>" title="Delete Voice">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.getElementById('addVoiceForm');
        const saveBtn = document.getElementById('saveVoiceBtn');
        const projectId = document.getElementById('projectId').value;
        const base_url = "<?php echo $base_url; ?>";

        form.addEventListener('submit', function(e) {
            e.preventDefault();
            saveBtn.disabled = true;
            saveBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Saving...';

            const formData = new FormData(form);
            formData.append('action', 'add_voice');
            formData.append('project_id', projectId);

            fetch(base_url + 'api/manage-voices.php', { method: 'POST', body: formData })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    window.location.reload();
                } else {
                    alert('Error: ' + (result.error || 'Could not save the voice.'));
                }
            })
            .catch(error => {
                console.error('Save Error:', error);
                alert('A critical network error occurred. Please check the console and try again.');
            })
            .finally(() => {
                saveBtn.disabled = false;
                saveBtn.innerHTML = 'Save Voice';
            });
        });
        
        document.querySelector('.table').addEventListener('click', function(e) {
            const deleteBtn = e.target.closest('.delete-voice-btn');
            if (deleteBtn) {
                if (confirm('Are you sure you want to permanently delete this voice? This action cannot be undone.')) {
                    const idToDelete = deleteBtn.dataset.id;
                    
                    fetch(base_url + 'api/manage-voices.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            action: 'delete_voice',
                            project_id: projectId,
                            id: idToDelete
                        })
                    })
                    .then(response => response.json())
                    .then(result => {
                        if (result.success) {
                            window.location.reload();
                        } else {
                            alert('Error: ' + (result.error || 'Could not delete the voice.'));
                        }
                    })
                    .catch(error => {
                         console.error('Delete Error:', error);
                         alert('A network error occurred while trying to delete the voice.');
                    });
                }
            }
        });
    });
    </script>
</body>
</html>