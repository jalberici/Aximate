<?php
error_reporting(E_ALL);ini_set('display_errors', '1');
/*******************************************************************************
 * Company:        [Inroads, LLC]
 * Copyright:      (c) [2025] [Inroads, LLC]. All rights reserved.
 * Version:        130.1.1 (SCRIPT GENERATOR FIXED)
 * Date:           2025-09-01
 * Last Author:    [Assistant]
 *
 * Description:    Fixed the duplicate variable declaration and scope issues
 *                 that prevented the script generator from working properly.
 ******************************************************************************/

// --- SESSION & TRACKING INFORMATION ---
$current_datetime_utc = '2025-08-07 19:30:10';
$current_user_login = 'josephalberici-art';
error_log("AxiMate Content Studio accessed by: {$current_user_login} at {$current_datetime_utc} UTC");

// PROTOCOL & BASE URL (DEFINED EARLY FOR USE IN ACTIONS)
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'];
$path = dirname($_SERVER['PHP_SELF']);
$base_url = rtrim($protocol . $host . $path, '/') . '/';

// --- START: DEFINITIVE ACTION HANDLING BLOCK ---

function send_json_response($data, $http_code = 200) {
    http_response_code($http_code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

// Reusable function to handle file uploads securely
function handle_file_upload($file_input_name, $project_id, $base_url) {
    if ($project_id === 0 || !isset($_FILES[$file_input_name])) {
        return array('success' => false, 'error' => 'Invalid project ID or no file uploaded.');
    }
    $file = $_FILES[$file_input_name];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return array('success' => false, 'error' => 'File upload error code: ' . $file['error']);
    }
    $outputDir = __DIR__ . '/saved_images/' . $project_id . '/';
    if (!is_dir($outputDir) && !mkdir($outputDir, 0755, true)) {
        return array('success' => false, 'error' => 'Could not create server directory.');
    }
    $sanitizedFilename = preg_replace("/[^a-zA-Z0-9\._-]/", "", basename($file['name']));
    $filepath = $outputDir . $sanitizedFilename;
    $overwriteConfirmed = isset($_POST['overwrite']) && $_POST['overwrite'] === 'true';
    if (file_exists($filepath) && !$overwriteConfirmed) {
        return array('success' => false, 'error' => 'File already exists.', 'requires_confirmation' => true);
    }
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        $imageUrl = $base_url . 'saved_images/' . $project_id . '/' . $sanitizedFilename;
        return array('success' => true, 'url' => $imageUrl);
    } else {
        return array('success' => false, 'error' => 'Failed to save uploaded file.');
    }
}


// ACTION: Handle Logo Upload
if (isset($_POST['action']) && $_POST['action'] === 'upload_logo') {
    require_once __DIR__ . '/config/config.php';
    $projectId = isset($_POST['project_id']) ? (int)$_POST['project_id'] : 0;
    $result = handle_file_upload('logoFile', $projectId, $base_url);
    if ($result['success']) {
        $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        $stmt = $mysqli->prepare("UPDATE `projects` SET `company_logo_path` = ? WHERE `id` = ?");
        $stmt->bind_param('si', $result['url'], $projectId);
        $stmt->execute();
        $stmt->close();
        $mysqli->close();
    }
    send_json_response($result);
}

// ACTION: Handle Final Background Image Upload
if (isset($_POST['action']) && $_POST['action'] === 'upload_background_image') {
    require_once __DIR__ . '/config/config.php';
    $projectId = isset($_POST['project_id']) ? (int)$_POST['project_id'] : 0;
    $result = handle_file_upload('backgroundImageFile', $projectId, $base_url);
    send_json_response($result);
}

// ACTION: Save the contents of the Fabric.js canvas
if (isset($_POST['action']) && $_POST['action'] === 'save_canvas') {
    $projectId = isset($_POST['project_id']) ? (int)$_POST['project_id'] : 0;
    $imageData = isset($_POST['imageData']) ? $_POST['imageData'] : '';
    if ($projectId === 0 || empty($imageData)) {
        send_json_response(array('success' => false, 'error' => 'Invalid project ID or missing image data.'), 400);
    }
    $filename = 'canvas_export_' . time() . '.png';
    $outputDir = __DIR__ . '/saved_images/' . $projectId . '/';
    $filepath = $outputDir . $filename;
    if (!is_dir($outputDir) && !mkdir($outputDir, 0755, true)) {
        send_json_response(array('success' => false, 'error' => 'Failed to create output directory.'), 500);
    }
    if (strpos($imageData, 'data:image/png;base64,') === 0) {
        $imageData = str_replace('data:image/png;base64,', '', $imageData);
        $imageData = str_replace(' ', '+', $imageData);
        $decodedData = base64_decode($imageData);
        if ($decodedData === false) {
            send_json_response(array('success' => false, 'error' => 'Failed to decode image data.'), 500);
        }
        if (file_put_contents($filepath, $decodedData) === false) {
            send_json_response(array('success' => false, 'error' => 'Failed to save image to server.'), 500);
        }
        $imageUrl = $base_url . 'saved_images/' . $projectId . '/' . $filename;
        send_json_response(array('success' => true, 'url' => $imageUrl));
    } else {
        send_json_response(array('success' => false, 'error' => 'Invalid image data format.'), 400);
    }
}

// ACTION: List all images for a project
if (isset($_GET['action']) && $_GET['action'] === 'list_images') {
    $projectId = isset($_GET['project_id']) ? (int)$_GET['project_id'] : 0;
    if ($projectId === 0) {
        send_json_response(array('error' => 'Invalid Project ID.'), 400);
    }
    $imageUrls = array();
    $imageDir = __DIR__ . '/saved_images/' . $projectId . '/';
    if (is_dir($imageDir)) {
        $files = scandir($imageDir);
        $allowedExtensions = array('jpg', 'jpeg', 'png', 'gif', 'webp');
        if (is_array($files)) {
            foreach ($files as $file) {
                if ($file === '.' || $file === '..') continue;
                $fileExtension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                if (in_array($fileExtension, $allowedExtensions)) {
                    $imageUrls[] = $base_url . 'saved_images/' . $projectId . '/' . basename($file);
                }
            }
        }
    }
    send_json_response($imageUrls);
}

// ACTION: Delete a specific image
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_image') {
    $projectId = isset($_POST['project_id']) ? (int)$_POST['project_id'] : 0;
    $imageUrl = isset($_POST['image_url']) ? $_POST['image_url'] : '';
    if ($projectId === 0 || empty($imageUrl) || strpos($imageUrl, '..') !== false) {
        send_json_response(array('success' => false, 'error' => 'Invalid project ID or image URL.'), 400);
    }
    $filename = basename($imageUrl);
    $filepath = __DIR__ . '/saved_images/' . $projectId . '/' . $filename;
    if (file_exists($filepath) && strpos(realpath($filepath), realpath(__DIR__ . '/saved_images/' . $projectId)) === 0) {
        if (unlink($filepath)) {
            send_json_response(array('success' => true, 'message' => 'Image deleted successfully.'));
        } else {
            send_json_response(array('success' => false, 'error' => 'Could not delete file from server.'), 500);
        }
    } else {
        send_json_response(array('success' => false, 'error' => 'File not found or access denied.'), 404);
    }
}

// This function must be defined *before* the block that uses it.
function updateNode($xpath, $query, $value, $attribute = 'innerText') {
    global $doc;
    $nodes = $xpath->query($query);
    foreach ($nodes as $node) {
        if ($attribute === 'innerText') {
            while ($node->hasChildNodes()) { $node->removeChild($node->firstChild); }
            $node->appendChild($doc->createTextNode($value));
        } elseif ($attribute === 'style') {
            $node->setAttribute('style', $value);
        } else {
            $node->setAttribute($attribute, $value);
        }
    }
}

// ACTION: Generate a webpage from a template
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SERVER['CONTENT_TYPE']) && strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false) {
    $json_data = file_get_contents('php://input');
    $data = json_decode($json_data, true);
    if (isset($data['action']) && $data['action'] === 'generate_webpage') {
        require_once __DIR__ . '/config/config.php';
        $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        $layouts = array("blue-modern" => array("name" => "Blue Modern", "template_file" => "web_templates/blue_modern.html"), "dark-elegance" => array("name" => "Dark Elegance", "template_file" => "web_templates/dark_elegance.html"), "fresh-green" => array("name" => "Fresh Green", "template_file" => "web_templates/fresh_green.html"), "vivid-purple" => array("name" => "Vivid Purple", "template_file" => "web_templates/vivid_purple.html"), "minimalist-gray" => array("name" => "Minimalist Gray", "template_file" => "web_templates/minimalist_gray.html"));
        $projectId = isset($data['projectId']) ? (int)$data['projectId'] : 0;
        $audioUrl = isset($data['audioUrl']) ? $data['audioUrl'] : '';
        $backgroundImageUrl = isset($data['backgroundImageUrl']) ? $data['backgroundImageUrl'] : '';
        if ($projectId === 0) { send_json_response(array('success' => false, 'error' => 'Invalid Project ID.'), 400); }
        $stmt = $mysqli->prepare("SELECT * FROM `projects` WHERE `id` = ?");
        $stmt->bind_param('i', $projectId);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows === 0) { send_json_response(array('success' => false, 'error' => 'Project not found.'), 404); }
        $project = $result->fetch_assoc();
        $stmt->close();
        $layoutKey = $project['layout_key'];
        if (!isset($layouts[$layoutKey])) { send_json_response(array('success' => false, 'error' => 'Invalid layout selected.'), 400); }
        $templateFile = __DIR__ . '/' . $layouts[$layoutKey]['template_file'];
        if (!file_exists($templateFile)) { send_json_response(array('success' => false, 'error' => 'Template file not found.'), 500); }
        
        global $doc;
        $doc = new DOMDocument();
        @$doc->loadHTMLFile($templateFile, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        $xpath = new DOMXPath($doc);
        
        updateNode($xpath, '//*[@data-branding="company-name"]', $project['company_title']);
        updateNode($xpath, '//*[@data-branding="company-phone"]', $project['company_phone']);
        updateNode($xpath, '//*[@data-branding="company-email"]', $project['company_email']);
        updateNode($xpath, '//*[@data-branding="company-address"]', $project['company_address']);
        
        $websiteUrl = $project['company_website'];
        $websiteText = preg_replace("(^https?://)", "", $websiteUrl ); 
        updateNode($xpath, '//*[@data-branding="company-website"]', $websiteUrl, 'href');
        updateNode($xpath, '//*[@data-branding="company-website"]', $websiteText, 'innerText');
        updateNode($xpath, '//*[@data-branding="company-logo"]', $project['company_logo_path'], 'src');
        updateNode($xpath, '//*[@data-branding="hero-message"]', $project['hero_title']);
        updateNode($xpath, '//*[@data-branding="audio-title"]', $project['audio_title']);
        updateNode($xpath, '//*[@data-branding="primary-button-text"]', $project['primary_button_title']);
        updateNode($xpath, '//*[@data-branding="primary-button-link"]', $project['primary_button_link'], 'href');
        updateNode($xpath, '//*[@data-branding="secondary-button-text"]', $project['secondary_button_title']);
        updateNode($xpath, '//*[@data-branding="secondary-button-link"]', $project['secondary_button_link'], 'href');
        if (!empty($backgroundImageUrl)) { updateNode($xpath, '//*[@data-branding="background-image"]', 'background-image: url(\'' . $backgroundImageUrl . '\');', 'style'); }
        $absoluteAudioUrl = $audioUrl;
        if (!empty($audioUrl) && strpos($audioUrl, 'http') !== 0) { $absoluteAudioUrl = $base_url . ltrim($audioUrl, '/'); }
        $audioPlayerNodes = $xpath->query('//*[@data-branding="audio-player"]');
        foreach ($audioPlayerNodes as $playerNode) { $playerNode->setAttribute('src', $absoluteAudioUrl); }
        $outputDir = __DIR__ . '/outputs/' . $projectId;
        if (!is_dir($outputDir)) { mkdir($outputDir, 0755, true); }
        $outputFile = $outputDir . '/index.html';
        $doc->saveHTMLFile($outputFile);
        send_json_response(array('success' => true, 'url' => 'outputs/' . $projectId . '/index.html'));
    }
}

// --- END OF ACTION HANDLING BLOCK ---

require_once __DIR__ . '/config/config.php';
$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
$project = null;
$projectId = isset($_GET['project_id']) ? (int)$_GET['project_id'] : 0;
if ($projectId > 0) {
    $stmt = $mysqli->prepare("SELECT * FROM `projects` WHERE `id` = ?");
    $stmt->bind_param('i', $projectId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $project = $result->fetch_assoc();
    }
    $stmt->close();
}
if ($project === null) {
    $mysqli->query("INSERT INTO `projects` (project_name) VALUES ('New Project')");
    $newProjectId = $mysqli->insert_id;
    $mysqli->close();
    header("Location: " . $protocol . $host . $_SERVER['PHP_SELF'] . "?project_id=" . $newProjectId);
    exit;
}
$mysqli->close();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$layouts = array(
    "blue-modern" => array("name" => "Blue Modern", "font" => "Inter", "theme" => "Clean blue, light background, blue accent buttons, subtle gradients.", "template_file" => "web_templates/blue_modern.html"),
    "dark-elegance" => array("name" => "Dark Elegance", "font" => "Montserrat", "theme" => "Dark title bar, dark hero overlay, gold accent buttons, modern and elegant.", "template_file" => "web_templates/dark_elegance.html"),
    "fresh-green" => array("name" => "Fresh Green", "font" => "Nunito", "theme" => "Light, fresh green accents, rounded buttons, soft and friendly.", "template_file" => "web_templates/fresh_green.html"),
    "vivid-purple" => array("name" => "Vivid Purple", "font" => "Poppins", "theme" => "Vivid purple gradients, white text, bold and energetic.", "template_file" => "web_templates/vivid_purple.html"),
    "minimalist-gray" => array("name" => "Minimalist Gray", "font" => "Source Sans Pro", "theme" => "Minimal, neutral grays, flat buttons, understated and professional.", "template_file" => "web_templates/minimalist_gray.html")
);
$popover_content_html = "<ul class='list-unstyled mb-0'>";
foreach ($layouts as $layout) {
    $popover_content_html .= "<li class='mb-2'><strong>" . htmlspecialchars($layout['name']) . "</strong><br><small>Font: " . htmlspecialchars($layout['font']) . "<br>Theme: " . htmlspecialchars($layout['theme']) . "</small></li>";
}
$popover_content_html .= "</ul>";
$languages = array( "en-US" => "English (USA)", "en-GB" => "English (UK)", "es-ES" => "Spanish (Spain)", "fr-FR" => "French (France)", "de-DE" => "German (Germany)", "it-IT" => "Italian (Italy)", "pt-BR" => "Portuguese (Brazil)", "pt-PT" => "Portuguese (Portugal)", "ru-RU" => "Russian (Russia)", "zh-CN" => "Chinese (Mandarin)", "ja-JP" => "Japanese (Japan)", "ko-KR" => "Korean (South Korea)", "ar-SA" => "Arabic (Saudi Arabia)", "hi-IN" => "Hindi (India)", "bn-BD" => "Bangla (Bangladesh)", "id-ID" => "Indonesian (Indonesia)", "nl-NL" => "Dutch (Netherlands)", "pl-PL" => "Polish (Poland)", "sv-SE" => "Swedish (Sweden)", "tr-TR" => "Turkish (Turkey)", "vi-VN" => "Vietnamese (Vietnam)", "th-TH" => "Thai (Thailand)", "da-DK" => "Danish (Denmark)", "fi-FI" => "Finnish (Finland)", "no-NO" => "Norwegian (Norway)", "cs-CZ" => "Czech (Czech Republic)", "hu-HU" => "Hungarian (Hungary)", "el-GR" => "Greek (Greece)", "he-IL" => "Hebrew (Israel)", "ro-RO" => "Romanian (Romania)", "sk-SK" => "Slovak (Slovakia)", "uk-UA" => "Ukrainian (Ukraine)", "ms-MY" => "Malay (Malaysia)", "fil-PH" => "Filipino (Philippines)", "ca-ES" => "Catalan (Spain)", "hr-HR" => "Croatian (Croatia)", "lt-LT" => "Lithuanian (Lithuania)", "lv-LV" => "Latvian (Latvia)", "sl-SI" => "Slovenian (Slovenia)", "et-EE" => "Estonian (Estonia)", "ga-IE" => "Irish (Ireland)", "is-IS" => "Icelandic (Iceland)", "cy-GB" => "Welsh (Wales)", "bg-BG" => "Bulgarian (Bulgaria)", "sr-RS" => "Serbian (Serbia)", "sw-KE" => "Swahili (Kenya)", "ta-MY" => "Tamil (Malaysia)", "fa-IR" => "Persian (Iran)", "km-KH" => "Khmer (Cambodia)", "mt-MT" => "Maltese (Malta)", "mk-MK" => "Macedonian (Macedonia)", "sq-AL" => "Albanian (Albania)" );
asort($languages);
$times = array();
for ($i = 15; $i <= 60; $i += 15) {
    $times[] = array('value' => $i, 'label' => $i . ' seconds');
}
for ($i = 90; $i <= 1800; $i += 30) {
    $minutes = floor($i / 60);
    $seconds = $i % 60;
    $label = $minutes . ' minute' . ($minutes > 1 ? 's' : '');
    if ($seconds > 0) {
    $label .= ' ' . $seconds . ' seconds';
    }
    $times[] = array('value' => $i, 'label' => $label);
}
$font_families = ['Arial', 'Helvetica', 'Times New Roman', 'Georgia', 'Courier New', 'Verdana', 'Impact', 'Comic Sans MS', 'Inter', 'Montserrat', 'Nunito', 'Poppins', 'Source Sans Pro'];
sort($font_families);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AxiMate Content Studio</title>
    <script>
    window.TEMPLATE_BASE_URL = "<?php echo htmlspecialchars($base_url, ENT_QUOTES, 'UTF-8'); ?>";
    window.APP_BASE_URL = "<?php echo htmlspecialchars($base_url, ENT_QUOTES, 'UTF-8'); ?>";
    </script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;900&family=Lato&family=Montserrat&family=Nunito&family=Open+Sans&family=Poppins&family=Roboto&family=Source+Sans+Pro&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fabric.js/5.3.0/fabric.min.js"></script>
<style>
    /* Base & Layout Styles */
    body { font-family: 'Inter', sans-serif; background-color: #f8f9fa; overflow-x: hidden; }
    .w-full{width:100%}
    .navbar { background-color: #ffffff; border-bottom: 1px solid #e0e0e0; }
    .card { border: none; border-radius: 10px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05); margin-bottom: 20px; overflow: visible !important; }
    .form-control, .form-select, .btn { border-radius: 8px; }
    .container-fluid { overflow-x: visible !important; max-height: 100vh !important; overflow-y: auto !important; }
    body { font-family: 'Inter', sans-serif; background-color: #f8f9fa; overflow-x: hidden; overflow-y: auto; max-height: 100vh; }
    .script-editor-tabs .nav-link { border: none; border-bottom: 2px solid transparent; border-radius: 0; color: #6c757d; padding-left: 0; padding-right: 1.5rem; }
    .script-editor-tabs .nav-link.active { border-bottom-color: #0d6efd; color: #0d6efd; font-weight: 500; }
    .script-editor-toolbar { background-color: #f8f9fa; padding: 8px; border: 1px solid #dee2e6; border-bottom: none; border-top-left-radius: 8px; border-top-right-radius: 8px; }
    .script-editor-toolbar .btn-group .btn { box-shadow: none; transform: none; border-radius: 4px; margin: 0 2px; }
    #script-result-area, #ssml-result-area { border: 1px solid #ced4da; border-top: none; border-radius: 0 0 8px 8px; padding: 10px; min-height: 200px; resize: vertical; overflow: auto; background-color: #f8f9fa; white-space: pre-wrap; }
    #ssml-result-area { font-family: 'Courier New', monospace; font-size: 0.9rem; min-height: 150px; }
    #script-result-area:focus, #ssml-result-area:focus { outline: 0; border-color: #86b7fe; box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, .25); background-color: #fff; }
    .audio-result-item { display: flex; align-items: center; justify-content: space-between; background-color: #f1f1f1; padding: 10px 15px; border-radius: 8px; margin-top: 10px; }
    .audio-result-item > span:first-child { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin-right: 1rem; }
    .audio-result-item .icons { flex-shrink: 0; display: flex; align-items: center; }
    .test-editor-container { background: white; border-radius: 10px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); overflow: visible !important; margin-bottom: 20px; }
    .test-editor-sidebar { background: #f8f9fa; border-right: 1px solid #dee2e6; padding: 20px; min-height: auto; max-height: none; overflow-y: visible; order: 1; }
    .test-editor-canvas-area { position: relative; background: #ffffff; min-height: 500px; height: auto !important; max-height: none !important; overflow: visible !important; padding: 0 !important; margin: 0 !important; order: 2; }
    .test-toolbar { background: #e9ecef; padding: 10px; border-bottom: 1px solid #dee2e6; display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
    .test-toolbar button, .test-toolbar input, .test-toolbar select { height: 35px; border: 1px solid #ced4da; border-radius: 5px; font-size: 13px; }
    .test-toolbar button { min-width: 35px; background: white; color: #495057; padding: 5px 8px; }
    .test-toolbar button:hover:not(:disabled) { background: #e9ecef; }
    .test-toolbar button.active { background: #0d6efd; color: white; border-color: #0d6efd; }
    .test-toolbar button:disabled { opacity: 0.5; cursor: not-allowed; }
    .test-toolbar-group { display: flex; gap: 3px; align-items: center; margin-right: 10px; }
    .test-toolbar-label { font-size: 12px; color: #6c757d; margin-right: 5px; }
    .test-shape-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin-bottom: 20px; }
    .test-shape-btn { aspect-ratio: 1; display: flex; align-items: center; justify-content: center; border: 2px solid #dee2e6; background: white; border-radius: 8px; cursor: pointer; transition: all 0.2s; padding: 8px; }
    .test-shape-btn:hover { border-color: #0d6efd; transform: translateY(-2px); }
    .test-shape-btn.creating { border-color: #28a745; background-color: #d4edda; }
    .test-canvas-container { height: auto !important; min-height: 500px; max-height: none !important; }
    .final-outputs-preview { display: flex; flex-direction: column; }
    .test-canvas-wrapper { position: relative; width: 100% !important; height: 100% !important; background: white; border: none !important; margin: 0 !important; padding: 0 !important; box-sizing: border-box !important; display: block !important; justify-content: flex-start !important; align-items: flex-start !important; }
    #aximate-canvas { display: block !important; cursor: crosshair; border: 1px solid #dee2e6; border-radius: 6px; box-sizing: border-box !important; width: calc(100% - 2px) !important; height: auto !important; max-width: calc(100% - 2px) !important; max-height: 100% !important; min-width: unset !important; min-height: unset !important; margin: 0 !important; padding: 0 !important; left: 0 !important; right: 0 !important; position: static !important; transform: none !important; float: none !important; }
    .test-placeholder { position: absolute; color: #6c757d; font-size: 1.2em; z-index: 1; top: 50%; left: 50%; transform: translate(-50%, -50%); pointer-events: none; }
    .test-color-input { width: 40px; height: 35px; padding: 2px; border: 1px solid #ced4da; border-radius: 5px; cursor: pointer; }
    .test-number-input { width: 60px; }
    .test-select-input { width: 120px; }
    .test-section-header { font-size: 14px; font-weight: bold; color: #495057; margin: 15px 0 8px 0; padding-bottom: 5px; border-bottom: 1px solid #dee2e6; }
    .test-btn-group-custom { display: flex; gap: 5px; margin-bottom: 10px; }
    .test-btn-group-custom .btn { flex: 1; font-size: 12px; padding: 8px 5px; }
    .feedback-toast { position: fixed; top: 20px; right: 20px; z-index: 10000; padding: 12px 20px; border-radius: 8px; color: white; font-weight: 500; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15); transform: translateX(400px); transition: transform 0.3s ease; }
    .feedback-toast.show { transform: translateX(0); }
    .feedback-toast.success { background-color: #28a745; }
    .feedback-toast.error { background-color: #dc3545; }
    .feedback-toast.info { background-color: #17a2b8; }
    .final-outputs-container { display: flex !important; flex-direction: column; gap: 20px; visibility: visible !important; opacity: 1 !important; height: auto !important; overflow: visible !important; }
    .final-outputs-controls { padding: 20px; border: 1px solid #dee2e6; border-radius: 8px; background-color: #ffffff; display: block !important; visibility: visible !important; overflow: visible !important; }
    .card:has(.final-outputs-container), .card .final-outputs-container, .card .final-outputs-controls, .card .final-outputs-preview { display: block !important; visibility: visible !important; opacity: 1 !important; overflow: visible !important; }
    #layoutPreviewFrame { width: 100% !important; border: none; display: none; background-color: #fff; overflow: hidden !important; }
    .layout-preview-placeholder { color: #6c757d; font-size: 1.1rem; text-align: center; margin: auto; min-height: 200px; display: flex; align-items: center; justify-content: center; }
    .info-icon { cursor: help; color: #6c757d; transition: color 0.2s ease-in-out; }
    .info-icon:hover { color: #0d6efd; }
    .popover { max-width: 320px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); z-index: 1060; }
    .full-screen-modal .modal-body { overflow: auto; background-color: #f0f0f0; text-align: center; }
    #imageLibraryBody { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 1rem; }
    #imageLibraryBody img { width: 100%; height: 100px; object-fit: cover; cursor: pointer; border-radius: 8px; border: 2px solid transparent; transition: border-color 0.2s ease; }
    #imageLibraryBody img:hover { border-color: #0d6efd; }
    @media (max-width: 767.98px) { html { font-size: 14px; } .navbar-brand span, .navbar-brand i { font-size: 1rem; } .card { padding: 1rem !important; } }
    .background-image-sec #backgroundFileStatus{border-top-right-radius:0;border-bottom-right-radius:0}
    .background-image-sec .input-group button {height:38px;margin-top: .5rem;border-radius:0;font-size:14px;border-color:#dee2e6;background:#eee;color:#333}
    .background-image-sec .input-group #browseServerBtn{border-top-right-radius:8px;border-bottom-right-radius:8px}
    .background-image-sec .input-group button:hover{background:#0d6efd;color:#fff}
	#format-emphasize, #format-whisper, #format-add-pause { display: inline-block !important; }
    #learnMoreLink { font-weight: 500; }
    .style-controls .form-control, .style-controls .form-select, .style-controls .btn-group .btn { height: 30px; font-size: 0.8rem; padding: 0.25rem 0.5rem; }
    .style-controls .form-control-color { padding: 0.1rem; height: 30px; }
    .style-controls .form-label { margin-bottom: 0.25rem !important; }
    /* NEW TOGGLE SWITCH STYLES */
    .voice-engine-toggle { display: flex; justify-content: space-between; align-items: center; background-color: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; padding: 0.75rem 1rem; margin-bottom: 1rem; }
    .voice-engine-toggle .form-check-label { font-weight: bold; }
    .voice-engine-toggle .form-switch .form-check-input { width: 3em; height: 1.5em; margin-left: 1em; }
</style>
</head>
<body>
    <input type="hidden" id="projectId" value="<?php echo htmlspecialchars($project['id'], ENT_QUOTES, 'UTF-8'); ?>">
    <nav class="navbar navbar-expand-lg navbar-light bg-white">
    <div class="container-fluid px-2 px-md-4">
    <div class="d-flex align-items-center gap-2 gap-md-4">
    <a class="navbar-brand d-flex align-items-center" href="#">
    <img src="<?php echo htmlspecialchars($project['company_logo_path'] ? $project['company_logo_path'] : 'https://www.axiumpro.com//images/ai_icons/aximate_logo.png', ENT_QUOTES, 'UTF-8'); ?>" alt="Customer Logo" class="d-inline-block align-text-top rounded-circle me-3" id="customerLogoPreview" width="40" height="40">
    <span class="fw-bold fs-5 d-none d-sm-inline" id="companyTitleDisplay"><?php echo htmlspecialchars($project['company_title'], ENT_QUOTES, 'UTF-8'); ?></span>
    </a>
    <span class="text-muted d-flex align-items-center"><i class="fas fa-phone-alt me-2"></i><span id="companyPhoneDisplay"><?php echo htmlspecialchars($project['company_phone'], ENT_QUOTES, 'UTF-8'); ?></span></span>
    </div>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
    <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
    <ul class="navbar-nav align-items-center">
    <li class="nav-item"><a class="nav-link active" href="index.php?project_id=<?php echo htmlspecialchars($projectId, ENT_QUOTES, 'UTF-8'); ?>">Project Home</a></li>
    <li class="nav-item"><a class="nav-link" href="custom-voices.php?project_id=<?php echo htmlspecialchars($projectId, ENT_QUOTES, 'UTF-8'); ?>">Custom Voices</a></li>
    <li class="nav-item"><a class="nav-link" id="learnMoreLink" href="#">Learn More <i class="fas fa-play-circle"></i></a></li>
    </ul>
    </div>
    </div>
    </nav>
    <div class="container-fluid mt-4 px-2 px-md-4">
    <div class="row">
    <!-- Left Panel -->
    <div class="col-12 col-lg-4 mb-4 mb-lg-0">
    <div class="card p-3 p-lg-4">
    <h5 class="mb-3">Project Details</h5>
    <div class="mb-3"><input type="text" class="form-control autosave-field" id="projectName" placeholder="My Project Name" data-db-field="project_name" value="<?php echo htmlspecialchars($project['project_name'], ENT_QUOTES, 'UTF-8'); ?>"></div>
    <div class="mb-4"><button class="btn btn-outline-secondary w-100 py-2" data-bs-toggle="modal" data-bs-target="#aiScriptGeneratorModal">Generate Script...</button></div>
		<div class="mb-4">
			<ul class="nav nav-tabs script-editor-tabs" id="scriptTab" role="tablist">
				<li class="nav-item" role="presentation">
					<button class="nav-link active" id="script-result-tab" data-bs-toggle="tab" data-bs-target="#script-result" type="button" role="tab">Script</button>
				</li>
				<li class="nav-item" role="presentation">
					<button class="nav-link" id="ssml-result-tab" data-bs-toggle="tab" data-bs-target="#ssml-result" type="button" role="tab">SSML</button>
				</li>
			</ul>
			<div class="tab-content" id="scriptTabContent">
				<div class="tab-pane fade show active" id="script-result" role="tabpanel">
					<div class="script-editor-wrapper">
						<div class="script-editor-toolbar">
							<div class="btn-group btn-group-sm" role="group">
								<button type="button" id="format-emphasize" class="btn btn-light" title="Emphasize Selection"><i class="fas fa-bold"></i></button>
								<button type="button" id="format-whisper" class="btn btn-light" title="Whisper Selection"><i class="fas fa-comment-dots"></i></button>
								<button type="button" id="format-add-pause" class="btn btn-light" title="Insert Long Dramatic Pause"><i class="fas fa-clock"></i></button>
							</div>
						</div>
						<div id="script-result-area" contenteditable="true" class="form-control" style="height: auto; min-height: 150px;" placeholder="Your generated script will appear here."></div>
					</div>
				</div>
				<div class="tab-pane fade" id="ssml-result" role="tabpanel">
					<div id="ssml-result-area" contenteditable="true" class="form-control" style="height: auto; min-height: 150px;" placeholder="SSML will be generated here."></div>
				</div>
			</div>
		</div>

		<h5 class="mb-3">Voice Configuration</h5>
        <div class="voice-engine-toggle">
            <label class="form-check-label" for="useCustomEngineSwitch">Custom Voice</label>
            <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" role="switch" id="useCustomEngineSwitch">
            </div>
        </div>
        <div class="mb-3">
            <label for="languageSelect" class="form-label fw-bold">Voice Language</label>
            <select id="languageSelect" class="form-select">
                <option value="">Loading Languages...</option>
            </select>
        </div>
        <div class="d-flex justify-content-end mb-2">
            <button id="syncSpeakersBtn" class="btn btn-sm btn-outline-secondary" title="Update the speaker list below to match the speakers found in the script.">
                <i class="fas fa-sync-alt me-1"></i> Sync Speakers from Script
            </button>
        </div>
		<div id="voice-config-container" class="mb-3"></div>

		<div class="mb-3"><button id="addSpeakerBtn" class="btn btn-outline-primary w-100 mb-3" type="button">+ Add Speaker</button></div>
		<div class="mb-4"><button class="btn btn-primary w-100 py-2" id="generateAudioBtn">Generate Audio</button></div>
		<h5 class="mb-3">Audio Results</h5>
		<div class="audio-results-list"></div>
		</div> 
		<div id="websiteBrandingCard" class="card p-3 p-lg-4 mt-4">
        <h5 class="mb-3">Website Branding</h5>
        
        <div class="mb-3">
            <label class="form-label">Company Logo</label>
            <div class="input-group">
                <input type="text" class="form-control autosave-field" id="companyLogoPath" placeholder="No logo selected." readonly data-db-field="company_logo_path" value="<?php echo htmlspecialchars(isset($project['company_logo_path']) ? $project['company_logo_path'] : '', ENT_QUOTES, 'UTF-8'); ?>">
                <button class="btn btn-outline-secondary" type="button" id="browseLogoComputerBtn">Computer</button>
                <button class="btn btn-outline-info" type="button" id="browseLogoServerBtn">Server</button>
            </div>
            <input type="file" id="companyLogoUploadInput" accept="image/*" style="display:none;">
        </div>
        <div class="mb-3"><label for="companyTitleInput" class="form-label">Company Title</label><input type="text" class="form-control autosave-field" id="companyTitleInput" data-db-field="company_title" value="<?php echo htmlspecialchars(isset($project['company_title']) ? $project['company_title'] : '', ENT_QUOTES, 'UTF-8'); ?>"></div>
        <div class="mb-3"><label for="companyPhoneInput" class="form-label">Telephone</label><input type="tel" class="form-control autosave-field" id="companyPhoneInput" data-db-field="company_phone" value="<?php echo htmlspecialchars(isset($project['company_phone']) ? $project['company_phone'] : '', ENT_QUOTES, 'UTF-8'); ?>"></div>
        <div class="mb-3"><label for="companyEmailInput" class="form-label">Email</label><input type="email" class="form-control autosave-field" id="companyEmailInput" placeholder="contact@yourcompany.com" data-db-field="company_email" value="<?php echo htmlspecialchars(isset($project['company_email']) ? $project['company_email'] : '', ENT_QUOTES, 'UTF-8'); ?>"></div>
        <div class="mb-3"><label for="companyAddressInput" class="form-label">Address</label><input type="text" class="form-control autosave-field" id="companyAddressInput" placeholder="123 Business St, City" data-db-field="company_address" value="<?php echo htmlspecialchars(isset($project['company_address']) ? $project['company_address'] : '', ENT_QUOTES, 'UTF-8'); ?>"></div>
        <div class="mb-3"><label for="companyWebsiteInput" class="form-label">Website URL</label><input type="url" class="form-control autosave-field" id="companyWebsiteInput" placeholder="https://www.yourcompany.com" data-db-field="company_website" value="<?php echo htmlspecialchars(isset($project['company_website']) ? $project['company_website'] : '', ENT_QUOTES, 'UTF-8'); ?>"></div>
        <hr class="my-4">
        <h6 class="mb-3">Hero & Audio Content</h6>
        <div class="mb-3">
            <label for="heroTitleInput" class="form-label">Hero Title</label>
            <textarea class="form-control autosave-field" id="heroTitleInput" rows="3" placeholder="A compelling message for your webpage hero section." data-db-field="hero_title"><?php echo htmlspecialchars(isset($project['hero_title']) ? $project['hero_title'] : '', ENT_QUOTES, 'UTF-8'); ?></textarea>
        </div>
        
        <div class="p-3 border rounded mb-3 style-controls">
            <label class="form-label fw-bold small mb-2">Hero Title Styling</label>
            <div class="row g-2 align-items-center">
                <div class="col-6 col-md-3">
                    <label class="form-label small">Color</label>
                    <input type="color" class="form-control form-control-color w-100 autosave-field" id="heroFontColor" data-db-field="hero_font_color" value="<?php echo htmlspecialchars(isset($project['hero_font_color']) ? $project['hero_font_color'] : '#FFFFFF', ENT_QUOTES, 'UTF-8'); ?>">
                </div>
                <div class="col-6 col-md-3">
                    <label class="form-label small">Size (px)</label>
                    <input type="number" class="form-control autosave-field" id="heroFontSize" data-db-field="hero_font_size" value="<?php echo htmlspecialchars(isset($project['hero_font_size']) ? $project['hero_font_size'] : '48', ENT_QUOTES, 'UTF-8'); ?>" min="12" max="120">
                </div>
                <div class="col-12 col-md-6">
                     <label class="form-label small">Font</label>
                    <select class="form-select autosave-field" id="heroFontFamily" data-db-field="hero_font_family">
                        <?php $hero_font_family = isset($project['hero_font_family']) ? $project['hero_font_family'] : 'Inter'; ?>
                        <?php foreach($font_families as $font): ?>
                        <option value="<?php echo $font; ?>" <?php echo ($hero_font_family === $font) ? 'selected' : ''; ?>><?php echo $font; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12 col-md-6">
                    <label class="form-label small">Style</label>
                    <div class="btn-group w-100" role="group">
                        <input type="checkbox" class="btn-check autosave-field" id="heroFontBold" data-db-field="hero_font_bold" <?php echo (isset($project['hero_font_bold']) && $project['hero_font_bold']) ? 'checked' : ''; ?>>
                        <label class="btn btn-outline-secondary" for="heroFontBold"><i class="fas fa-bold"></i></label>
                        <input type="checkbox" class="btn-check autosave-field" id="heroFontItalic" data-db-field="hero_font_italic" <?php echo (isset($project['hero_font_italic']) && $project['hero_font_italic']) ? 'checked' : ''; ?>>
                        <label class="btn btn-outline-secondary" for="heroFontItalic"><i class="fas fa-italic"></i></label>
                        <input type="checkbox" class="btn-check autosave-field" id="heroFontUnderline" data-db-field="hero_font_underline" <?php echo (isset($project['hero_font_underline']) && $project['hero_font_underline']) ? 'checked' : ''; ?>>
                        <label class="btn btn-outline-secondary" for="heroFontUnderline"><i class="fas fa-underline"></i></label>
                    </div>
                </div>
                <div class="col-12 col-md-6">
                     <label class="form-label small">Position</label>
                     <select class="form-select autosave-field" id="heroPosition" data-db-field="hero_position">
                        <?php $hero_position = isset($project['hero_position']) ? $project['hero_position'] : 'center-center'; ?>
                        <option value="center-center" <?php echo ($hero_position === 'center-center') ? 'selected' : ''; ?>>Middle Center</option>
                        <option value="flex-start-flex-start" <?php echo ($hero_position === 'flex-start-flex-start') ? 'selected' : ''; ?>>Top Left</option>
                        <option value="center-flex-start" <?php echo ($hero_position === 'center-flex-start') ? 'selected' : ''; ?>>Top Center</option>
                        <option value="flex-end-flex-start" <?php echo ($hero_position === 'flex-end-flex-start') ? 'selected' : ''; ?>>Top Right</option>
                        <option value="flex-start-center" <?php echo ($hero_position === 'flex-start-center') ? 'selected' : ''; ?>>Middle Left</option>
                        <option value="flex-end-center" <?php echo ($hero_position === 'flex-end-center') ? 'selected' : ''; ?>>Middle Right</option>
                        <option value="flex-start-flex-end" <?php echo ($hero_position === 'flex-start-flex-end') ? 'selected' : ''; ?>>Bottom Left</option>
                        <option value="center-flex-end" <?php echo ($hero_position === 'center-flex-end') ? 'selected' : ''; ?>>Bottom Center</option>
                        <option value="flex-end-flex-end" <?php echo ($hero_position === 'flex-end-flex-end') ? 'selected' : ''; ?>>Bottom Right</option>
                    </select>
                </div>
            </div>
        </div>
        <hr>
        <div class="mb-3">
            <label for="audioTitleInput" class="form-label">Audio Section Title</label>
            <input type="text" class="form-control autosave-field" id="audioTitleInput" placeholder="e.g., Hear Our Story" data-db-field="audio_title" value="<?php echo htmlspecialchars(isset($project['audio_title']) ? $project['audio_title'] : '', ENT_QUOTES, 'UTF-8'); ?>">
        </div>
         <div class="p-3 border rounded mb-3 style-controls">
            <label class="form-label fw-bold small mb-2">Audio Title Styling</label>
            <div class="row g-2 align-items-center">
                <div class="col-6 col-md-3">
                    <label class="form-label small">Color</label>
                    <input type="color" class="form-control form-control-color w-100 autosave-field" id="audioFontColor" data-db-field="audio_font_color" value="<?php echo htmlspecialchars(isset($project['audio_font_color']) ? $project['audio_font_color'] : '#000000', ENT_QUOTES, 'UTF-8'); ?>">
                </div>
                <div class="col-6 col-md-3">
                    <label class="form-label small">Size (px)</label>
                    <input type="number" class="form-control autosave-field" id="audioFontSize" data-db-field="audio_font_size" value="<?php echo htmlspecialchars(isset($project['audio_font_size']) ? $project['audio_font_size'] : '24', ENT_QUOTES, 'UTF-8'); ?>" min="12" max="100">
                </div>
                <div class="col-12 col-md-6">
                    <label class="form-label small">Font</label>
                    <select class="form-select autosave-field" id="audioFontFamily" data-db-field="audio_font_family">
                        <?php $audio_font_family = isset($project['hero_font_family']) ? $project['hero_font_family'] : 'Inter'; ?>
                        <?php foreach($font_families as $font): ?>
                        <option value="<?php echo $font; ?>" <?php echo ($audio_font_family === $font) ? 'selected' : ''; ?>><?php echo $font; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12 col-md-6">
                    <label class="form-label small">Style</label>
                    <div class="btn-group w-100" role="group">
                        <input type="checkbox" class="btn-check autosave-field" id="audioFontBold" data-db-field="audio_font_bold" <?php echo (isset($project['audio_font_bold']) && $project['audio_font_bold']) ? 'checked' : ''; ?>>
                        <label class="btn btn-outline-secondary" for="audioFontBold"><i class="fas fa-bold"></i></label>
                        <input type="checkbox" class="btn-check autosave-field" id="audioFontItalic" data-db-field="audio_font_italic" <?php echo (isset($project['audio_font_italic']) && $project['audio_font_italic']) ? 'checked' : ''; ?>>
                        <label class="btn btn-outline-secondary" for="audioFontItalic"><i class="fas fa-italic"></i></label>
                        <input type="checkbox" class="btn-check autosave-field" id="audioFontUnderline" data-db-field="audio_font_underline" <?php echo (isset($project['audio_font_underline']) && $project['audio_font_underline']) ? 'checked' : ''; ?>>
                        <label class="btn btn-outline-secondary" for="audioFontUnderline"><i class="fas fa-underline"></i></label>
                    </div>
                </div>
            </div>
        </div>
        <hr>
        <div class="mb-3 p-3 border rounded">
            <label class="form-label fw-bold">Primary Button</label>
            <div class="row g-2">
                <div class="col-12"><label for="primaryBtnTitle" class="form-label small">Title</label><input type="text" class="form-control autosave-field" id="primaryBtnTitle" data-db-field="primary_button_title" value="<?php echo htmlspecialchars(isset($project['primary_button_title']) ? $project['primary_button_title'] : '', ENT_QUOTES, 'UTF-8'); ?>"></div>
                <div class="col-12"><label for="primaryBtnLink" class="form-label small">Link (URL, PDF, MP3)</label><input type="text" class="form-control autosave-field" id="primaryBtnLink" placeholder="https://example.com/signup" data-db-field="primary_button_link" value="<?php echo htmlspecialchars(isset($project['primary_button_link']) ? $project['primary_button_link'] : '', ENT_QUOTES, 'UTF-8'); ?>"></div>
            </div>
        </div>
        <div class="mb-3 p-3 border rounded">
            <label class="form-label fw-bold">Secondary Button</label>
            <div class="row g-2">
                <div class="col-12"><label for="secondaryBtnTitle" class="form-label small">Title</label><input type="text" class="form-control autosave-field" id="secondaryBtnTitle" data-db-field="secondary_button_title" value="<?php echo htmlspecialchars(isset($project['secondary_button_title']) ? $project['secondary_button_title'] : '', ENT_QUOTES, 'UTF-8'); ?>"></div>
                <div class="col-12"><label for="secondaryBtnLink" class="form-label small">Link (URL, PDF, MP3)</label><input type="text" class="form-control autosave-field" id="secondaryBtnLink" placeholder="https://example.com/features" data-db-field="secondary_button_link" value="<?php echo htmlspecialchars(isset($project['secondary_button_link']) ? $project['secondary_button_link'] : '', ENT_QUOTES, 'UTF-8'); ?>"></div>
            </div>
        </div>
    </div>
    </div>
    <!-- Right Panel -->
    <div class="col-12 col-lg-8">
    <div class="card p-3 p-lg-4">
    <h5 class="mb-4">Create a Background Image</h5>
    <div class="mb-3"><label for="imageSource" class="form-label">Image Source</label><select class="form-select" id="imageSource"><option value="ai_description" selected>AI Generate from Description</option><option value="upload">Upload My Own Image</option></select></div>
    <div id="uploadImageOptions" class="mb-3" style="display: none;"><label for="imageUpload" class="form-label">Upload Image</label><input class="form-control" type="file" id="imageUpload" accept="image/*"></div>
    <div class="mb-3" id="generateAiImageContainer">
    <label for="generateAiImage" class="form-label">Generate AI Image</label>
    <select class="form-select" id="generateAiImage">
    <option value="script_result" selected>Based on Script Result</option>
    <option value="custom_image">Custom Image</option>
    </select>
    </div>
    <div id="aiDescriptionOptions" class="mb-3" style="display: none;">
    <label for="aiDescriptionPrompt" class="form-label">Describe the Image</label>
    <textarea class="form-control" id="aiDescriptionPrompt" rows="3" placeholder="e.g., 'A serene forest at sunset with a small cabin.'"></textarea>
    </div>
    <div class="mb-3"><label class="form-label">Output Size (pixels)</label><div class="input-group"><input type="number" class="form-control" id="outputWidth" value="1024"><span class="input-group-text">x</span><input type="number" class="form-control" id="outputHeight" value="1024"></div></div>
    <div class="mb-4"><button class="btn btn-primary w-100 py-2" id="generateImageBtn">Generate Image</button></div>
    
    <h5 class="mb-3">Image Preview & Editor</h5>
    <div class="test-editor-container">
      <div class="row g-0">
        <div class="col-md-3 test-editor-sidebar order-md-1">
                <h5 class="mb-3"><i class="fas fa-tools me-2"></i>Tools</h5>
                <button class="btn btn-outline-primary w-100 mb-3" id="addTestTextBtn"><i class="fas fa-font me-2"></i>Add Text</button>
                <button class="btn btn-outline-secondary w-100 mb-3" id="addTestImageBtn"><i class="fas fa-image me-2"></i>Add Image</button>
                <input type="file" id="testImageUpload" accept="image/*" style="display: none;">
                <div class="test-section-header">Basic Shapes</div>
                <div class="test-shape-grid">
                    <div class="test-shape-btn" data-shape="rectangle" title="Rectangle"><i class="fas fa-square fa-lg"></i></div>
                    <div class="test-shape-btn" data-shape="circle" title="Circle"><i class="fas fa-circle fa-lg"></i></div>
                    <div class="test-shape-btn" data-shape="star" title="Star"><i class="fas fa-star fa-lg"></i></div>
                    <div class="test-shape-btn" data-shape="triangle" title="Triangle"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L22 22H2L12 2Z"/></svg></div>
                    <div class="test-shape-btn" data-shape="right-triangle" title="Right Triangle"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M2 2L22 12L2 22V2Z"/></svg></div>
                    <div class="test-shape-btn" data-shape="hexagon" title="Hexagon"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M17.5 3.5L22 12L17.5 20.5H6.5L2 12L6.5 3.5H17.5Z"/></svg></div>
                    <div class="test-shape-btn" data-shape="heart" title="Heart"><i class="fas fa-heart fa-lg"></i></div>
                    <div class="test-shape-btn" data-shape="arrow-right" title="Arrow Right"><i class="fas fa-arrow-right fa-lg"></i></div>
                    <div class="test-shape-btn" data-shape="arrow-left" title="Arrow Left"><i class="fas fa-arrow-left fa-lg"></i></div>
                </div>
                <div class="test-section-header">Lines & Connectors</div>
                <div class="test-shape-grid">
                    <div class="test-shape-btn" data-shape="solid-line" title="Solid Line"><i class="fas fa-minus fa-lg"></i></div>
                    <div class="test-shape-btn" data-shape="dotted-line" title="Dotted Line"><i class="fas fa-ellipsis-h fa-lg"></i></div>
                    <div class="test-shape-btn" data-shape="dashed-line" title="Dashed Line"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-dasharray="6 6" d="M4 12H20"/></svg></div>
                    <div class="test-shape-btn" data-shape="double-line" title="Double Line"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 10H20M4 14H20"/></svg></div>
                    <div class="test-shape-btn" data-shape="bracket-left" title="Left Bracket"><i class="fas fa-chevron-left fa-lg"></i></div>
                    <div class="test-shape-btn" data-shape="bracket-right" title="Right Bracket"><i class="fas fa-chevron-right fa-lg"></i></div>
                </div>
                <div class="test-section-header">Actions</div>
                <div class="test-btn-group-custom">
                    <button class="btn btn-outline-secondary" id="testUndoBtn" disabled title="Undo"><i class="fas fa-undo"></i></button>
                    <button class="btn btn-outline-secondary" id="testRedoBtn" disabled title="Redo"><i class="fas fa-redo"></i></button>
                </div>
                <button class="btn btn-outline-danger w-100 mb-2" id="testDeleteBtn"><i class="fas fa-trash me-2"></i>Delete Selected</button>
                <button class="btn btn-outline-warning w-100 mb-2" id="testClearBtn"><i class="fas fa-broom me-2"></i>Clear All</button>
            </div>
        <div class="col-md-9 test-editor-canvas-area order-md-2">
                <div class="test-toolbar">
                    <div class="test-toolbar-group"><span class="test-toolbar-label">Text:</span><button id="testBoldBtn" title="Bold" disabled><i class="fas fa-bold"></i></button><button id="testItalicBtn" title="Italic" disabled><i class="fas fa-italic"></i></button><button id="testUnderlineBtn" title="Underline" disabled><i class="fas fa-underline"></i></button></div>
                    <div class="test-toolbar-group"><button id="testAlignLeftBtn" title="Align Left" disabled><i class="fas fa-align-left"></i></button><button id="testAlignCenterBtn" title="Align Center" disabled><i class="fas fa-align-center"></i></button><button id="testAlignRightBtn" title="Align Right" disabled><i class="fas fa-align-right"></i></button></div>
                    <div class="test-toolbar-group"><span class="test-toolbar-label">Fill:</span><input type="color" id="testFillColor" class="test-color-input" value="#33a2e0" title="Fill Color"><label class="form-check-label" style="font-size: 12px;"><input type="checkbox" id="testTransparentFill" class="form-check-input"> None</label></div>
                    <div class="test-toolbar-group"><span class="test-toolbar-label">Border:</span><input type="color" id="testStrokeColor" class="test-color-input" value="#000000" title="Border Color"><input type="number" id="testStrokeWidth" class="form-control test-number-input" min="0" max="20" value="2" title="Border Width"></div>
                    <div class="test-toolbar-group"><span class="test-toolbar-label">Font:</span><select id="testFontFamily" class="form-select test-select-input" disabled><option value="Arial">Arial</option><option value="Helvetica">Helvetica</option><option value="Times New Roman">Times New Roman</option><option value="Georgia">Georgia</option><option value="Courier New">Courier New</option><option value="Verdana">Verdana</option><option value="Impact">Impact</option><option value="Comic Sans MS">Comic Sans MS</option></select><input type="number" id="testFontSize" class="form-control test-number-input" min="8" max="200" value="40" title="Font Size" disabled></div>
                    <div class="test-toolbar-group"><span class="test-toolbar-label">Rotate:</span><button id="testRotateLeftBtn" title="Rotate Left 15°" disabled><i class="fas fa-undo"></i></button><button id="testRotateRightBtn" title="Rotate Right 15°" disabled><i class="fas fa-redo"></i></button><input type="number" id="testRotationInput" class="form-control test-number-input" min="-360" max="360" value="0" title="Rotation (degrees)" disabled></div>
                    <div class="test-toolbar-group"><span class="test-toolbar-label">Flip:</span><button id="testFlipHBtn" title="Flip Horizontal" disabled><i class="fas fa-arrows-left-right"></i></button><button id="testFlipVBtn" title="Flip Vertical" disabled><i class="fas fa-arrows-up-down"></i></button></div>
          <div class="test-toolbar-group"><span class="test-toolbar-label">Layer:</span><button id="testBringToFrontBtn" title="Bring to Front" disabled><i class="fas fa-angles-up"></i></button><button id="testBringForwardBtn" title="Bring Forward" disabled><i class="fas fa-angle-up"></i></button><button id="testSendBackwardBtn" title="Send Backward" disabled><i class="fas fa-angle-down"></i></button><button id="testSendToBackBtn" title="Send to Back" disabled><i class="fas fa-angles-down"></i></button></div>
                </div>
                <div class="test-canvas-container">
                    <div class="test-canvas-wrapper">
                        <div class="test-placeholder" id="test-placeholder">Click a shape to add it to the canvas</div>
                        <canvas id="aximate-canvas"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="text-center text-muted mt-2" id="output-size-display-container">Output Size: <span id="output-size-display">1024px x 1024px</span></div>
    <div class="d-flex justify-content-center mt-3 mb-4">
        <button class="btn btn-outline-secondary me-2" id="downloadImageBtn" title="Download Image"><i class="fas fa-download me-2"></i>Download</button>
        <button class="btn btn-outline-primary me-2" id="saveImageBtn" title="Save Image to Server"><i class="fas fa-save me-2"></i>Save as</button>
        <button class="btn btn-outline-secondary" id="enlargeImageBtn" title="Enlarge Image"><i class="fas fa-expand me-2"></i>Enlarge</button>
    </div>
    </div>
    
    <div class="card p-3 p-lg-4 mt-4" id="final-outputs-section">
        <div class="final-outputs-container">
            <div class="final-outputs-controls">
                <h5 class="mb-4">Generate Final Outputs</h5>
                <div class="row align-items-end">
                    <div class="col-lg-4 mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <label for="layoutSelect" class="form-label mb-0">Select Layout</label>
                            <i class="fas fa-info-circle info-icon" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-placement="right" data-bs-html="true" title="Layout Theme Details" data-bs-content="<?php echo htmlspecialchars($popover_content_html, ENT_QUOTES, 'UTF-8'); ?>"></i>
                        </div>
                        <select class="form-select autosave-field" id="layoutSelect" data-db-field="layout_key">
                            <option value="">Choose a layout theme...</option>
                            <?php foreach ($layouts as $key => $layout): ?>
                                <option value="<?php echo htmlspecialchars($key, ENT_QUOTES, 'UTF-8'); ?>"
                                        data-template-file="<?php echo htmlspecialchars($layout['template_file'], ENT_QUOTES, 'UTF-8'); ?>"
                                        <?php if ($project['layout_key'] === $key) echo 'selected'; ?>>
                                    <?php echo htmlspecialchars($layout['name'], ENT_QUOTES, 'UTF-8'); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-lg-8 mb-3">
                        <label class="form-label mb-0">Background Image</label>
                        <div class="d-flex background-image-sec">
                          <input type="text" class="form-control mt-2" id="backgroundFileStatus" placeholder="No file selected." readonly>
                          <div class="input-group">
                            <button class="btn btn-outline-secondary" type="button" id="browseComputerBtn">Computer</button>
                            <button class="btn btn-outline-info" type="button" id="browseServerBtn">Server</button>
                          </div>
                          
                        </div>
                        <input type="file" id="finalBackgroundUpload" data-db-field="background_image_path" accept="image/*" style="display:none;">
                    </div>
                </div>
                <div class="row mt-4">
                  <div class="col-lg-6">
                    <button class="btn btn-primary py-2 w-full" id="generateWebpageBtn"><i class="fas fa-globe me-2"></i>Generate Webpage</button>
                  </div>
                  <div class="col-lg-6">
                    <button class="btn btn-info py-2 text-white w-full" id="generateMp4Btn"><i class="fas fa-video me-2"></i>Generate MP4</button>
                  </div>
                </div>
            </div>
            <div class="final-outputs-preview mt-4">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h5 class="mb-0">Live Preview</h5>
                    <a href="#" id="viewFullSizeLink" target="_blank" class="btn btn-sm btn-outline-secondary" title="Open in new tab"><i class="fas fa-external-link-alt me-1"></i> View Full Size</a>
                </div>
                <div id="layoutPreviewPlaceholder" class="layout-preview-placeholder">Select a layout to see a live preview.</div>
                <iframe id="layoutPreviewFrame" title="Web Template Live Preview"></iframe>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>
    </div>

<!-- Modals -->
<div class="modal fade" id="aiScriptGeneratorModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content" style="display: flex; flex-direction: column; max-height: 90vh;">
            <div class="modal-header"><h5 class="modal-title">Intelligent Content Co-Pilot</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body" style="overflow-y: auto;">
                <div id="script-generator-form">
                    <div class="mb-3"><label for="objectiveSelect" class="form-label fw-bold">1. Select Your Objective</label><select id="objectiveSelect" class="form-select"><option value="custom" selected>Custom / General Purpose</option><optgroup label="The Persuasion Engine"><option value="product_explainer">Product Explainer</option><option value="promo_cta">Promotional Offer / CTA</option><option value="testimonial">Customer Testimonial</option><option value="lead_gen">Demo Sign-up / Lead Gen</option><option value="lead_nurture">Lead Nurturing Message</option></optgroup><optgroup label="The Engagement Engine"><option value="storytelling">Narrative Storytelling</option><option value="podcast_monologue">Podcast-Style Monologue</option><option value="podcast_interview">Podcast-Style Interview</option><option value="company_update">Internal Company Update</option></optgroup><optgroup label="The Operational Engine"><option value="customer_reply">Personalized Customer Reply</option><option value="training_module">Employee Onboarding / Training</option><option value="urgent_alert">Urgent Alert / Notification</option><option value="friendly_reminder">Friendly Reminder</option></optgroup></select></div>
                    <div class="mb-3"><label for="primaryIntent" class="form-label fw-bold">2. Define the Primary Intent (in one sentence)</label><input type="text" id="primaryIntent" class="form-control" placeholder="e.g., Convince a busy executive that our product saves them time."></div>
                    <div class="mb-3"><label for="contextArea" class="form-label fw-bold">3. Provide Context</label><textarea id="contextArea" class="form-control" rows="4" placeholder="Add key talking points, product names, specific details, or a rough outline here..."></textarea><div class="d-flex justify-content-between align-items-center mt-2"><label for="backgroundDocUpload" class="btn btn-sm btn-outline-secondary"><i class="fas fa-paperclip me-1"></i> Upload Background Doc (.txt)</label><input type="file" id="backgroundDocUpload" accept=".txt" style="display:none;"><small id="docUploadStatus" class="text-muted"></small></div></div>
                    <hr class="my-4">
                    <h6 class="fw-bold">4. Add the Final Polish</h6>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="creativitySelect" class="form-label">Creativity</label>
                            <select id="creativitySelect" class="form-select">
                                <option value="0.1">Deterministic</option>
                                <option value="0.7" selected>Original</option>
                                <option value="0.9">Creative</option>
                                <option value="1.0">Imaginative</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3"><label for="toneSelect" class="form-label">Tone of Voice</label><select id="toneSelect" class="form-select"></select></div>
                        <div class="col-md-6 mb-3"><label for="timeSelect" class="form-label">Time</label><select id="timeSelect" class="form-select"><option value="">Select duration...</option><?php foreach ($times as $time): ?><option value="<?php echo htmlspecialchars($time['value'], ENT_QUOTES, 'UTF-8'); ?>" <?php echo ($time['value'] === 60) ? 'selected' : ''; ?>><?php echo htmlspecialchars($time['label'], ENT_QUOTES, 'UTF-8'); ?></option><?php endforeach; ?></select></div>
                         <div class="col-md-6 mb-3"><label for="modalLanguageSelect" class="form-label">Language</label><select id="modalLanguageSelect" class="form-select"><?php foreach ($languages as $value => $text): ?><option value="<?php echo htmlspecialchars($value, ENT_QUOTES, 'UTF-8'); ?>" <?php echo ($value === 'en-US') ? 'selected' : ''; ?>><?php echo htmlspecialchars($text, ENT_QUOTES, 'UTF-8'); ?></option><?php endforeach; ?></select></div>
						<div class="col-md-6 mb-3">
							<label for="speakerModeSelect" class="form-label">Speaker Mode</label>
							<select id="speakerModeSelect" class="form-select">
								<option value="single">Single Speaker Mode</option>
								<option value="2" selected>Multi Speaker Mode (2)</option>
								<option value="3">Multi Speaker Mode (3)</option>
								<option value="4">Multi Speaker Mode (4)</option>
								<option value="5">Multi Speaker Mode (5)</option>
							</select>
						</div>
                        <div class="col-md-6 mb-3" id="vocalStyleContainer"><label for="vocalStyleSelect" class="form-label">Vocal Performance Style</label><select id="vocalStyleSelect" class="form-select"><option value="conversational" selected>Conversational</option><option value="narrative">Narrative (Storyteller)</option><option value="energetic">Energetic (Promotional)</option><option value="authoritative">Authoritative (Educational)</option><option value="empathetic">Empathetic (Customer Service)</option></select></div>
                    </div>
                </div>
                <div id="scriptPreviewDiv" class="d-flex flex-column" style="display: none; flex-grow: 1; min-height: 0;"></div>
            </div>
            <div class="modal-footer">
                <div id="generate-footer-buttons"><button type="button" class="btn btn-outline-secondary mx-2" data-bs-dismiss="modal">Close</button><button type="button" class="btn btn-primary" id="modalGenerateScriptBtn">Generate</button></div>
                <div id="preview-footer-buttons" style="display: none;"><button type="button" class="btn btn-secondary mx-2" id="rejectScriptBtn">Go Back & Edit</button><button type="button" class="btn btn-success" id="acceptScriptBtn">Accept and Use Script</button></div>
            </div>
        </div>
    </div>
</div>
    <div class="modal fade" id="enlargeImageModal" tabindex="-1"><div class="modal-dialog modal-fullscreen"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">Enlarged Preview</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body d-flex justify-content-center align-items-center bg-light"></div></div></div></div>
    <div class="modal fade" id="imageLibraryModal" tabindex="-1"><div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">Select Image</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><div id="imageLibraryBody"></div></div></div></div></div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
      
<script id="aximate-studio-app">
    /**
     * ========================================================================
     * --- THE DEFINITIVE CMS-PROOF FETCH HELPER ---
     * ========================================================================
     */
    async function fetchAndParseJson(url, options) {
        try {
            const response = await fetch(url, options);
            const rawText = await response.text();
            if (!response.ok) {
                 // Try to parse error from JSON body first
                try {
                    const errorJson = JSON.parse(rawText);
                    throw new Error(errorJson.error || `HTTP error! Status: ${response.status}`);
                } catch (e) {
                    // If response is not JSON, use the raw text
                    throw new Error(`Server returned a non-JSON error: ${rawText.substring(0, 200)}`);
                }
            }
            return JSON.parse(rawText);
        } catch (error) {
            console.error('FetchAndParseJson Error:', error.message, 'URL:', url);
            throw error;
        }
    }
	
    window.showToast = function(message, type = 'info') {
        var toast = document.createElement('div');
        toast.className = `feedback-toast ${type}`;
        toast.textContent = message;
        document.body.appendChild(toast);
        setTimeout(() => toast.classList.add('show'), 100);
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => document.body.contains(toast) && document.body.removeChild(toast), 300);
        }, 4000);
    };

	document.addEventListener('DOMContentLoaded', function() {
        // ========================================================================
		// --- 1. GLOBAL STATE & ELEMENT REFERENCES ---
		// ========================================================================
		const userPlan = 'premium';
		let allGoogleVoices = [];
        let allHumeVoices = [];
		let availableVoices = [];
		let allLanguages = [];

		let currentlyPlayingPreview = null;
		let isUpdating = false;
		let explainerAudio = null;
		window.lastGeneratedData = null;
		window.lastAIImageUrl = null;
		const projectId = document.getElementById('projectId').value;

		const useCustomEngineSwitch = document.getElementById('useCustomEngineSwitch');
		const friendlyLanguageNames = <?php echo json_encode($languages); ?>;

		const scriptArea = document.getElementById('script-result-area');
		const ssmlArea = document.getElementById('ssml-result-area'); 
		const voiceConfigContainer = document.getElementById('voice-config-container');
		const addSpeakerBtn = document.getElementById('addSpeakerBtn');
		const generateAudioBtn = document.getElementById('generateAudioBtn');
		const syncSpeakersBtn = document.getElementById('syncSpeakersBtn');
		const languageSelect = document.getElementById('languageSelect');
		
    // ========================================================================
    // --- 2. INITIALIZATION (CORRECTED DATA HANDLING) ---
    // ========================================================================
        const googlePromise = fetchAndParseJson(`${window.APP_BASE_URL}api/get-voices.php?provider=google`);
        const humePromise = fetchAndParseJson(`${window.APP_BASE_URL}api/get-voices.php?provider=hume`);

		Promise.all([googlePromise, humePromise])
        .then(function([googleResponse, humeResponse]) {
            
            // --- START: THE DEFINITIVE FIX (Handle new data structure) ---
            allGoogleVoices = googleResponse.voices || [];
            languageCategories = googleResponse.languageCategories || {};
            allHumeVoices = humeResponse.voices || [];
            // --- END: THE DEFINITIVE FIX ---

            // Populate the new language category dropdown
            languageSelect.innerHTML = '<option value="">-- Select Language Group --</option>';
            // Create sorted array of category names
            const sortedCategories = Object.keys(languageCategories).sort((a, b) => {
                if (a === 'English') return -1; // English always first
                if (b === 'English') return 1;
                return a.localeCompare(b); // Sort others alphabetically
            });

            sortedCategories.forEach(categoryName => {
                const option = new Option(categoryName, categoryName);
                languageSelect.appendChild(option);
            });

            if (languageSelect.options.length > 1) {
                const defaultGroup = "English";
                if (Array.from(languageSelect.options).some(opt => opt.value === defaultGroup)) {
                    languageSelect.value = defaultGroup;
                } else {
                    languageSelect.selectedIndex = 1; // Fallback to the first group
                }
                updateVoiceDropdowns();
            }
        })
        .catch(function(error) {
            console.error("Fatal Error: Could not load initial voice data.", error);
            languageSelect.innerHTML = '<option>Could not load languages</option>';
            showToast(`FATAL: Could not load voice data. ${error.message}`, 'error');
        });

		// ========================================================================
		// --- 3. CORE VOICE & SCRIPT FUNCTIONS (CORRECTED FILTERING) ---
		// ========================================================================
    function updateVoiceDropdowns() {
        const useHume = useCustomEngineSwitch.checked;
        const selectedLangCategory = languageSelect.value;

        languageSelect.disabled = useHume;

        if (useHume) {
            availableVoices = allHumeVoices;
        } else {
            // --- START: THE DEFINITIVE FIX ---
            // WHY: Filter voices based on the selected Language Category.
            if (!selectedLangCategory || !languageCategories[selectedLangCategory]) {
                availableVoices = [];
            } else {
                const allowedLangCodes = languageCategories[selectedLangCategory];
                availableVoices = allGoogleVoices.filter(voice => allowedLangCodes.includes(voice.lang_code));
            }
            // --- END: THE DEFINITIVE FIX ---
        }
        
        document.querySelectorAll('.voice-select-dropdown').forEach(populateSingleVoiceDropdown);
    }
    
    function populateSingleVoiceDropdown(dropdown) {
        if (!dropdown) return;
        
        const currentVal = dropdown.value;
        dropdown.innerHTML = ''; 

        if (availableVoices.length === 0) {
            dropdown.innerHTML = '<option value="">No voices available</option>';
            return;
        }

        const voiceGroups = {};

        availableVoices.forEach(function(voice) {
            const category = voice.category || (voice.is_custom ? 'Premium Custom Voices' : 'Standard Voices');
            if (!voiceGroups[category]) {
                voiceGroups[category] = [];
            }
            voiceGroups[category].push(voice);
        });

        const sortedGroupNames = Object.keys(voiceGroups).sort((a, b) => {
            const sortOrderA = voiceGroups[a].length > 0 ? voiceGroups[a][0].sortOrder || 99 : 99;
            const sortOrderB = voiceGroups[b].length > 0 ? voiceGroups[b][0].sortOrder || 99 : 99;
            return sortOrderA - sortOrderB;
        });

        sortedGroupNames.forEach(groupName => {
            const group = document.createElement('optgroup');
            group.label = groupName;
            
            const voicesInGroup = voiceGroups[groupName];
            
            voicesInGroup.forEach(function(voice) {
                const option = new Option(voice.label, voice.id);
                
                if (voice.isDisabled) {
                    option.disabled = true;
                    option.title = 'Upgrade your plan to access this voice tier.';
                    option.style.color = '#999';
                }
                
                group.appendChild(option);
            });
            dropdown.appendChild(group);
        });
        
        if (Array.from(dropdown.options).some(opt => opt.value === currentVal)) {
            dropdown.value = currentVal;
        }
        
        togglePerformanceControls(dropdown);
    }
    
    function addSpeakerRow(name = '', isFirst = false) {
        const speakerWrapper = document.createElement('div');
        speakerWrapper.className = 'voice-config-row border rounded p-3 mb-3';
        speakerWrapper.innerHTML = `<div class="input-group mb-2"><input type="text" class="form-control" value="${name}" placeholder="Speaker Name"><select class="form-select voice-select-dropdown" style="flex-grow: 2;"><option>Select a language first</option></select><button class="btn btn-outline-secondary btn-preview-voice" type="button" title="Preview Voice"><i class="fas fa-volume-up"></i></button><button class="btn btn-outline-danger btn-remove-speaker" type="button" title="Remove Speaker" ${isFirst ? 'disabled' : ''}><i class="fas fa-times"></i></button></div><div class="d-flex align-items-center mt-2 expressiveness-control-group"><label class="form-label me-2 mb-0 small" style="width: 110px;">Expressiveness (Pitch):</label><input type="range" class="form-range expressiveness-slider" min="-15.0" max="15.0" step="0.1" value="0.0"><span class="ms-2 small" style="width: 40px;">0.0</span></div>`;
        voiceConfigContainer.appendChild(speakerWrapper);
        if (availableVoices.length > 0) {
            populateSingleVoiceDropdown(speakerWrapper.querySelector('.voice-select-dropdown'));
        }
        const expressivenessSlider = speakerWrapper.querySelector('.expressiveness-slider');
        expressivenessSlider.addEventListener('input', (e) => {
            e.target.nextElementSibling.textContent = parseFloat(e.target.value).toFixed(1);
        });
    }

    function updateUIFromScript(structuredScript) {
        if (!Array.isArray(structuredScript)) return;
        const ssmlText = structuredScript.map(line => `${line.speaker.toUpperCase()}: ${line.text}`).join('\n');
        ssmlArea.textContent = ssmlText;
        updateVisualFromSSML();
        const speakerNames = [...new Set(structuredScript.map(line => line.speaker.toUpperCase()))];
        voiceConfigContainer.innerHTML = '';
        speakerNames.forEach((name, index) => addSpeakerRow(name, index === 0));
    }
    
    function togglePerformanceControls(dropdownElement) {
        if (!dropdownElement || !dropdownElement.value) return;
        const selectedOption = dropdownElement.options[dropdownElement.selectedIndex];
        const voice = availableVoices.find(v => v.id === selectedOption.value);
        const row = dropdownElement.closest('.voice-config-row');
        if (!row || !voice) return;
        if (voice.provider && voice.provider.startsWith('hume')) {
             row.querySelectorAll('.expressiveness-control-group').forEach(el => el.style.display = 'none');
             const infoMessage = row.querySelector('.voice-info-message');
             if (infoMessage) infoMessage.style.display = 'none';
             return;
        }
        const unsupportedTypes = ['Chirp', 'Studio', 'News', 'Polyglot', 'Casual', 'HD'];
        let isUnsupported = unsupportedTypes.some(type => selectedOption.value.includes(type));
        const displayStyle = isUnsupported ? 'none' : 'flex';
        row.querySelectorAll('.expressiveness-control-group').forEach(el => el.style.display = displayStyle);
        let infoMessage = row.querySelector('.voice-info-message');
        if (!infoMessage) {
            infoMessage = document.createElement('div');
            infoMessage.className = 'voice-info-message small text-muted mt-2 p-2 rounded';
            infoMessage.style.backgroundColor = '#f8f9fa';
            infoMessage.style.border = '1px solid #e9ecef';
            row.appendChild(infoMessage);
        }
        if (isUnsupported) {
            let voiceFamily = 'this advanced voice type';
            if (selectedOption.value.includes('Chirp') || selectedOption.value.includes('HD') || selectedOption.value.includes('Studio')) { voiceFamily = 'Studio/Chirp voices'; }
            infoMessage.innerHTML = `<i class="fas fa-info-circle text-primary me-2"></i><strong>Optimized Performance:</strong> ${voiceFamily} use built-in prosody.`;
            infoMessage.style.display = 'block';
        } else {
            infoMessage.style.display = 'none';
        }
    }

    function updateSSMLFromVisual() {
        if (isUpdating) return;
        isUpdating = true;
        let ssmlOutput = "";
        scriptArea.querySelectorAll('div').forEach(lineNode => {
            const bTag = lineNode.querySelector('b');
            if (!bTag) return;
            const speakerMatch = bTag.textContent.match(/^([A-Z0-9_]+):\s*/i);
            if (speakerMatch) {
                const tempNode = lineNode.cloneNode(true);
                tempNode.querySelector('b').remove();
                let dialogue = tempNode.innerHTML.trim();
                dialogue = dialogue.replace(/<b>(.*?)<\/b>/gi, '<emphasis level="strong">$1</emphasis>')
                                 .replace(/<strong>(.*?)<\/strong>/gi, '<emphasis level="strong">$1</emphasis>')
                                 .replace(/<span data-style="whisper".*?>(.*?)<\/span>/gi, '<prosody rate="slow" volume="soft">$1</prosody>')
                                 .replace(/<span data-perform="long-pause".*?<\/span>/gi, '<break time="1s"/>');
                ssmlOutput += `${speakerMatch[1].toUpperCase()}: ${dialogue}\n`;
            }
        });
        ssmlArea.textContent = ssmlOutput.trim();
        isUpdating = false;
    }

    function updateVisualFromSSML() {
        if (isUpdating) return;
        isUpdating = true;
        const lines = ssmlArea.textContent.split('\n');
        const visualHTML = lines.map(line => {
            const speakerMatch = line.match(/^([A-Z0-9_]+):\s*(.*)/i);
            if (speakerMatch) {
                const speaker = speakerMatch[1].toUpperCase();
                let visualText = speakerMatch[2]
                    .replace(/<emphasis level="strong">(.*?)<\/emphasis>/gi, '<b>$1</b>')
                    .replace(/<prosody.*?>(.*?)<\/prosody>/gi, `<span data-style="whisper" style="border-bottom: 2px dotted #6c757d;">$1</span>`)
                    .replace(/<break.*?\/>/gi, '<span data-perform="long-pause" style="display:inline-block; width:25px;">&nbsp;</span>');
                return `<div><b>${speaker}:</b> ${visualText}</div>`;
            }
            return `<div>${line}</div>`;
        }).join('');
        scriptArea.innerHTML = visualHTML;
        isUpdating = false;
    }

    function getScriptFromSSML() {
        const audioScript = [];
        const lines = ssmlArea.textContent.split('\n');
        lines.forEach(line => {
            const speakerMatch = line.match(/^([A-Z0-9_]+):\s*(.*)/i);
            if (speakerMatch) {
                const speaker = speakerMatch[1].toUpperCase();
                const ssmlText = speakerMatch[2].trim();
                if (ssmlText) audioScript.push({ speaker, text: ssmlText });
            }
        });
        return audioScript;
    }
    // ========================================================================
    // --- 4. EVENT LISTENERS ---
    // ========================================================================

    languageSelect.addEventListener('change', updateVoiceDropdowns);

    document.addEventListener('script-generated', function(e) {
        updateUIFromScript(e.detail.structuredScript);
        setTimeout(updateVoiceDropdowns, 100);
    });

    document.getElementById('format-emphasize').addEventListener('click', () => { document.execCommand('bold', false, null); updateSSMLFromVisual(); });
    document.getElementById('format-whisper').addEventListener('click', () => { document.execCommand('insertHTML', false, `<span data-style="whisper" style="border-bottom: 2px dotted #6c757d;">${window.getSelection().toString()}</span>`); updateSSMLFromVisual(); });
    document.getElementById('format-add-pause').addEventListener('click', () => { document.execCommand('insertHTML', false, '<span data-perform="long-pause" style="display:inline-block; width:25px;">&nbsp;</span>'); updateSSMLFromVisual(); });

    scriptArea.addEventListener('input', updateSSMLFromVisual);
    ssmlArea.addEventListener('input', updateVisualFromSSML);

    addSpeakerBtn.addEventListener('click', () => {
        addSpeakerRow(`SPEAKER_${String(voiceConfigContainer.children.length + 1).padStart(2, '0')}`, false);
    });
    
    syncSpeakersBtn.addEventListener('click', () => {
        const scriptFromSSML = getScriptFromSSML();
        updateUIFromScript(scriptFromSSML);
        setTimeout(updateVoiceDropdowns, 100);
    });

    voiceConfigContainer.addEventListener('change', function(e) {
        if (e.target.classList.contains('voice-select-dropdown')) {
            togglePerformanceControls(e.target);
        }
    });

    voiceConfigContainer.addEventListener('click', function(e) {
        const previewBtn = e.target.closest('.btn-preview-voice');
        if (previewBtn) {
            const row = previewBtn.closest('.voice-config-row');
            const voiceId = row.querySelector('.voice-select-dropdown').value;
            const voice = availableVoices.find(v => v.id === voiceId);

            if (!voice) return showToast('Please select a voice.', 'error');
            
            previewBtn.disabled = true;
            previewBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
            if (currentlyPlayingPreview) currentlyPlayingPreview.pause();

            const endpoint = (voice.provider.startsWith('hume')) ? 'api/preview-hume-voice.php' : 'api/generate-audio.php';
            
            const body = (voice.provider.startsWith('hume')) 
                ? { voice: voice } 
                : { action: 'preview_voice', voiceId: voice.id, provider: voice.provider };

            fetchAndParseJson(window.APP_BASE_URL + endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            })
            .then(data => {
                if (!data.success) throw new Error(data.error || 'Preview failed');
                const absoluteUrl = data.audioUrl.startsWith('http') ? data.audioUrl : window.APP_BASE_URL + data.audioUrl;
                currentlyPlayingPreview = new Audio(absoluteUrl);
                currentlyPlayingPreview.play();
                currentlyPlayingPreview.onended = () => {
                    previewBtn.disabled = false;
                    previewBtn.innerHTML = '<i class="fas fa-volume-up"></i>';
                };
            }).catch(err => {
                showToast(`Preview failed: ${err.message}`, 'error');
                previewBtn.disabled = false;
                previewBtn.innerHTML = '<i class="fas fa-volume-up"></i>';
            });
        }
        
        const removeBtn = e.target.closest('.btn-remove-speaker');
        if (removeBtn) {
            removeBtn.closest('.voice-config-row').remove();
        }
    });

    generateAudioBtn.addEventListener('click', function() {
        this.disabled = true;
        this.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Generating...';
        
        try {
            const audioScript = getScriptFromSSML();
            if (audioScript.length === 0) throw new Error("Script is empty.");
    
            const voiceRows = document.querySelectorAll('#voice-config-container .voice-config-row');
            const voiceMap = {};
            let isCustomJob = useCustomEngineSwitch.checked; 
    
            voiceRows.forEach(row => {
                const speakerName = row.querySelector('input[type="text"]').value.trim().toUpperCase();
                const selectedVoiceId = row.querySelector('.voice-select-dropdown').value;
                const voice = availableVoices.find(v => v.id === selectedVoiceId);
                
                if (!voice || !selectedVoiceId) {
                    throw new Error(`Voice for ${speakerName} is not selected.`);
                }
                
                if (isCustomJob) {
                    voiceMap[speakerName] = voice;
                } else {
                    const voiceData = { 
                        id: voice.id, 
                        provider: voice.provider, 
                        pitch: row.querySelector('.expressiveness-slider').value,
                        lang: languageSelect.value
                    };
                    if (voice.id.includes('Chirp')) {
                        voiceData.model = 'chirp';
                    }
                    voiceMap[speakerName] = voiceData;
                }
            });
    
            const endpoint = isCustomJob ? 'api/custom-voice-service.php' : 'api/generate-audio.php';
            const payload = {
                projectId: projectId,
                script: audioScript,
                voiceMap: voiceMap
            };
    
            if (!isCustomJob) {
                payload.action = 'generate_audio';
            }
    
            fetchAndParseJson(`${window.APP_BASE_URL}${endpoint}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            })
            .then(data => {
                if (!data.success) throw new Error(data.error || 'Audio generation failed.');
                
                const audioResultsList = document.querySelector('.audio-results-list');
                audioResultsList.innerHTML = '';
                const newItem = document.createElement('div');
                newItem.className = 'audio-result-item';
                const absoluteUrl = data.audioUrl.startsWith('http') ? data.audioUrl : window.APP_BASE_URL + data.audioUrl;
                newItem.innerHTML = `<span>${data.fileName}</span><div class="icons"><audio controls src="${absoluteUrl}" class="me-2"></audio><a href="${absoluteUrl}" download="${data.fileName}" class="btn btn-sm btn-outline-secondary" title="Download"><i class="fas fa-download"></i></a></div>`;
                audioResultsList.append(newItem);
                showToast('Audio generated successfully!', 'success');
                updateLivePreviewAudio(data.audioUrl);
            })
            .catch(error => showToast(`Generation Error: ${error.message}`, 'error'))
            .finally(() => {
                this.disabled = false;
                this.innerHTML = 'Generate Audio';
            });
    
        } catch (error) {
            showToast(`Error: ${error.message}`, 'error');
            this.disabled = false;
            this.innerHTML = 'Generate Audio';
        }
    });
	
    document.getElementById('learnMoreLink').addEventListener('click', function(e) {
        e.preventDefault();
        const audioSrc = '<?php echo $base_url; ?>audio_files/learn_more_aximate_studio.mp3';
        
        if (explainerAudio && !explainerAudio.paused) {
            explainerAudio.pause();
            explainerAudio.currentTime = 0;
            showToast('Explainer audio stopped.', 'info');
        } else {
            if (!explainerAudio || explainerAudio.src !== audioSrc) {
                explainerAudio = new Audio(audioSrc);
            }
            showToast('Playing explainer audio...', 'info');
            explainerAudio.play().catch(err => {
                console.error("Audio playback failed:", err);
                showToast('Could not play audio file.', 'error');
            });
        }
    });

    // ========================================================================
    // --- 5. SCRIPT GENERATOR MODAL LOGIC (RESTORED & SYNTAX VERIFIED) ---
    // ========================================================================

    const modal = document.getElementById('aiScriptGeneratorModal');
    if (modal) {
        let lastObjective = ''; 
        const objectiveSelect = document.getElementById('objectiveSelect');
        const primaryIntentInput = document.getElementById('primaryIntent');
        const contextArea = document.getElementById('contextArea');
        const generateBtn = document.getElementById('modalGenerateScriptBtn');
        const scriptForm = document.getElementById('script-generator-form');
        const previewDiv = document.getElementById('scriptPreviewDiv');
        const formFooter = document.getElementById('generate-footer-buttons');
        const previewFooter = document.getElementById('preview-footer-buttons');
        const rejectBtn = document.getElementById('rejectScriptBtn');
        const acceptBtn = document.getElementById('acceptScriptBtn');
        const modalBody = modal.querySelector('.modal-body');
        const toneSelect = document.getElementById('toneSelect');
        const backgroundDocUpload = document.getElementById('backgroundDocUpload');
        const docUploadStatus = document.getElementById('docUploadStatus');
        const modalLanguageSelect = document.getElementById('modalLanguageSelect');
        
        const placeholderMap = { 'custom': { intent: "e.g., Explain the importance of creative writing.", context: "Add key talking points, specific details, or a rough outline here..." }, 'product_explainer': { intent: "e.g., Convince a busy executive that our product 'Photon' saves them time.", context: "Product Name: Photon\nKey Features: AI-powered, 50% faster, secure.\nTarget Audience: Busy professionals who need to increase productivity." }, 'promo_cta': { intent: "e.g., Create excitement for a limited-time 25% discount on our annual plan.", context: "Offer: 25% off annual plan.\nDeadline: This Friday at midnight.\nCall to Action: Click the link below to claim your discount now." }, 'testimonial': { intent: "e.g., Create a believable testimonial from a happy customer.", context: "Customer Name: Jane Doe\nProduct Used: Photon\nPositive Outcomes: Loved the customer service, saved her 10 hours a week, onboarding was simple." }, 'lead_gen': { intent: "e.g., Encourage listeners to sign up for a free demo of our software.", context: "Offer: Free, no-obligation 30-minute demo.\nKey Benefit: See how Photon can triple your team's efficiency in one week.\nCall to Action: Visit our website to schedule your demo." }, 'lead_nurture': { intent: "e.g., Re-engage a lead who showed interest but didn't buy.", context: "Lead's Pain Point: Mentioned they struggle with project management.\nKey Info: Briefly share a success story from a similar company. Offer a helpful, no-strings-attached resource (like a free guide)." }, 'storytelling': { intent: "e.g., Tell a short, engaging story about overcoming a challenge.", context: "Main Character: A small business owner named Alex.\nChallenge: Struggling to manage inventory.\nResolution: Discovered a new method that changed everything." }, 'podcast_monologue': { intent: "e.g., Deliver an insightful monologue about the future of artificial intelligence.", context: "Main Topic: The future of AI.\nKey Points: 1) AI as a creative partner, 2) Ethical considerations, 3) A surprising prediction for the next 5 years." }, 'podcast_interview': { intent: "e.g., Create an interview script between a host and an expert guest.", context: "Host Name: Sarah\nGuest Name: Dr. Evans, an expert in marine biology.\nTopic: The discovery of a new deep-sea creature. Sarah should ask about the discovery and its implications." }, 'company_update': { intent: "e.g., Announce the successful launch of a new company initiative to all employees.", context: "Initiative: 'Project Greenlight'\nKey Success: Completed two weeks ahead of schedule.\nMessage: Thank the team for their hard work and mention the upcoming celebration." }, 'customer_reply': { intent: "e.g., Provide a helpful and empathetic response to a customer's support ticket.", context: "Customer's Issue: Was having trouble resetting their password.\nResolution: The issue is now fixed.\nTone: Reassuring and apologetic for the inconvenience. End on a friendly note." }, 'training_module': { intent: "e.g., Create a short training script for new employees on using the company's CRM.", context: "Topic: How to create a new client entry in the CRM.\nKey Steps: 1) Log in, 2) Click 'New Client', 3) Fill in required fields, 4) Click 'Save'.\nGoal: Make it simple, clear, and easy to follow." }, 'urgent_alert': { intent: "e.g., Broadcast an urgent notification about a temporary system outage.", context: "System: The main web server.\nIssue: Experiencing a temporary outage.\nETA for fix: Approximately 30 minutes.\nInstruction: Advise users not to log out and that work will be saved." }, 'friendly_reminder': { intent: "e.g., Send a friendly reminder about an upcoming appointment or deadline.", context: "Event: Upcoming dental appointment.\nDate & Time: Tomorrow at 2:00 PM.\nAction: Ask for a confirmation by replying to the message." } };
        
        function sanitizeStringForAPI(str) { 
            if (typeof str !== 'string') return str; 
            str = str.replace(/[\u2018\u2019]/g, "'").replace(/[\u201C\u201D]/g, '"').replace(/[\u2013\u2014]/g, '-').replace(/\u2026/g, '...'); 
            str = str.replace(/[^\x20-\x7E\r\n]/g, ''); 
            return str; 
        }

        function updatePlaceholders() { const selectedObjective = objectiveSelect.value; const placeholders = placeholderMap[selectedObjective] || placeholderMap['custom']; primaryIntentInput.placeholder = placeholders.intent; contextArea.placeholder = placeholders.context; }
        objectiveSelect.addEventListener('change', updatePlaceholders);
        if (backgroundDocUpload && docUploadStatus) { backgroundDocUpload.addEventListener('change', function() { docUploadStatus.textContent = this.files && this.files[0] ? this.files[0].name : ''; }); }
        function populateTones() { if (!toneSelect) return; const tones = ["Professional", "Conversational", "Enthusiastic", "Calm", "Humorous", "Authoritative", "Empathetic", "Inspirational", "Friendly", "Formal"]; toneSelect.innerHTML = ''; tones.forEach(tone => { const option = new Option(tone, tone.toLowerCase()); if (tone === "Friendly") option.selected = true; toneSelect.appendChild(option); }); }
        function showFormView() { modalBody.style.overflowY = 'auto'; scriptForm.style.display = 'block'; previewDiv.style.display = 'none'; formFooter.style.display = 'block'; previewFooter.style.display = 'none'; generateBtn.disabled = false; generateBtn.innerHTML = 'Generate'; }
        function showPreviewView(data) { window.lastGeneratedData = data; const scriptHtml = Array.isArray(data.script) ? data.script.map(line => `<div><strong>${line.speaker || 'Narrator'}:</strong> ${line.text}</div>`).join('') : ''; const imagePromptText = data.imagePrompt || ''; const finalHtml = `<h5 class="mb-3">Review Generated Script</h5><div class="d-flex flex-column gap-3" style="flex-grow: 1; min-height: 0;"><div class="border rounded-2 d-flex flex-column" style="background-color: #f8f9fa; min-height: 0; flex-shrink: 1; flex-basis: 60%;"><h6 class="fw-bold text-dark p-2 border-bottom mb-0" style="background-color: #f1f3f5; border-top-left-radius: 0.25rem; border-top-right-radius: 0.25rem;">Generated Script</h6><div class="p-2" style="overflow-y: auto; flex-grow: 1;">${scriptHtml || '<p class="text-muted m-0">No script generated.</p>'}</div></div><div class="border rounded-2 d-flex flex-column" style="background-color: #f8f9fa; min-height: 0; flex-shrink: 1; flex-basis: 40%;"><h6 class="fw-bold text-dark p-2 border-bottom mb-0" style="background-color: #f1f3f5; border-top-left-radius: 0.25rem; border-top-right-radius: 0.25rem;">Generated Image Prompt</h6><div class="p-2 small" style="overflow-y: auto; flex-grow: 1; white-space: pre-wrap;">${imagePromptText || '<p class="text-muted m-0">No prompt generated.</p>'}</div></div></div>`; previewDiv.innerHTML = finalHtml; modalBody.style.overflowY = 'hidden'; scriptForm.style.display = 'none'; previewDiv.style.display = 'flex'; formFooter.style.display = 'none'; previewFooter.style.display = 'block'; }
        function showLoadingView() { generateBtn.disabled = true; generateBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Generating...'; }
        
        function sendRequest(finalContext) {
            const currentObjective = document.getElementById('objectiveSelect').value;
            const cleanIntent = sanitizeStringForAPI(document.getElementById('primaryIntent').value);
            const cleanContext = sanitizeStringForAPI(finalContext);
            const newConversation = (lastObjective !== '' && lastObjective !== currentObjective);
            const formData = {
                objective: currentObjective,
                primaryIntent: cleanIntent,
                context: cleanContext,
                creativity: document.getElementById('creativitySelect').value,
                tone: document.getElementById('toneSelect').value,
                time: document.getElementById('timeSelect').value,
                language: modalLanguageSelect.value,
                speakers: document.getElementById('speakerModeSelect').value,
                vocalStyle: document.getElementById('vocalStyleSelect').value,
                projectId: projectId,
                start_new_conversation: newConversation
            };
            lastObjective = currentObjective;

            fetchAndParseJson(window.APP_BASE_URL + 'api/generate-script.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            })
            .then(data => {
                if (data && data.error) throw new Error(data.error);
                if (data && Array.isArray(data.script)) {
                    showPreviewView(data);
                } else {
                    throw new Error('Server response was invalid or missing data.');
                }
            })
            .catch(error => {
                console.error("Script Generation Failed:", error);
                showFormView();
                showToast(`Script Generation Failed: ${error.message}`, 'error');
            });
        }

        generateBtn.addEventListener('click', function() { showLoadingView(); const baseContext = contextArea.value; const file = backgroundDocUpload.files[0]; if (file) { const reader = new FileReader(); reader.onload = function(e) { const fileContent = e.target.result; const combinedContext = `${baseContext}\n\n--- Document Content ---\n${fileContent}`; sendRequest(combinedContext); }; reader.onerror = function() { showToast('Error reading file.', 'error'); showFormView(); }; reader.readAsText(file); } else { sendRequest(baseContext); } });
        acceptBtn.addEventListener('click', function() { if (window.lastGeneratedData && Array.isArray(window.lastGeneratedData.script)) { document.dispatchEvent(new CustomEvent('script-generated', { detail: { structuredScript: window.lastGeneratedData.script } })); bootstrap.Modal.getInstance(modal)?.hide(); } });
        rejectBtn.addEventListener('click', showFormView);
        modal.addEventListener('hidden.bs.modal', showFormView);
        
        modal.addEventListener('shown.bs.modal', function () {
            lastObjective = document.getElementById('objectiveSelect').value;
        });

        populateTones();
        updatePlaceholders();
        showFormView();
    }

    // ========================================================================
    // --- 6. AUTOSAVE LOGIC ---
    // ========================================================================

    const storageKey = `autosave_script_${projectId}`;
    let autosaveTimer = null;
    function saveScriptDraft() { const content = scriptArea.innerHTML; if (content && content.trim() !== '') { localStorage.setItem(storageKey, content); } else { localStorage.removeItem(storageKey); } }
    scriptArea.addEventListener('input', () => { clearTimeout(autosaveTimer); autosaveTimer = setTimeout(saveScriptDraft, 3000); });
    function checkForSavedDraft() { const savedDraft = localStorage.getItem(storageKey); if (savedDraft && savedDraft.trim() !== '') { const modalHTML = `<div class="modal fade" id="restoreDraftModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">Unsaved Script Found</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><p>It looks like you have an unsaved script from your last session. Would you like to restore it?</p></div><div class="modal-footer"><button type="button" class="btn btn-secondary" id="discardDraftBtn">Discard</button><button type="button" class="btn btn-primary" id="restoreDraftBtn">Restore</button></div></div></div></div>`; document.body.insertAdjacentHTML('beforeend', modalHTML); const restoreModalEl = document.getElementById('restoreDraftModal'); const restoreModal = new bootstrap.Modal(restoreModalEl); document.getElementById('restoreDraftBtn').addEventListener('click', () => { scriptArea.innerHTML = savedDraft; updateSSMLFromVisual(); localStorage.removeItem(storageKey); restoreModal.hide(); showToast('Script restored!', 'success'); }); document.getElementById('discardDraftBtn').addEventListener('click', () => { localStorage.removeItem(storageKey); restoreModal.hide(); showToast('Draft discarded.', 'info'); }); restoreModalEl.addEventListener('hidden.bs.modal', () => restoreModalEl.remove()); restoreModal.show(); } }
    checkForSavedDraft();

    // ========================================================================
    // --- 7. GENERAL UI & AUTOSAVE ---
    // ========================================================================
    
    document.querySelectorAll('.autosave-field').forEach(field => { field.addEventListener('change', function() { var formData = new FormData(); formData.append('action', 'update_project_field'); formData.append('project_id', projectId); formData.append('field_name', this.dataset.dbField); formData.append('field_value', this.type === 'checkbox' ? (this.checked ? 1 : 0) : this.value); fetch(window.APP_BASE_URL + 'api/update-project.php', { method: 'POST', body: formData }).then(response => response.json()).then(result => { if (!result.success) { throw new Error(result.error || 'Unknown error'); } }).catch(error => showToast(`Error saving ${this.dataset.dbField}: ${error.message}`, 'error')); }); });

    // ========================================================================
    // --- 8. CANVAS & IMAGE HANDLING LOGIC ---
    // ========================================================================
    
    function fabricColorToHex(color) { if (!color) return '#000000'; if (color.toHex) { return '#' + color.toHex(); } if (String(color).startsWith('rgb')) { const rgb = color.match(/\d+/g).map(Number); return '#' + ((1 << 24) + (rgb[0] << 16) + (rgb[1] << 8) + rgb[2]).toString(16).slice(1).toUpperCase(); } return color; }
    var testCanvas = null; var testEditorHistory = null; 
    function initializeTestEditor() { 
        try { 
            var canvasElement = document.getElementById('aximate-canvas'); 
            if (!canvasElement) { console.error("Canvas element not found!"); return; } 
            var canvasContainer = canvasElement.parentElement; 
            var containerWidth = canvasContainer.clientWidth; 
            var canvasWidth = containerWidth - 2; 
            var canvasHeight = Math.min(canvasContainer.clientHeight - 40, 600); 
            canvasWidth = Math.max(canvasWidth, 600); 
            canvasHeight = Math.max(canvasHeight, 400); 
            canvasElement.width = canvasWidth; 
            canvasElement.height = canvasHeight; 
            canvasElement.style.width = canvasWidth + 'px'; 
            canvasElement.style.height = canvasHeight + 'px'; 
            testCanvas = new fabric.Canvas('aximate-canvas', { width: canvasWidth, height: canvasHeight, backgroundColor: 'white', selection: true, preserveObjectStacking: true }); 
            testEditorHistory = { states: [], index: -1, locked: false, save: function() { if (this.locked) return; try { if (this.index < this.states.length - 1) { this.states.splice(this.index + 1); } this.states.push(testCanvas.toJSON()); this.index++; this.updateButtons(); } catch (e) { console.error("Test History save failed:", e); } }, undo: function() { if (this.index <= 0) return; this.locked = true; this.index--; var self = this; testCanvas.loadFromJSON(this.states[this.index], function() { testCanvas.renderAll(); self.locked = false; self.updateButtons(); updateTestPlaceholder(); updateTestControlsForSelection(null); }); }, redo: function() { if (this.index >= this.states.length - 1) return; this.locked = true; this.index++; var self = this; testCanvas.loadFromJSON(this.states[this.index], function() { testCanvas.renderAll(); self.locked = false; self.updateButtons(); updateTestPlaceholder(); updateTestControlsForSelection(null); }); }, updateButtons: function() { var undoBtn = document.getElementById('testUndoBtn'); var redoBtn = document.getElementById('testRedoBtn'); if (undoBtn) undoBtn.disabled = this.index <= 0; if (redoBtn) redoBtn.disabled = this.index >= this.states.length - 1; } }; 
            setupTestCanvasEvents(); 
            setupTestButtonEvents(); 
            setupTestStyleControls(); 
            setupTestTransformControls(); 
            setupTestKeyboardShortcuts(); 
            updateTestPlaceholder(); 
            updateTestControlsForSelection(null); 
            testEditorHistory.save(); 
			window.axiMateTestEditor = { canvas: function() { return testCanvas; }, createShape: createTestShape, addText: addTestText, history: function() { return testEditorHistory; }, resizeCanvas: resizeTestCanvas, updatePlaceholder: updateTestPlaceholder, saveState: function() { testEditorHistory.save(); } };        } catch (error) { console.error("Test Editor initialization failed:", error); } 
    } 
    function resizeTestCanvas() { try { var canvasContainer = document.getElementById('aximate-canvas').parentElement; var maxWidth = Math.min(canvasContainer.clientWidth - 40, 800); var maxHeight = Math.min(canvasContainer.clientHeight - 40, 600); var newWidth = Math.max(maxWidth, 600); var newHeight = Math.max(maxHeight, 400); testCanvas.setWidth(newWidth); testCanvas.setHeight(newHeight); testCanvas.renderAll(); } catch (error) { console.error("Test Canvas resize failed:", error); } } 
    function updateTestPlaceholder() { var placeholder = document.getElementById('test-placeholder'); if (placeholder) { var hasObjects = testCanvas.getObjects().length > 0 || testCanvas.backgroundImage; placeholder.style.display = hasObjects ? 'none' : 'block'; } } 
    function getCurrentTestStyle() { return { fill: document.getElementById('testTransparentFill').checked ? 'transparent' : document.getElementById('testFillColor').value, stroke: document.getElementById('testStrokeColor').value, strokeWidth: parseInt(document.getElementById('testStrokeWidth').value) || 2, fontFamily: document.getElementById('testFontFamily').value, fontSize: parseInt(document.getElementById('testFontSize').value) || 40 }; } 
    function createTestShape(type) { try { var style = getCurrentTestStyle(); var centerX = testCanvas.width / 2; var centerY = testCanvas.height / 2; var shape = null; highlightTestShapeButton(type, true); switch(type) { case 'rectangle': shape = new fabric.Rect({ width: 150, height: 100, fill: style.fill, stroke: style.stroke, strokeWidth: style.strokeWidth, left: centerX, top: centerY, originX: 'center', originY: 'center' }); break; case 'circle': shape = new fabric.Circle({ radius: 60, fill: style.fill, stroke: style.stroke, strokeWidth: style.strokeWidth, left: centerX, top: centerY, originX: 'center', originY: 'center' }); break; case 'star': var points = []; var outerRadius = 50; var innerRadius = 25; var spikes = 5; for (var i = 0; i < spikes * 2; i++) { var radius = i % 2 === 0 ? outerRadius : innerRadius; var angle = (i * Math.PI) / spikes - Math.PI / 2; points.push({ x: Math.cos(angle) * radius, y: Math.sin(angle) * radius }); } shape = new fabric.Polygon(points, { fill: style.fill, stroke: style.stroke, strokeWidth: style.strokeWidth, left: centerX, top: centerY, originX: 'center', originY: 'center' }); break; case 'triangle': shape = new fabric.Triangle({ width: 100, height: 100, fill: style.fill, stroke: style.stroke, strokeWidth: style.strokeWidth, left: centerX, top: centerY, originX: 'center', originY: 'center' }); break; case 'right-triangle': var rightTrianglePoints = [{ x: -60, y: -60 }, { x: -60, y: 60 }, { x: 60, y: 60 }]; shape = new fabric.Polygon(rightTrianglePoints, { fill: style.fill, stroke: style.stroke, strokeWidth: style.strokeWidth, left: centerX, top: centerY, originX: 'center', originY: 'center' }); break; case 'hexagon': var hexPoints = []; for (var i = 0; i < 6; i++) { var angle = (i * Math.PI) / 3; hexPoints.push({ x: Math.cos(angle) * 50, y: Math.sin(angle) * 50 }); } shape = new fabric.Polygon(hexPoints, { fill: style.fill, stroke: style.stroke, strokeWidth: style.strokeWidth, left: centerX, top: centerY, originX: 'center', originY: 'center' }); break; case 'heart': shape = new fabric.Path('M12,21.35l-1.45-1.32C5.4,15.36,2,12.28,2,8.5 C2,5.42,4.42,3,7.5,3c1.74,0,3.41,0.81,4.5,2.09C13.09,3.81,14.76,3,16.5,3 C19.58,3,22,5.42,22,8.5c0,3.78-3.4,6.86-8.55,11.54L12,21.35z', { fill: style.fill, stroke: style.stroke, strokeWidth: style.strokeWidth, left: centerX, top: centerY, originX: 'center', originY: 'center', scaleX: 2, scaleY: 2 }); break; case 'arrow-right': var arrowLine = new fabric.Line([-60, 0, 40, 0], { stroke: style.stroke, strokeWidth: style.strokeWidth }); var arrowHead = new fabric.Triangle({ width: 25, height: 25, fill: style.stroke, left: 40, top: 0, angle: 90, originX: 'center', originY: 'center' }); shape = new fabric.Group([arrowLine, arrowHead], { left: centerX, top: centerY, originX: 'center', originY: 'center' }); break; case 'arrow-left': var arrowLine = new fabric.Line([-40, 0, 60, 0], { stroke: style.stroke, strokeWidth: style.strokeWidth }); var arrowHead = new fabric.Triangle({ width: 25, height: 25, fill: style.stroke, left: -40, top: 0, angle: -90, originX: 'center', originY: 'center' }); shape = new fabric.Group([arrowLine, arrowHead], { left: centerX, top: centerY, originX: 'center', originY: 'center' }); break; case 'solid-line': shape = new fabric.Line([-75, 0, 75, 0], { stroke: style.stroke, strokeWidth: style.strokeWidth, left: centerX, top: centerY, originX: 'center', originY: 'center' }); break; case 'dotted-line': shape = new fabric.Line([-75, 0, 75, 0], { stroke: style.stroke, strokeWidth: style.strokeWidth, strokeDashArray: [5, 5], left: centerX, top: centerY, originX: 'center', originY: 'center' }); break; case 'dashed-line': shape = new fabric.Line([-75, 0, 75, 0], { stroke: style.stroke, strokeWidth: style.strokeWidth, strokeDashArray: [10, 5], left: centerX, top: centerY, originX: 'center', originY: 'center' }); break; case 'double-line': var line1 = new fabric.Line([-75, -5, 75, -5], { stroke: style.stroke, strokeWidth: style.strokeWidth }); var line2 = new fabric.Line([-75, 5, 75, 5], { stroke: style.stroke, strokeWidth: style.strokeWidth }); shape = new fabric.Group([line1, line2], { left: centerX, top: centerY, originX: 'center', originY: 'center' }); break; case 'bracket-left': shape = new fabric.Path('M 30 10 L 10 30 L 30 50', { fill: '', stroke: style.stroke, strokeWidth: style.strokeWidth + 2, left: centerX, top: centerY, originX: 'center', originY: 'center' }); break; case 'bracket-right': shape = new fabric.Path('M 10 10 L 30 30 L 10 50', { fill: '', stroke: style.stroke, strokeWidth: style.strokeWidth + 2, left: centerX, top: centerY, originX: 'center', originY: 'center' }); break; default: highlightTestShapeButton(type, false); return false; } if (shape) { testCanvas.add(shape); testCanvas.setActiveObject(shape); testCanvas.renderAll(); updateTestPlaceholder(); testEditorHistory.save(); setTimeout(function() { highlightTestShapeButton(type, false); }, 500); return true; } highlightTestShapeButton(type, false); return false; } catch (error) { console.error("Test Shape creation failed:", error); highlightTestShapeButton(type, false); return false; } } 
        function highlightTestShapeButton(type, highlight) { var btn = document.querySelector('[data-shape="' + type + '"]'); if (btn) { if (highlight) { btn.classList.add('creating'); } else { btn.classList.remove('creating'); } } } 
        function addTestText() { try { var style = getCurrentTestStyle(); var text = new fabric.IText('Double-click to edit', { left: testCanvas.width / 2, top: testCanvas.height / 2, originX: 'center', originY: 'center', fontFamily: style.fontFamily, fontSize: style.fontSize, fill: style.fill === 'transparent' ? '#000000' : style.fill, editable: true, selectByWord: true, splitByGrapheme: false }); testCanvas.add(text); testCanvas.setActiveObject(text); testCanvas.renderAll(); updateTestPlaceholder(); testEditorHistory.save(); return true; } catch (error) { console.error("Test Text creation failed:", error); return false; } } 

        function setAndResizeCanvasBackground(imageUrl) {
            fabric.Image.fromURL(imageUrl, function(img) {
                const canvasContainer = testCanvas.getElement().parentElement;
                const containerWidth = canvasContainer.clientWidth;

                const imgAspectRatio = img.height / img.width;
                const newCanvasWidth = containerWidth - 2; 
                const newCanvasHeight = newCanvasWidth * imgAspectRatio;

                testCanvas.setWidth(newCanvasWidth);
                testCanvas.setHeight(newCanvasHeight);

                testCanvas.setBackgroundImage(img, testCanvas.renderAll.bind(testCanvas), {
                    scaleX: newCanvasWidth / img.width,
                    scaleY: newCanvasHeight / img.height
                });

                updateTestPlaceholder();
                testEditorHistory.save();

            }, { crossOrigin: 'anonymous' });
        }

        function addDraggableImageLayer(file) {
            if (!file) return;
            try {
                const reader = new FileReader();
                reader.onload = function(e) {
                    fabric.Image.fromURL(e.target.result, function(img) {
                        img.scaleToWidth(200);
                        img.set({
                            left: (testCanvas.width - img.getScaledWidth()) / 2,
                            top: (testCanvas.height - img.getScaledHeight()) / 2,
                            crossOrigin: 'anonymous'
                        });
                        testCanvas.add(img);
                        testCanvas.setActiveObject(img);
                        testCanvas.renderAll();
                        updateTestPlaceholder();
                        testEditorHistory.save();
                    });
                };
                reader.readAsDataURL(file);
                return true;
            } catch (error) {
                console.error("Failed to add image layer:", error);
                showToast('Failed to add image.', 'error');
                return false;
            }
        }
        
        function updateTestControlsForSelection(obj) { var textControls = ['testBoldBtn', 'testItalicBtn', 'testUnderlineBtn', 'testFontFamily', 'testFontSize', 'testAlignLeftBtn', 'testAlignCenterBtn', 'testAlignRightBtn']; var transformControls = ['testRotateLeftBtn', 'testRotateRightBtn', 'testFlipHBtn', 'testFlipVBtn', 'testRotationInput']; var layerControls = ['testBringToFrontBtn', 'testBringForwardBtn', 'testSendBackwardBtn', 'testSendToBackBtn']; var buttons = document.querySelectorAll('.test-toolbar button'); for (var i = 0; i < buttons.length; i++) { buttons[i].classList.remove('active'); } if (!obj) { var allControls = textControls.concat(transformControls).concat(layerControls); for (var i = 0; i < allControls.length; i++) { var element = document.getElementById(allControls[i]); if (element) element.disabled = true; } return; } for (var i = 0; i < transformControls.length; i++) { var element = document.getElementById(transformControls[i]); if (element) element.disabled = false; } for (var i = 0; i < layerControls.length; i++) { var element = document.getElementById(layerControls[i]); if (element) element.disabled = false; } var isText = obj.type === 'i-text' || obj.type === 'text'; for (var i = 0; i < textControls.length; i++) { var element = document.getElementById(textControls[i]); if (element) element.disabled = !isText; } if (isText) { var boldBtn = document.getElementById('testBoldBtn'); var italicBtn = document.getElementById('testItalicBtn'); var underlineBtn = document.getElementById('testUnderlineBtn'); if (boldBtn) boldBtn.classList.toggle('active', obj.fontWeight === 'bold'); if (italicBtn) italicBtn.classList.toggle('active', obj.fontStyle === 'italic'); if (underlineBtn) underlineBtn.classList.toggle('active', obj.underline === true); var fontFamily = document.getElementById('testFontFamily'); var fontSize = document.getElementById('testFontSize'); if (fontFamily) fontFamily.value = obj.fontFamily || 'Arial'; if (fontSize) fontSize.value = obj.fontSize || 40; var textAlign = obj.textAlign || 'left'; var alignments = ['Left', 'Center', 'Right']; for (var i = 0; i < alignments.length; i++) { var btn = document.getElementById('testAlign' + alignments[i] + 'Btn'); if (btn) btn.classList.toggle('active', textAlign === alignments[i].toLowerCase()); } } else { if (obj.fill && obj.fill !== 'transparent') { document.getElementById('testFillColor').value = fabricColorToHex(obj.fill); document.getElementById('testTransparentFill').checked = false; } else { document.getElementById('testTransparentFill').checked = true; } if (obj.stroke) { document.getElementById('testStrokeColor').value = fabricColorToHex(obj.stroke); } if (obj.strokeWidth !== undefined) { document.getElementById('testStrokeWidth').value = obj.strokeWidth; } } var rotationInput = document.getElementById('testRotationInput'); if (rotationInput) { rotationInput.value = Math.round(obj.angle || 0); } } 
        function applyTestStyle(property, value) {
            var obj = testCanvas.getActiveObject();
            if (!obj) return false;
            try {
                if (obj.type === 'group' && (property === 'fill' || property === 'stroke')) {
                    obj.forEachObject(function(subObj) {
                        if (property !== 'fill' || subObj.fill !== '') {
                             subObj.set(property, value);
                        }
                    });
                } else {
                    obj.set(property, value);
                }
                if (property === 'fontFamily' || property === 'fontSize') { obj.setCoords(); }
                testCanvas.renderAll();
                testEditorHistory.save();
                return true;
            } catch (error) {
                console.error("Test Style application failed:", error);
                return false;
            }
        }
        function setupTestCanvasEvents() { testCanvas.on('selection:created', function(e) { if (e.selected && e.selected.length > 0) { updateTestControlsForSelection(e.selected[0]); } }); testCanvas.on('selection:updated', function(e) { if (e.selected && e.selected.length > 0) { updateTestControlsForSelection(e.selected[0]); } }); testCanvas.on('selection:cleared', function() { updateTestControlsForSelection(null); }); testCanvas.on('object:modified', function(e) { testEditorHistory.save(); if (e.target) { var rotationInput = document.getElementById('testRotationInput'); if (rotationInput) { rotationInput.value = Math.round(e.target.angle || 0); } } }); } 
        function setupTestButtonEvents() { 
            document.querySelectorAll('.test-shape-btn').forEach(btn => btn.addEventListener('click', function() { createTestShape(this.dataset.shape); })); 
            document.getElementById('addTestTextBtn').addEventListener('click', addTestText); 
            document.getElementById('addTestImageBtn').addEventListener('click', () => document.getElementById('testImageUpload').click()); 
            document.getElementById('testImageUpload').addEventListener('change', function(e) { if (e.target.files.length > 0) addDraggableImageLayer(e.target.files[0]); this.value = ''; }); 
            document.getElementById('testUndoBtn').addEventListener('click', () => testEditorHistory.undo()); 
            document.getElementById('testRedoBtn').addEventListener('click', () => testEditorHistory.redo()); 
            document.getElementById('testDeleteBtn').addEventListener('click', function() {
                const activeObject = testCanvas.getActiveObject();
                if (activeObject) {
                    if (activeObject.type === 'activeSelection') {
                        activeObject.forEachObject(function(obj) {
                            testCanvas.remove(obj);
                        });
                    } else {
                        testCanvas.remove(activeObject);
                    }
                    testCanvas.discardActiveObject();
                    testCanvas.renderAll();
                    testEditorHistory.save();
                } else {
                    showToast('No object selected to delete.', 'info');
                }
            });
            document.getElementById('testClearBtn').addEventListener('click', function() {
                if (confirm('Are you sure you want to clear all objects from the canvas? This action cannot be undone.')) {
                    testCanvas.remove(...testCanvas.getObjects());
                    testCanvas.discardActiveObject().renderAll();
                    updateTestPlaceholder();
                    testEditorHistory.save();
                }
            });
        } 
        function setupTestStyleControls() { 
            document.getElementById('testFillColor').addEventListener('input', function() { document.getElementById('testTransparentFill').checked = false; applyTestStyle('fill', this.value); }); 
            document.getElementById('testTransparentFill').addEventListener('change', function() { var fillColor = document.getElementById('testFillColor'); applyTestStyle('fill', this.checked ? 'transparent' : fillColor.value); }); 
            document.getElementById('testStrokeColor').addEventListener('input', function() { applyTestStyle('stroke', this.value); }); 
            document.getElementById('testStrokeWidth').addEventListener('change', function() { applyTestStyle('strokeWidth', parseInt(this.value)); }); document.getElementById('testFontFamily').addEventListener('change', function() { applyTestStyle('fontFamily', this.value); }); document.getElementById('testFontSize').addEventListener('change', function() { applyTestStyle('fontSize', parseInt(this.value)); }); document.getElementById('testBoldBtn').addEventListener('click', function() { var obj = testCanvas.getActiveObject(); if (obj?.type.includes('text')) { var isBold = obj.fontWeight === 'bold'; applyTestStyle('fontWeight', isBold ? 'normal' : 'bold'); this.classList.toggle('active', !isBold); } }); document.getElementById('testItalicBtn').addEventListener('click', function() { var obj = testCanvas.getActiveObject(); if (obj?.type.includes('text')) { var isItalic = obj.fontStyle === 'italic'; applyTestStyle('fontStyle', isItalic ? 'normal' : 'italic'); this.classList.toggle('active', !isItalic); } }); document.getElementById('testUnderlineBtn').addEventListener('click', function() { var obj = testCanvas.getActiveObject(); if (obj?.type.includes('text')) { var isUnderlined = obj.underline; applyTestStyle('underline', !isUnderlined); this.classList.toggle('active', !isUnderlined); } }); ['Left', 'Center', 'Right'].forEach(align => { document.getElementById('testAlign' + align + 'Btn').addEventListener('click', function() { applyTestStyle('textAlign', align.toLowerCase()); document.querySelectorAll('[id^="testAlign"]').forEach(b => b.classList.remove('active')); this.classList.add('active'); }); }); 
        } 
        function setupTestTransformControls() { document.getElementById('testRotateLeftBtn').addEventListener('click', function() { var obj = testCanvas.getActiveObject(); if (obj) { var newAngle = (obj.angle || 0) - 15; applyTestStyle('angle', newAngle); document.getElementById('testRotationInput').value = Math.round(newAngle); } }); document.getElementById('testRotateRightBtn').addEventListener('click', function() { var obj = testCanvas.getActiveObject(); if (obj) { var newAngle = (obj.angle || 0) + 15; applyTestStyle('angle', newAngle); document.getElementById('testRotationInput').value = Math.round(newAngle); } }); document.getElementById('testRotationInput').addEventListener('change', function() { var obj = testCanvas.getActiveObject(); if (obj) applyTestStyle('angle', parseInt(this.value) || 0); }); document.getElementById('testFlipHBtn').addEventListener('click', function() { var obj = testCanvas.getActiveObject(); if (obj) applyTestStyle('flipX', !obj.flipX); }); document.getElementById('testFlipVBtn').addEventListener('click', function() { var obj = testCanvas.getActiveObject(); if (obj) applyTestStyle('flipY', !obj.flipY); }); document.getElementById('testBringToFrontBtn').addEventListener('click', () => { var obj = testCanvas.getActiveObject(); if (obj) { obj.bringToFront(); testCanvas.renderAll(); testEditorHistory.save(); } }); document.getElementById('testBringForwardBtn').addEventListener('click', () => { var obj = testCanvas.getActiveObject(); if (obj) { obj.bringForward(); testCanvas.renderAll(); testEditorHistory.save(); } }); document.getElementById('testSendBackwardBtn').addEventListener('click', () => { var obj = testCanvas.getActiveObject(); if (obj) { obj.sendBackwards(); testCanvas.renderAll(); testEditorHistory.save(); } }); document.getElementById('testSendToBackBtn').addEventListener('click', () => { var obj = testCanvas.getActiveObject(); if (obj) { obj.sendToBack(); testCanvas.renderAll(); testEditorHistory.save(); } }); } 
        function setupTestKeyboardShortcuts() { document.addEventListener('keydown', function(e) { if (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA' || document.activeElement.isContentEditable) return; if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); document.getElementById('deleteImageBtn').click(); } if (e.ctrlKey || e.metaKey) { switch (e.key.toLowerCase()) { case 'z': e.preventDefault(); e.shiftKey ? testEditorHistory.redo() : testEditorHistory.undo(); break; case 'y': e.preventDefault(); testEditorHistory.redo(); break; case 'b': e.preventDefault(); document.getElementById('testBoldBtn').click(); break; case 'i': e.preventDefault(); document.getElementById('testItalicBtn').click(); break; case 'u': e.preventDefault(); document.getElementById('testUnderlineBtn').click(); break; } } }); }
        initializeTestEditor();
        window.addEventListener('resize', () => testCanvas && setTimeout(resizeTestCanvas, 100));

        // ========================================================================
        // --- 9. FINAL OUTPUTS & LIVE PREVIEW LOGIC ---
        // ========================================================================
        
        const imageSource = document.getElementById('imageSource');
        const uploadImageOptions = document.getElementById('uploadImageOptions');
        const imageUploadInput = document.getElementById('imageUpload');
        const generateAiImageContainer = document.getElementById('generateAiImageContainer');
        const generateAiImage = document.getElementById('generateAiImage');
        const aiDescriptionOptions = document.getElementById('aiDescriptionOptions');
        const iframe = document.getElementById('layoutPreviewFrame');

        imageSource.addEventListener('change', function() {
            if (this.value === 'upload') {
                uploadImageOptions.style.display = 'block';
                generateAiImageContainer.style.display = 'none';
                aiDescriptionOptions.style.display = 'none';
            } else {
                uploadImageOptions.style.display = 'none';
                generateAiImageContainer.style.display = 'block';
                if (generateAiImage.value === 'custom_image') {
                    aiDescriptionOptions.style.display = 'block';
                }
            }
        });

        generateAiImage.addEventListener('change', function() {
            aiDescriptionOptions.style.display = (this.value === 'custom_image') ? 'block' : 'none';
        });

        imageUploadInput.addEventListener('change', function(e) {
            if (e.target.files && e.target.files[0]) {
                const reader = new FileReader();
                reader.onload = function(event) {
                    setAndResizeCanvasBackground(event.target.result);
                };
                reader.readAsDataURL(e.target.files[0]);
            }
        });
        
        const backgroundFileStatus = document.getElementById('backgroundFileStatus');
        const imageLibraryModal = new bootstrap.Modal(document.getElementById('imageLibraryModal'));
        const imageLibraryBody = document.getElementById('imageLibraryBody');
        window.imageSelectionTarget = 'background';
        window.lastGeneratedAudioUrl = '';

        function updateCompanyLogo(url) {
            const logoPreview = document.getElementById('customerLogoPreview');
            const logoPathInput = document.getElementById('companyLogoPath');
            if (logoPreview) logoPreview.src = url;
            if (logoPathInput) { logoPathInput.value = url; logoPathInput.dispatchEvent(new Event('change', { bubbles: true })); }
            sendMessageToIframe({ type: 'updateElement', brandingKey: 'company-logo', value: url, attribute: 'src' });
            showToast('Company logo updated!', 'success');
        }

        function loadServerImages() {
            fetch(`${window.APP_BASE_URL}index.php?action=list_images&project_id=${projectId}&t=${new Date().getTime()}`)
            .then(r => r.json())
            .then(list => {
                imageLibraryBody.innerHTML = '';
                if (!Array.isArray(list) || list.length === 0) {
                    imageLibraryBody.innerHTML = '<div class="text-muted text-center p-3 w-100">No images found on server.</div>';
                    return;
                }
                list.forEach(imgUrl => {
                    const wrapper = document.createElement('div');
                    wrapper.className = 'position-relative';
                    const img = document.createElement('img');
                    img.src = `${imgUrl}?t=${new Date().getTime()}`; 
                    img.alt = 'Server image'; img.title = 'Click to select this image';
                    img.addEventListener('click', function() {
                        const urlWithCacheBuster = `${imgUrl}?t=${new Date().getTime()}`;
                        if (window.imageSelectionTarget === 'logo') { 
                            updateCompanyLogo(urlWithCacheBuster); 
                        } else { 
                            backgroundFileStatus.value = urlWithCacheBuster;
                            document.getElementById('generateWebpageBtn').click();
                        }
                        imageLibraryModal.hide();
                    });
                    const deleteBtn = document.createElement('button');
                    deleteBtn.className = 'btn btn-danger btn-sm position-absolute top-0 end-0 m-1 p-1 lh-1';
                    deleteBtn.innerHTML = '<i class="fas fa-trash-alt fa-xs"></i>';
                    deleteBtn.title = 'Delete this image permanently';
                    deleteBtn.addEventListener('click', function(e) {
                        e.stopPropagation(); 
                        if (confirm('Are you sure you want to permanently delete this image?')) {
                            const formData = new FormData();
                            formData.append('action', 'delete_image'); formData.append('project_id', projectId); formData.append('image_url', imgUrl);
                            fetch(window.APP_BASE_URL + 'index.php', { method: 'POST', body: formData })
                            .then(res => res.json())
                            .then(result => { if (result.success) { showToast('Image deleted!', 'success'); wrapper.remove(); } else { throw new Error(result.error || 'Failed to delete.'); } })
                            .catch(error => showToast('Delete Error: ' + error.message, 'error'));
                        }
                    });
                    wrapper.appendChild(img); wrapper.appendChild(deleteBtn); imageLibraryBody.appendChild(wrapper);
                });
            })
            .catch(err => { imageLibraryBody.innerHTML = '<div class="text-danger text-center p-3 w-100">Error loading images.</div>'; console.error("Image Load Error:", err); });
        }
                
        document.getElementById('browseServerBtn').addEventListener('click', function() { window.imageSelectionTarget = 'background'; loadServerImages(); imageLibraryModal.show(); });
        document.getElementById('browseComputerBtn').addEventListener('click', () => { document.getElementById('finalBackgroundUpload').click(); });
        
        document.getElementById('companyLogoUploadInput').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (!file) return;
            function performUpload(overwrite = false) {
                const formData = new FormData();
                formData.append('action', 'upload_logo');
                formData.append('project_id', projectId);
                formData.append('logoFile', file);
                if (overwrite) formData.append('overwrite', 'true');
                showToast('Uploading logo...', 'info');
                fetch(window.APP_BASE_URL + 'index.php', { method: 'POST', body: formData })
                    .then(res => res.json())
                    .then(result => {
                        if (result.success && result.url) {
                            updateCompanyLogo(result.url);
                        } else if (result.requires_confirmation) {
                            if (confirm('A file with this name already exists. Replace it?')) {
                                performUpload(true);
                            }
                        } else {
                            throw new Error(result.error || 'Upload failed.');
                        }
                    })
                    .catch(error => showToast('Upload Error: ' + error.message, 'error'));
            }
            performUpload(false);
            e.target.value = '';
        });

        document.getElementById('browseLogoServerBtn').addEventListener('click', function() { window.imageSelectionTarget = 'logo'; loadServerImages(); imageLibraryModal.show(); });
        
        document.getElementById('finalBackgroundUpload').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (!file) return;
            const formData = new FormData();
            formData.append('action', 'upload_background_image');
            formData.append('project_id', projectId);
            formData.append('backgroundImageFile', file);
            showToast('Uploading background...', 'info');
            fetch(window.APP_BASE_URL + 'index.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(result => {
                    if (result.success && result.url) {
                        backgroundFileStatus.value = result.url;
                        document.getElementById('generateWebpageBtn').click();
                    } else { throw new Error(result.error || 'Upload failed.'); }
                })
                .catch(error => showToast('Upload Error: ' + error.message, 'error'));
            e.target.value = '';
        });
    
    function resizeIframe() {
        setTimeout(() => {
            try {
                if (iframe && iframe.contentWindow && iframe.contentWindow.document.body) {
                    iframe.style.height = 'auto';
                    const newHeight = iframe.contentWindow.document.body.scrollHeight;
                    iframe.style.height = newHeight + 'px';
                }
            } catch (e) {
                console.error("Error resizing iframe:", e);
            }
        }, 250); 
    }

    if (iframe) {
        iframe.addEventListener('load', resizeIframe);
        window.addEventListener('resize', resizeIframe);
    }
    
    const generateImageBtn = document.getElementById('generateImageBtn');
    generateImageBtn.addEventListener('click', function() {
        const thisBtn = this;
        let prompt = '';
        const generateSource = document.getElementById('generateAiImage').value;
        const width = document.getElementById('outputWidth').value;
        const height = document.getElementById('outputHeight').value;

        if (generateSource === 'custom_image') {
            prompt = document.getElementById('aiDescriptionPrompt').value;
        } else {
            prompt = (window.lastGeneratedData && window.lastGeneratedData.imagePrompt) 
                         ? window.lastGeneratedData.imagePrompt 
                         : document.getElementById('heroTitleInput').value || "A professional and abstract background for a business presentation";
        }

        if (!prompt || prompt.trim() === '') {
            return showToast('Please generate a script or enter a custom description for the AI image.', 'error');
        }

        thisBtn.disabled = true;
        thisBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Generating...';

        fetch(window.APP_BASE_URL + 'api/generate-image.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prompt: prompt, projectId: projectId, width: width, height: height })
        })
        .then(res => res.json())
        .then(data => {
            if (!data.success || !data.imageUrl) {
                throw new Error(data.error || 'Failed to generate image.');
            }
            showToast('AI Image generated and applied to canvas!', 'success');
            setAndResizeCanvasBackground(data.imageUrl); // Automatically apply
        })
        .catch(error => {
            showToast(`Image Generation Error: ${error.message}`, 'error');
            console.error('Image Generation Error:', error);
        })
        .finally(() => {
            thisBtn.disabled = false;
            thisBtn.innerHTML = 'Generate Image';
        });
    });

    const generateWebpageBtn = document.getElementById('generateWebpageBtn');
    const layoutPreviewPlaceholder = document.getElementById('layoutPreviewPlaceholder');
    const viewFullSizeLink = document.getElementById('viewFullSizeLink');
    const layoutSelect = document.getElementById('layoutSelect');
    
    window.updateLivePreviewAudio = function(relativeAudioUrl) {
        window.lastGeneratedAudioUrl = relativeAudioUrl;
        if (iframe.style.display === 'block') {
            showToast('New audio detected. Regenerating webpage preview...', 'info');
            generateWebpageBtn.click();
        }
    };

    generateWebpageBtn.addEventListener('click', function() {
        if (!layoutSelect.value) {
            showToast('Please select a layout theme first.', 'error');
            return;
        }
        this.disabled = true;
        this.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Generating...';
        layoutPreviewPlaceholder.innerHTML = 'Generating preview...';
        layoutPreviewPlaceholder.style.display = 'flex';
        iframe.style.display = 'none';
        
        const backgroundImageUrl = document.getElementById('backgroundFileStatus').value;
        const audioUrl = window.lastGeneratedAudioUrl || '';
        fetch(window.APP_BASE_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify({ action: 'generate_webpage', projectId: projectId, audioUrl: audioUrl, backgroundImageUrl: backgroundImageUrl })
        })
        .then(res => res.json().then(data => ({ ok: res.ok, status: res.status, data })))
        .then(({ ok, status, data }) => {
            if (!ok || !data.success) { throw new Error(data.error || `Server error: ${status}`); }
            const finalUrl = `${window.APP_BASE_URL}${data.url}?t=${new Date().getTime()}`;
            iframe.src = finalUrl;
            viewFullSizeLink.href = finalUrl;
            layoutPreviewPlaceholder.style.display = 'none';
            iframe.style.display = 'block';
            showToast('Webpage preview generated!', 'success');
        })
        .catch(error => {
            layoutPreviewPlaceholder.innerHTML = 'Error generating preview. Please try again.';
            showToast(`Webpage Generation Error: ${error.message}`, 'error');
            console.error('Webpage Generation Error:', error);
        })
        .finally(() => {
            this.disabled = false;
            this.innerHTML = '<i class="fas fa-globe me-2"></i>Generate Webpage';
        });
    });

    layoutSelect.addEventListener('change', function() {
        if (this.value) {
           generateWebpageBtn.click();
        } else {
            layoutPreviewPlaceholder.innerHTML = 'Select a layout to see a live preview.';
            iframe.style.display = 'none';
            layoutPreviewPlaceholder.style.display = 'flex';
        }
    });
    
    if(layoutSelect.value) {
        generateWebpageBtn.click();
    }

    document.getElementById('downloadImageBtn').addEventListener('click', function() {
        const dataURL = testCanvas.toDataURL({ format: 'png', quality: 1 });
        const link = document.createElement('a');
        link.download = `aximate_canvas_${Date.now()}.png`;
        link.href = dataURL;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    });
    
    document.getElementById('saveImageBtn').addEventListener('click', function() {
        showToast('Saving image to server...', 'info');
        setTimeout(() => {
            const imageData = testCanvas.toDataURL({ format: 'png' });
            const formData = new FormData();
            formData.append('action', 'save_canvas');
            formData.append('project_id', projectId);
            formData.append('imageData', imageData);

            fetch(window.APP_BASE_URL + 'index.php', { method: 'POST', body: formData })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    showToast('Image saved successfully!', 'success');
                    if (document.getElementById('imageLibraryModal').classList.contains('show')) {
                        loadServerImages();
                    }
                } else {
                    throw new Error(result.error || 'Failed to save image.');
                }
            })
            .catch(error => {
                showToast('Error saving image: ' + error.message, 'error');
            });
        }, 200); 
    });
    
    document.getElementById('enlargeImageBtn').addEventListener('click', function() {
        const modal = new bootstrap.Modal(document.getElementById('enlargeImageModal'));
        const modalBody = document.querySelector('#enlargeImageModal .modal-body');
        const dataURL = testCanvas.toDataURL({ format: 'png', quality: 1 });
        modalBody.innerHTML = `<img src="${dataURL}" class="img-fluid" alt="Enlarged Canvas Preview">`;
        modal.show();
    });
    
    // --- START: REAL-TIME PREVIEW UPDATE LOGIC (postMessage) ---
    function sendMessageToIframe(message) {
        if (iframe && iframe.contentWindow) {
            iframe.contentWindow.postMessage(message, '*');
        }
    }

    function syncAllBrandingToPreview() {
        // Send all text/link updates
        const fieldsToUpdate = {
            'company-name': '#companyTitleInput', 'company-phone': '#companyPhoneInput',
            'company-email': '#companyEmailInput', 'company-address': '#companyAddressInput',
            'hero-message': '#heroTitleInput', 'audio-title': '#audioTitleInput',
            'primary-button-text': '#primaryBtnTitle', 'secondary-button-text': '#secondaryBtnTitle'
        };
        for (const [key, selector] of Object.entries(fieldsToUpdate)) {
            sendMessageToIframe({ type: 'updateElement', brandingKey: key, value: document.querySelector(selector).value });
        }
        
        sendMessageToIframe({ type: 'updateElement', brandingKey: 'company-website', value: document.getElementById('companyWebsiteInput').value.replace(/^https?:\/\//, '') });
        sendMessageToIframe({ type: 'updateElement', brandingKey: 'company-website', value: document.getElementById('companyWebsiteInput').value, attribute: 'href' });
        sendMessageToIframe({ type: 'updateElement', brandingKey: 'primary-button-link', value: document.getElementById('primaryBtnLink').value, attribute: 'href' });
        sendMessageToIframe({ type: 'updateElement', brandingKey: 'secondary-button-link', value: document.getElementById('secondaryBtnLink').value, attribute: 'href' });
        sendMessageToIframe({ type: 'updateElement', brandingKey: 'company-logo', value: document.getElementById('companyLogoPath').value, attribute: 'src' });
        
        // Send a single message with all style data
        const allStyles = {
            hero: {
                color: document.getElementById('heroFontColor').value,
                size: document.getElementById('heroFontSize').value,
                fontFamily: document.getElementById('heroFontFamily').value,
                isBold: document.getElementById('heroFontBold').checked,
                isItalic: document.getElementById('heroFontItalic').checked,
                isUnderline: document.getElementById('heroFontUnderline').checked,
                position: document.getElementById('heroPosition').value
            },
            audio: {
                color: document.getElementById('audioFontColor').value,
                size: document.getElementById('audioFontSize').value,
                fontFamily: document.getElementById('audioFontFamily').value,
                isBold: document.getElementById('audioFontBold').checked,
                isItalic: document.getElementById('audioFontItalic').checked,
                isUnderline: document.getElementById('audioFontUnderline').checked
            }
        };
        sendMessageToIframe({ type: 'updateStyles', styles: allStyles });
    }

    // --- Add all event listeners ---
    const allBrandingInputs = document.querySelectorAll('#websiteBrandingCard .autosave-field');
    allBrandingInputs.forEach(input => {
        const eventType = (input.type === 'select-one' || input.type === 'checkbox') ? 'change' : 'input';
        input.addEventListener(eventType, syncAllBrandingToPreview);
    });

    iframe.addEventListener('load', () => {
        resizeIframe();
        syncAllBrandingToPreview();
	});
	// --- END: REAL-TIME PREVIEW UPDATE LOGIC ---

	useCustomEngineSwitch.addEventListener('change', updateVoiceDropdowns);
});
</script>
</body>
</html>
