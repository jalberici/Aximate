<?php

// --- Configuration ---
// IMPORTANT: Replace 'hf_YOUR_HUGGINGFACE_TOKEN' with your actual Hugging Face API token
define('HUGGING_FACE_TOKEN', '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');

// IMPORTANT: Replace 'https://YOUR_UNIQUE_ENDPOINT_ID.us-east-1.aws.endpoints.huggingface.cloud/v1/chat/completions'
// with the exact URL of your deployed Hugging Face Inference Endpoint.
define('HUGGING_FACE_ENDPOINT', 'https://j0a39pq512ogr9jx.us-east-1.aws.endpoints.huggingface.cloud');

echo "Attempting to connect to Hugging Face Endpoint: " . HUGGING_FACE_ENDPOINT . "\n";

// --- Request Data (JSON) ---
$data = [
    'messages' => [
        ['role' => 'system', 'content' => 'You are a helpful AI assistant.'],
        ['role' => 'user', 'content' => 'What is the capital of France?']
    ],
    'max_tokens' => 50,
    'temperature' => 0.7,
];

$json_data = json_encode($data);

// --- Context Options for the HTTP Request ---
$options = [
    'http' => [
        'header'  => "Content-type: application/json\r\n" .
                     "Authorization: Bearer " . HUGGING_FACE_TOKEN . "\r\n",
        'method'  => 'POST',
        'content' => $json_data,
        'ignore_errors' => true // Important to get error responses from the server
    ]
];

// Create the stream context
$context  = stream_context_create($options);

// Make the HTTP request
$response = @file_get_contents(HUGGING_FACE_ENDPOINT, false, $context);

// --- Handle the Response ---
if ($response === FALSE) {
    echo "Error: Could not connect to the endpoint or retrieve a response.\n";
    // You can get more details about the error if needed:
    // var_dump($http_response_header);
} else {
    // Check HTTP response headers for status code
    $http_status_line = $http_response_header[0];
    preg_match('{HTTP\/\S+\s(\d{3})}', $http_status_line, $match);
    $status_code = $match[1];

    if ($status_code >= 200 && $status_code < 300) {
        echo "\n--- Successful API Call ---\n";
        echo "HTTP Status Code: " . $status_code . "\n";

        $decoded_response = json_decode($response, true);

        if (json_last_error() === JSON_ERROR_NONE) {
            // Check if the expected structure exists for chat completions
            if (isset($decoded_response['choices'][0]['message']['content'])) {
                echo "AI Response: " . $decoded_response['choices'][0]['message']['content'] . "\n";
            } else {
                echo "Unexpected successful response structure. Full response:\n";
                print_r($decoded_response);
            }
        } else {
            echo "Error: Failed to decode JSON response.\n";
            echo "Raw response: " . $response . "\n";
        }
    } else {
        echo "\n--- API Call Failed ---\n";
        echo "HTTP Status Code: " . $status_code . "\n";
        echo "Error Response: " . $response . "\n";
        echo "Please check:\n";
        echo "1. Your HUGGING_FACE_TOKEN is correct.\n";
        echo "2. Your HUGGING_FACE_ENDPOINT URL is correct and the model is deployed and running.\n";
        echo "3. The model (e.g., Llama 3-70B-Instruct, Llama 4 Scout) is loaded and accessible at that endpoint.\n";
        echo "4. You have accepted the model's license terms on Hugging Face.\n";
        echo "5. Your billing is correctly configured for Inference Endpoints.\n";
    }
}

?>