<?php

/*******************************************************************************
 * Company:        [Inroads, LLC]
 * Copyright:      (c) [2025] [Inroads, LLC]. All rights reserved.
 * Version:        1.0.0
 * Date:           2025-07-23
 * Last Author:    [Inroads Dev Team]
 * Filename:       db_config.php
 * Description:    Database connection settings.
 ******************************************************************************/

// --- DATABASE CONNECTION SETTINGS ---
// IMPORTANT: Replace these with your actual database credentials.
define('DB_HOST', 'localhost');
define('DB_NAME', 'aximate_studio');      // <-- IMPORTANT: Replace with your DB Name
define('DB_USER', 'xxxxxx');   // <-- IMPORTANT: Replace with your DB User
define('DB_PASS', 'xxxxxx');      // <-- IMPORTANT: Replace with your DB Password

// Create a new database connection
$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check for connection errors (PHP 5.6 and 8.2 compatible)
if ($mysqli->connect_error) {
    // In a production environment, you might log this error instead of displaying it.
    http_response_code(500);
    header('Content-Type: application/json');
    die(json_encode(array('error' => 'Database connection failed: ' . $mysqli->connect_error)));
}

// Set the character set to utf8mb4 for full Unicode support.
$mysqli->set_charset("utf8mb4");