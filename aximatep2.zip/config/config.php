<?php
// config/config.php

// =================================================================
//  APPLICATION-WIDE CONFIGURATION
// =================================================================

// --- Database Configuration ---
define('DB_HOST', 'localhost');
define('DB_NAME', 'aximate_studio');
define('DB_USER', 'xxxxxx');           // <-- ENTER your DB user
define('DB_PASS', 'xxxxxx');       // <-- ENTER your DB password

// --- Application Settings ---
define('APP_NAME', 'AxiMate Studio');
define('APP_URL', 'https://www.axiumpro.com/ai_related/aximate_content_studio');

// =================================================================
//  AI SERVICE CREDENTIALS (LLM & TTS)
// =================================================================

// --- SCRIPT GENERATION LLM (NEW: AIMLAPI.COM) ---
// *** REPLACE with your actual key from aimlapi.com ***
define('AI_API_KEY', 'xxxxxx'); 
define('AI_API_ENDPOINT', 'https://api.aimlapi.com/chat/completions');

// ** CHOOSE YOUR MODEL ** 
// You can now easily switch between any model supported by AIMLAPI.
// Examples: 'gpt-3.5-turbo', 'gpt-4-turbo-preview', 'claude-3-opus-20240229', 'google/gemini-pro'
define('AI_SCRIPT_MODEL', 'meta-llama/llama-4-scout'); // A great, affordable starting point.


// --- TEXT-TO-SPEECH (TTS) - (UNCHANGED: LEMONFOX.AI) ---
// *** REPLACE with your actual Lemonfox key ***
//define('LEMONFOX_TTS_API_KEY', 'xxxxxx'); 
//define('LEMONFOX_TTS_BASE_URL', 'https://api.lemonfox.ai/v1');
  
  
// --- TEXT-TO-SPEECH (TTS) - (ACTIVE: GOOGLE CLOUD) ---
// This is the modern, secure method for authenticating with the Google Cloud PHP library.
// It uses the full, absolute path to your JSON service account key file.
// define('GOOGLE_APPLICATION_CREDENTIALS', '/home/axiumpro/public_html/ai_related/aximate_content_studio_Development/aximate_content_studio_wssml/config/aximate-content-studio-xxxxxx.json');
  
// --- START: config.php Google Credentials Fix ---
// OLD LINE:
// define('GOOGLE_APPLICATION_CREDENTIALS', '/home/axiumpro/public_html/ai_related/aximate_content_studio_Development/aximate_content_studio_wssml/config/aximate-content-studio-xxxxxx.json');

// NEW, MORE ROBUST LINE:
// This builds the path from the config file's current location, which is safer.
define('GOOGLE_APPLICATION_CREDENTIALS', __DIR__ . '/aximate-content-studio-xxxxxx.json');
// --- END: config.php Google Credentials Fix ---  


// =================================================================
//  IMAGE GENERATION (Stability AI) & Audio Transcription (Groq)
// =================================================================

define('STABILITY_API_KEY', 'sk-xxxxxx'); // Optional: update if you use Stability AI
define('STABILITY_API_ENDPOINT', 'https://api.stability.ai/v1/generation/stable-diffusion-xl-1024-v1-0/text-to-image');
define('STABILITY_IMAGE_DIMENSIONS', '1024x1024,1152x896,896x1152,1216x832,832x1216,1344x768,768x1344,1536x640,640x1536');

define('TRANSCRIPTION_API_ENDPOINT', 'https://api.groq.com/openai/v1/audio/transcriptions');
define('TRANSCRIPTION_MODEL_NAME', 'whisper-large-v3');
  
  // =================================================================
//  CUSTOM VOICE PROVIDER CONFIGURATION
// =================================================================

// The "Master Switch": Determines which voice provider the application uses.
// For now, this is 'hume'. In the future, we can change it to 'google'.
define('CUSTOM_VOICE_PROVIDER', 'hume'); 

// --- Hume AI Credentials (Project Specific - Stored in DB) ---
// We define these constants so the application knows what to look for,
// but the actual keys will be pulled from the project's database record.
define('HUME_API_KEY', 'iBNlZTsyIVkP6SQwTc06p3xmIuhmxHlMq7AM2FcdIXrWYmId'); 
define('HUME_SECRET_KEY', 'taiwAtr4A7TWZnf1YKKCWyDDGFTUHBNeyxBoLK9NA7kBUy7ZLRCp09JRAASzkGEU');

// NO CLOSING TAG - prevents accidental whitespace output in PHP